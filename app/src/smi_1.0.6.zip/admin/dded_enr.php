<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_dde.inc.php';

include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$code = str_majuscules(valpost('code'));
$desc = str_majuscules(valpost('desc'));

$pub = array_search(valpost('pub'), $non_oui);
$cli = array_search(valpost('client'), $non_oui);
$age = array_search(valpost('age'), $non_oui);
$tec = array_search(valpost('tec'), $non_oui);
$ope = array_search(valpost('ope'), $non_oui);
$cge = array_search(valpost('cge'), $non_oui);
$stt = array_search(valpost('stt'), $non_oui);
$st = array_search(valpost('st'), $non_oui);
$dot = array_search(valpost('dot'), $non_oui);
$do = array_search(valpost('do'), $non_oui);

$email = strtolower(valpost('email'));

$retourliste = TRUE;

switch ($td) {
    // Ajout de la fiche destinataire de demande
    case 'add' :
        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
        $rech = 'SELECT COUNT(*) FROM `' . TBDDED . "` WHERE `dded_code` = '" . $db->escape($code) . "'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $rech = 'INSERT INTO `' . TBDDED . '` (dded_code,dded_desc,dded_pub,dded_cli,dded_age,dded_tec,dded_ope,dded_cge,dded_stt,dded_st,dded_dot,dded_do,dded_email,dded_delok)';
            $rech .= " VALUES ('" . $db->escape($code) . "','" . $db->escape($desc) . "','$pub','$cli','$age','$tec','$ope','$cge','$stt','$st','$dot','$do','$email','1')";
            $db->query($rech);
            $msg = _('Fiche ajoutée');
        } else {
            $msg = _('Ce code existe déjà');
            $retourliste = FALSE;
        }
        close_database();
        break;

    // MAJ de la fiche destinataire de demande
    case 'edit' :
        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
        if ($code <> 'VA') {
            $rech = 'UPDATE `' . TBDDED . "` SET `dded_code`='" . $db->escape($code) . "', `dded_desc`='" . $db->escape($desc) . "', `dded_pub`='" . $pub . "',";
            $rech .= "  `dded_cli`='" . $cli . "', `dded_age`='" . $age . "',";
            $rech .= " `dded_tec`='" . $tec . "', `dded_ope`='" . $ope . "', `dded_cge`='" . $cge . "',";
            $rech .= " `dded_stt`='" . $stt . "', `dded_st`='" . $st . "', `dded_dot`='" . $dot . "', `dded_do`='" . $do . "',";
            $rech .= " `dded_email`='" . $email . "' WHERE `dded_code` = '" . $db->escape($code) . "'";
            $db->query($rech);

            $msg = _('Fiche modifiée');
        } else {
            $msg = _('Modification impossible');
            $retourliste = FALSE;
        }
        close_database();
        break;

    // Suppression de la fiche destinataire de demande
    case 'del' :
        if ($code <> 'VA') {
            // Vérifie si utilisé dans une demande
            if (exist_dded_in_dde($code) == TRUE) {
                $msg = _('Ce destinataire de demande a déjà été utilisé dans une demande');
                $retourliste = FALSE;
            } else {
                $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

                // SUPPRESSION de la fiche destinataire de demande
                $rech = 'DELETE FROM `' . TBDDED . "` WHERE `dded_code` = '" . $db->escape($code) . "'";
                $db->query($rech);
                close_database();

                $msg = _('Fiche supprimée');
            }
        } else {
            $msg = _('Suppression impossible');
            $retourliste = FALSE;
        }
        break;
    default :
        $msg = _('Problème de paramètres');
        $retourliste = FALSE;
        break;
}
?>

<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche Destinataire de Demande'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            <?php
            if ($retourliste == FALSE)
                {echo "warn_txt('" . str_escape($msg) . "');";}
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    aff_ret_idx_man($td, 'dded_lst.php', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'dded_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>