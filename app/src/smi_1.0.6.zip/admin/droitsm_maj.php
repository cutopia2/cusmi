<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';
if (CheckURLLog(FALSE) == FALSE) {
    header('Location: ../index.php');
}
if (CheckNivLog('9') == FALSE) {
    header('Location: ../index.php');
}
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$pbm_droits = FALSE;
$nu = -1;

$td = $_GET['td'];
$coderech = $_GET['code'];

if ($pbm_droits == FALSE) {
    if ($coderech <> '') {
        $row = lit_enr_droitsm($coderech);
        if (is_array($row)) {
            $row = encode_str($row);
            extract($row);
            $nu = (int)$droitsm_nivutil;
        } else {
            $pbm_droits = TRUE;
        }
    } else {
        if ($td <> 'add') {
            $pbm_droits = TRUE;
        }
    }
}

if ($pbm_droits == FALSE) {
    if (isset($_GET['nu'])) {
        $nu = (int)trim($_GET['nu']);
        if (trim($tab_niv[$nu]) == '') {
            $pbm_droits = TRUE;
        }
    }
}

$titre = '';
if ($pbm_droits == FALSE) {
    switch ($td) {
        case 'add' :
            $titre = _('CREATION MODELE DE DROIT');
            break;
        case 'edit' :
            $titre = _('MISE A JOUR MODELE DE DROITS');
            break;
        case 'del' :
            $titre = _('SUPPRESSION MODELE DE DROITS');
            break;
        default :
            $pbm_droits = TRUE;
            break;
    }
}

$lst_id_readonly = '';
if ($nu <> -1) {
    $lst_id_readonly = 'nu';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-type=" content="text/html; charset=utf-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche modèle de droits'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab_champ = ["nom:code ; format:txt ; req:Y ; txt:<?php echo _('Code'); ?>; lmn:1 ; lmx:20; stok:frmok ; stbad:frmbad",
            "nom:nu ; format:liste ; req:Y ; txt:<?php echo _('Niveau utilisateur'); ?> ; vmn:0 ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_droits == FALSE) { ?>
        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                <?php
                switch ($td)
                {
                    case 'add' :
                        echo "init_valid_form('enr','droitsm_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                        break;
                    case 'edit' :
                        echo "init_valid_form('enr','droitsm_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                        break;
                    case 'view' :
                        echo 'readonly_all();';
                        break;
                    case 'del' :
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                }
                ?>
                readonly_id('<?php echo $lst_id_readonly; ?>', false);
                init_valselbut('sel', 'tab_droits', 1, 'auto_', true);
                init_sel_all('sel', 'tab_droits', '<?php echo _('Aucun'); ?>', 0, '<?php echo _('Tous'); ?>', 1, 'auto_');
                init_chk_valselbut('sel', 'tab_droits', '<?php echo _('Tous'); ?>', 'auto_');
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';
if ($pbm_droits == FALSE) {
    cre_ent_form($titre, 'droitsm_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="droitsm_maj" id="droitsm_maj" method="<?php if ($nu == -1) {
        echo 'get';
    } else {
        echo 'post';
    } ?>" action="<?php if ($nu <> -1) {
        echo 'droitsm_enr.php';
    } ?>">
        <?php if ($nu <> -1) { ?>
            <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <?php } else { ?>
            <input name="code" type="hidden" id="code" value="<?php echo $coderech ?>">
        <?php } ?>
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="10%" class="rubfrm" id="f_nu"><?php echo _('Niveau utilisateur'); ?></td>
                <td width="47%">
                    <?php
                    echo '<select name="nu" id="nu">';
                    foreach ($tab_niv_full as $key => $value) {
                        if ((trim($value) <> '') && ((int)$key <> 5) && ((int)$key <> 9)) {
                            echo '<option value="' . $key . '"';
                            if ($nu == (int)$key) {
                                echo ' selected';
                            }
                            echo '>';
                            echo $value . '</option>';
                        }
                    }
                    echo '</select>';
                    echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                    ?>
                </td>
            </tr>
            <?php if ($nu <> -1) { ?>
                <tr>
                    <td class="rubfrm" id="f_code"><?php echo _('Code'); ?></td>
                    <td>
                        <input name="code" type="text" id="code" value="<?php echo $droitsm_code ?>" size="20">
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_des"><?php echo _('Nom'); ?></td>
                    <td>
                        <input name="des" type="text" id="des" value="<?php echo $droitsm_des ?>" size="50">
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    </td>
                </tr>
            <?php } ?>
        </table>
        <?php
        // Tableau des droits
        if ($nu <> -1) {
            echo '<div id="tab_droits">';
            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

            // *** Affichage de la table
            echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';
            echo '<th>';
            echo _('Type opération');
            echo '</th>';
            echo '<th>';
            echo _('Autorisé');
            echo '</th>';
            echo '<th>';
            echo _('Déjà paramétré');
            echo '</th>';

            // On reprend un droit "type" pour le niveau utilisateur donné
            $rech = 'SELECT * FROM `' . TBDROITST . '`';
            $rech .= " WHERE `droitst_nivutil` = '" . $nu . "'";
            $rech .= ' ORDER BY `droitst_desc`';
            $rows = $db->get_results($rech, ARRAY_A);

            $i = 0;
            $id_max = 0;

            foreach ($rows as $row) {
                $row = encode_str($row);
                // création de l'entête de ligne (TR)
                echo '<tr>';

                $dejaprm = FALSE;

                if ($td <> 'add') {
                    // On vérifie si le détail de ce droit a déjà été paramétré
                    $rech2 = 'SELECT * FROM `' . TBDROITSMD . '`';
                    $rech2 .= " WHERE `droitsmd_nomfic` = '" . $row['droitst_nomfic'] . "'";
                    $rech2 .= " AND `droitsmd_td` = '" . $row['droitst_td'] . "'";
                    $rech2 .= " AND `droitsmd_modele` = '" . $coderech . "'";
                    $row2 = $db->get_row($rech2, ARRAY_A);
                    if ($row2) {
                        $dejaprm = TRUE;
                    }
                }

                echo '<td>' . $row['droitst_desc'] . '</td>';
                echo '<td align="center">';
                if ($dejaprm == FALSE) {
                    // Pas paramétré : on ajoute dans le Modèle
                    $rech3 = 'INSERT INTO `' . TBDROITSMD . '` (droitsmd_desc,droitsmd_nomfic,droitsmd_td,droitsmd_modele,droitsmd_auto)';
                    $rech3 .= " VALUES ('" . $row['droitst_desc'] . "','" . $row['droitst_nomfic'] . "','" . $row['droitst_td'] . "','" . $coderech . "','" . $row['droitst_auto'] . "')";
                    $db->query($rech3);

                    $last_id = $db->insert_id;
                    $id_max = max($id_max, $last_id);

                    echo '<input name="num[]" type="hidden" id="num[]" value="' . $last_id . '" readonly="readonly">';
                    cre_select('auto_' . $last_id, 'auto_' . $last_id, $non_oui, (int)$row['droitst_auto']);
                } else {
                    echo '<input name="num[]" type="hidden" id="num[]" value="' . $row2['droitsmd_id'] . '" readonly="readonly">';
                    $id_max = max($id_max, $row2['droitsmd_id']);
                    cre_select('auto_' . $row2['droitsmd_id'], 'auto_' . $row2['droitsmd_id'], $non_oui, (int)$row2['droitsmd_auto']);
                }
                echo '</td>';
                echo '<td align="center">';
                echo $non_oui[$dejaprm];
                echo '</td>';
                echo '</tr>';

                $i++;
            }

            echo '</table>';
            // *** Fin affichage de la table

            close_database();

            echo '</div>';
        }

        if ($td <> 'del') {
            if ($nu <> -1) {
                echo '<p align="center">';
                echo '<input type="button" name="sel" id="sel" value="' . _('Aucun') . '" class="bton_fgris_petit">';
                echo '</p>';
            }
        }
        ?>
        <p align="center">
            <?php
            switch ($td) {
                case 'add' :
                case 'edit' :
                    if ($nu <> -1) {
                        echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Enregistrer') . '">';
                    } else {
                        echo '<input name="valid" type="submit" class="bton_std" id="valid" value="' . _('Valider') . '">';
                    }
                    echo '<input name="RAZ" type="reset" class="bton_std" id="RAZ" value="' . _('Réinitialiser') . '">';
                    break;
                case 'del' :
                    echo '<input name="del" type="submit" class="bton_std" id="del" value="' . _('Supprimer') . '">';
                    break;
            }
            ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'droitsm_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>