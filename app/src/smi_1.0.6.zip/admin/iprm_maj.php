<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_age.inc.php';
include_once '../inc/fic_cli.inc.php';
include_once '../inc/fic_cocl.inc.php';
include_once '../inc/fic_dde.inc.php';
include_once '../inc/fic_dos.inc.php';
include_once '../inc/fic_loc.inc.php';
include_once '../inc/fic_ope.inc.php';
include_once '../inc/fic_ot.inc.php';
include_once '../inc/fic_rel.inc.php';
include_once '../inc/fic_ret.inc.php';
include_once '../inc/fic_tac.inc.php';
include_once '../inc/fic_tec.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$td = $_GET['td'];
$coderech = $_GET['code'];

$pbm_iprm = FALSE;

if ($coderech <> '') {
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
    $rech = 'SELECT * FROM `' . TBIPRM . "` WHERE iprm_code = '$coderech'";
    $row = $db->get_row($rech, ARRAY_A);
    if ($row) {
        $row = encode_str($row);
        extract($row);
    } else {
        $pbm_iprm = TRUE;
    }
    close_database();
} else {
    if ($td == 'add') {
        $iprm_code = '';
        $iprm_nom = '';
    } else {
        $pbm_iprm = TRUE;
    }
}

switch ($td) {
    case 'add' :
        $titre = _('CREATION PARAMETRES IMPORT SPECIFIQUE');
        break;
    case 'edit' :
        $titre = _('MISE A JOUR PARAMETRES IMPORT SPECIFIQUE');
        break;
    case 'del' :
        $titre = _('SUPPRESSION PARAMETRES IMPORT SPECIFIQUE');
        break;
    default :
        $pbm_iprm = TRUE;
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Paramètres imports spécifiques'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab1_champ = ["nom:code ; format:txt ; req:Y ; txt:<?php echo _('Code'); ?> ; lmx:20 ; stok:frmok ; stbad:frmbad",
            "nom:nom ; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?> ; lmx:50 ; stok:frmok ; stbad:frmbad",
            "nom:typbd ; format:liste ; req:Y ; txt:<?php echo _('Type base de données'); ?>; stok:frmok ; stbad:frmbad",
            "nom:ipbd ; format:txt ; req:Y ; txt:<?php echo _('Adresse IP'); ?>; lmx:50 ; stok:frmok ; stbad:frmbad",
            "nom:nombd ; format:txt ; req:Y ; txt:<?php echo _('Nom'); ?>; lmx:50 ; stok:frmok ; stbad:frmbad",
            "nom:userbd ; format:txt ; req:Y ; txt:<?php echo _('Utilisateur'); ?>; lmx:50 ; stok:frmok ; stbad:frmbad",
            "nom:pwbd ; format:txt ; req:Y ; txt:<?php echo _('Mot de Passe'); ?>; lmx:50 ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_fam == FALSE) { ?>
        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                <?php
                switch ($td)
                {
                    case 'add' :
                        echo "init_valid_form('enr','iprm_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'edit' :
                        echo "init_valid_form('enr','iprm_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'view' :
                        echo 'readonly_all();';
                        break;
                    case 'del' :
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                }
                ?>
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>
<body>
<?php
include_once '../inc/entete.inc.php';

if ($pbm_iprm == FALSE) {
    cre_ent_form($titre, 'iprm_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="iprm_maj" id="iprm_maj" method="post" action="iprm_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
            <tr>
                <td width="30%" class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                <td>
                    <?php if ($td == 'add') { ?>
                        <input name="code" type="text" id="code" value="<?php echo $iprm_code ?>" size="20"
                               maxlength="20">
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    <?php } else { ?>
                        <input name="code" type="text" id="code" value="<?php echo $iprm_code ?>" size="20"
                               maxlength="20" readonly="1">
                    <?php } ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_nom" align="right"><?php echo _('Libellé'); ?></td>
                <td>
                    <input name="nom" type="text" id="nom" value="<?php echo $iprm_nom ?>" size="50">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_typbd" align="right"><?php echo _('Type base de données'); ?></td>
                <td>
                    <?php
                    cre_select('typbd', 'typbd', $imp_typbd, $iprm_typbd);
                    ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_ipbd" align="right"><?php echo _('Adresse IP'); ?></td>
                <td>
                    <input name="ipbd" type="text" id="ipbd" value="<?php echo $iprm_ip ?>" size="50">
                    <span
                        class="annot_petit_it">(<?php echo _('Du serveur MySQL - Format xxx.xxx.xxx.xxx ou nom de serveur'); ?>
                        )</span>
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_nombd" align="right"><?php echo _('Nom'); ?></td>
                <td>
                    <input name="nombd" type="text" id="nombd" value="<?php echo $iprm_bd ?>" size="50">
                    <span class="annot_petit_it">(<?php echo _('De la base de données'); ?>)</span>
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_userbd" align="right"><?php echo _('Utilisateur'); ?></td>
                <td>
                    <input name="userbd" type="text" id="userbd" value="<?php echo $iprm_user ?>" size="50">
                    <span class="annot_petit_it">(<?php echo _('De la base de données'); ?>)</span>
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_pwbd" align="right"><?php echo _('Mot de Passe'); ?></td>
                <td>
                    <input name="pwbd" type="text" id="pwbd" value="<?php echo $iprm_pw ?>" size="50">
                    <span class="annot_petit_it">(<?php echo _("Pour l'utilisateur ci-dessus"); ?>)</span>
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                </td>
            </tr>
        </table>
        <p align="center">
            <?php
            switch ($td) {
                case 'add' :
                case 'edit' :
                    echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Enregistrer') . '">';
                    echo ' <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="' . _('Réinitialiser') . '">';
                    break;
                case 'del' :
                    echo '<input name="del" type="submit" class="bton_std" id="del" value="' . _('Supprimer') . '">';
                    break;
            }
            ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'iprm_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>