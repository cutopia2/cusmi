<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_co.inc.php';
include_once '../inc/fic_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$td = $_GET['td'];
$coderech = $_GET['code'];

$pbm_co = FALSE;

if ($coderech <> '') {
    // Récupération des informations contrat
    $row = lit_enr_co($coderech);
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);

        if ($td == 'add') {
            $co_code = '(2)' . $coderech;
            $co_code = substr($co_code, 0, 10); // Le code ne doit pas dépasser 10 caractères
            $co_nom = ''; // RAZ du nom pour nouveau nom
        }
    } else {
        $pbm_co = TRUE;
    }
} else {
    if ($td == 'add') {
        // Récupération du texte "master" des conditions générales de vente pour les contrats

        $row = lit_enr_txt('CON_CGV_MASTER');
        extract($row);

        $co_cgv = $txt_texte;
    } else {
        $pbm_co = TRUE;
    }
}

$titre = '';
switch ($td) {
    case 'add' :
        $titre = _('CREATION CONTRAT TYPE');
        break;
    case 'edit' :
        $titre = _('MISE A JOUR CONTRAT TYPE');
        break;
    case 'del' :
        $titre = _('SUPPRESSION CONTRAT TYPE');
        break;
    default :
        $pbm_co = TRUE;
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche contrat type'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab1_champ = ["nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?>; lmx:20 ; stok:frmok ; stbad:frmbad",
            "nom:nom ; format:txt ; req:Y ; txt:<?php echo _('Nom'); ?> ; lmx:50 ; stok:frmok ; stbad:frmbad",
            "nom:desc ; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?>; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_co == FALSE) { ?>
        <script type="text/javascript">
            <!--
            $(function () {
                $("#code").Setcase({caseValue: 'upper', changeonFocusout: true});
                $("#nom").Setcase({caseValue: 'upper', changeonFocusout: true});
            });

            function init_all() {
                init_Body();
                <?php
                switch ($td)
                {
                    case 'add' :
                        echo "$('#texte').ckeditor();";
                        echo "init_valid_form('enr','co_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'edit' :
                        echo "$('#texte').ckeditor();";
                        echo "init_valid_form('enr','co_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        echo "init_new_fen('imprim','impression','click');";
                        break;
                    case 'view' :
                        echo 'readonly_all();';
                        break;
                    case 'del' :
                        echo "warn_del('');";
                        echo 'readonly_all();';
                        break;
                }
                ?>
                init_back('annul', 'click');
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>
    <?php } ?>
</head>
<body>

<?php
include_once '../inc/entete.inc.php';

if ($pbm_co == FALSE) {
    cre_ent_form($titre, 'co_lst.php', $_SERVER['HTTP_REFERER'], 'co_maji.php?code=' . $coderech);
    ?>
    <form name="co_maj" id="co_maj" method="post" action="co_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="160" class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                <td>
                    <?php if ($td == 'add') { ?>
                        <input name="code" type="text" id="code" value="<?php echo $co_code ?>" size="10">
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    <?php } else { ?>
                        <input name="code" type="text" id="code" value="<?php echo $co_code ?>" size="10" readonly>
                    <?php } ?>
                </td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_nom" align="right"><?php echo _('Nom'); ?></td>
                <td>
                    <?php
                    if (($td == 'add') || ($td == 'edit')) {
                        ?>
                        <input name="nom" type="text" id="nom" value="<?php echo $co_nom ?>" size="50">
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                        <?php
                    } else {
                        ?>
                        <input name="nom" type="text" id="nom" value="<?php echo $co_nom ?>" size="50" readonly>
                        <?php
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_desc" align="right"><?php echo _('Libellé'); ?></td>
                <td>
                    <?php
                    if (($td == 'add') || ($td == 'edit')) {
                        ?>
                        <textarea name="desc" rows="5" id="desc"><?php echo $co_desc ?></textarea>
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                        <?php
                    } else {
                        ?>
                        <textarea name="desc" rows="5" readonly id="desc"><?php echo $co_desc ?></textarea>
                        <?php
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td valign="top" class="rubfrm" id="f_cgv"
                    align="right"><?php echo _("Conditions générales de vente du contrat (par l'agence)"); ?></td>
                <td valign="top">
                    <textarea name="texte" rows="10" readonly id="texte"><?php echo $co_cgv ?></textarea>
                    <img src="../img/oblig.png" align="absmiddle" align="top">
                </td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_actif" align="right"><?php echo _('Actif'); ?></td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('actif', 'actif', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('actif', 'actif', $non_oui, (int)$co_actif);
                    }
                    ?>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_actif" align="right"><?php echo _('Spécifique'); ?></td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('specif', 'specif', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('specif', 'specif', $non_oui, (int)$co_specif);
                    }
                    ?>
                    <span
                        class="annot_petit_it"><?php echo _("(Si spécifique, utilisable en espace privé, mais pas affiché dans l'espace publique)"); ?></span>
                </td>
            </tr>
        </table>
        <p align="center">
            <?php if (($td == 'add') || ($td == 'edit')) { ?>
                <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="<?php echo _('Réinitialiser'); ?>">
                <input name="enr" type="button" class="bton_std" id="enr" value="<?php echo _('Enregistrer'); ?>">
            <?php } ?>
            <?php if ($td == 'del') { ?>
                <input name="del" type="submit" class="bton_std" id="del" value="<?php echo _('Supprimer'); ?>">
                <input name="annul" type="button" class="bton_std" id="annul" value="<?php echo _('Annuler'); ?>">
            <?php } ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'co_lst.php');
}
include_once 'pied.php';
?>
