<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';

if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_age.inc.php';
include_once '../inc/fic_cli.inc.php';
include_once '../inc/fic_cocl.inc.php';
include_once '../inc/fic_do.inc.php';
include_once '../inc/fic_dos.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/fic_fici.inc.php';
include_once '../inc/fic_int.inc.php';
include_once '../inc/fic_loc.inc.php';
include_once '../inc/fic_ope.inc.php';
include_once '../inc/fic_ot.inc.php';
include_once '../inc/fic_pdt.inc.php';
include_once '../inc/fic_plan.inc.php';
include_once '../inc/fic_prm.inc.php';
include_once '../inc/fic_prmmail.inc.php';
include_once '../inc/fic_rdv.inc.php';
include_once '../inc/fic_rel.inc.php';
include_once '../inc/fic_st.inc.php';
include_once '../inc/fic_statut.inc.php';
include_once '../inc/fic_tac.inc.php';
include_once '../inc/fic_tec.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_time.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));

$pbm_conf = FALSE;
if (CheckNivLog('5') == TRUE) {
    if (!exist_logo('cge')) {
        $pbm_conf = TRUE;
    }
    if (!exist_logo_allage()) {
        $pbm_conf = TRUE;
    }
    if (!existe_cdg()) {
        $pbm_conf = TRUE;
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Index Backoffice'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            init_autohref_classe('falselnkimg', '<?php echo str_escape(_("Merci de confirmer<br />Sinon, cliquez sur 'Annuler'")); ?>');
            <?php
            if ($pbm_conf == FALSE)
            {
                if (CheckNivLog('5')) {
                    echo "init_warn('".pbm_tecspr('')."tecspr','','','','');";
                    echo "init_warn('".pbm_agespr()."agespr','','','','');";
                    echo "init_warn('".pbm_cagespr('')."cagespr','','','','');";
                    echo '$( "#onglets_idx" ).tabs();';
                }
            }
            else
            {
            ?>
            jError('<?php echo str_escape(_("SMI n'a pas encore été totalement configuré")) . '<br />' . str_escape(_("Merci de contacter l'administrateur")); ?>',
                {
                    autoHide: true,
                    HorizontalPosition: 'center',
                    VertitalPosition: 'center',
                    TimeShown: 5000
                }
            );
            window.location = ('index.php');
            <?php
            }
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>

<body>
<?php
if ($pbm_conf == FALSE) {
    include_once '../inc/entete.inc.php';

    if (CheckNivLog('5') == TRUE) {
        cre_ent_form(_('TABLEAU DE BORD'), '', '', '', FALSE);
        ?>
        <div id="onglets_idx">
            <ul>
                <li><a href="#idx_tac"><?php echo _('Tâches à effectuer'); ?></a></li>
                <li><a href="#idx_intc"><?php echo _('Interventions en cours'); ?></a></li>
                <li><a href="#idx_intag"><?php echo _('Inter. à gérer'); ?></a></li>
                <li><a href="#idx_relp"><?php echo _('Relevés avec problèmes'); ?></a></li>
                <li><a href="#idx_cocle"><?php echo _('Contrats à échéance'); ?></a></li>
                <li><a href="#idx_dosc"><?php echo _('Dossiers en cours'); ?></a></li>
            </ul>
            <div id="idx_tac">
                <?php
                // RAZ variables pour les pieds de liste
                include '../inc/init_varpl.inc.php';

                $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

                $rech = cree_strrechlsttac();
                if (stripos($rech,'WHERE ') == FALSE) {
                    $rech .= ' WHERE ' . TBTAC . ".tac_codedest<>'" . $db->escape($admin_code) . "'";
                } else {
                    $rech .= ' AND ' . TBTAC . ".tac_codedest<>'" . $db->escape($admin_code) . "'";
                }
                if (stripos($rech,'WHERE ') == FALSE) {
                    $rech .= " WHERE tac_datefin='0000-00-00'";
                } else {
                    $rech .= " AND tac_datefin='0000-00-00'";
                }
                $rech .= 'ORDER BY ' . TBTAC . '.tac_code DESC';

                $rows = $db->get_results($rech, ARRAY_A);
                if ($rows) {
                    // *** Affichage de la table
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    titlst($tac_titre_col, FALSE);
                    echo '<th>' . _('Cliquer') . '</th>';

                    $i = 0;

                    // Inclusion module affichage liste tâches
                    include_once '../inc/tacr_lst.inc.php';

                    echo '</table>';
                    // *** Fin affichage de la table
                } else {
                    echo '<div class="annot_gras_it">';
                    echo '<br />' . _('Pas de tâche en cours');
                    echo '</div>';
                }
                close_database();

                $taille_piedla = '';
                include '../inc/piedla.inc.php'; ?>
            </div>

            <div id="idx_intc">
                <?php
                // RAZ variables pour les pieds de liste
                include '../inc/init_varpl.inc.php';

                $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

                $rech = cree_strrechlstint($_SESSION['niv_log']);
                if (stripos($rech,'WHERE ') == FALSE) {
                    $rech .= ' WHERE ' . TBINT . ".int_codestatut <> 'CLOT'";
                } else {
                    $rech .= ' AND ' . TBINT . ".int_codestatut <> 'CLOT'";
                }
                $rech .= ' AND ' . TBINT . ".int_codetec <> '-1'";
                $rech .= 'ORDER BY ' . TBINT . '.int_code DESC';
                // *** Fin de chaîne de Recherche

                $rows = $db->get_results($rech, ARRAY_A);
                if ($rows) {
                    echo '<div class="annot_std_it">';
                    echo _('Laisser la souris sur une icône pour le détail');
                    echo '</div>';

                    // *** Affichage de la table
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    titlst($int_titre_col, FALSE);
                    echo '<th>' . _('Cliquer') . '</th>';

                    $i = 0;

                    // Inclusion module affichage liste interventions
                    include '../inc/intr_lst.inc.php';

                    echo '</table>';
                    // *** Fin affichage de la table
                } else {
                    echo '<div class="annot_gras_it">';
                    echo '<br />' . _("Pas d'intervention en cours");
                    echo '</div>';
                }
                close_database();

                $taille_piedla = '';
                include '../inc/piedla.inc.php'; ?>
            </div>


            <div id="idx_intag">
                <?php
                // RAZ variables pour les pieds de liste
                include '../inc/init_varpl.inc.php';

                $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

                $rech = cree_strrechlstint($_SESSION['niv_log']);
                if (stripos($rech,'WHERE ') == FALSE) {
                    $rech .= ' WHERE ' . TBINT . ".int_codetec = '-1'";
                } else {
                    $rech .= ' AND ' . TBINT . ".int_codetec = '-1'";
                }

                $rech .= ' ORDER BY ' . TBINT . '.int_code DESC';

                // *** Fin de chaîne de Recherche

                $rows = $db->get_results($rech, ARRAY_A);
                if ($rows) {
                    echo '<span class="annot_petit_it">';
                    echo _('Laisser la souris sur une icône pour le détail') . '<br />';
                    echo '</span>';

                    // *** Affichage de la table
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    titlst($int_titre_col, FALSE);
                    echo '<th>' . _('Cliquer') . '</th>';

                    $i = 0;

                    // Inclusion module affichage liste interventions
                    include '../inc/intr_lst.inc.php';

                    echo '</table>';
                    // *** Fin affichage de la table
                } else {
                    echo '<div class="annot_gras_it">';
                    echo '<br />' . _("Pas d'intervention en cours");
                    echo '</div>';
                }
                close_database();

                $taille_piedla = '';
                include '../inc/piedla.inc.php'; ?>
            </div>

            <div id="idx_relp">
                <span class="annot_std_it"><?php echo _('Déclarés et non affectés à une intervention'); ?></span>
                <?php
                // RAZ variables pour les pieds de liste
                include '../inc/init_varpl.inc.php';

                $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

                $rech = cree_strrechlstrrel();
                $rech .= crestr_triord($rel_titre_col, 'rel_code', FALSE, $limit);
                // *** Fin de chaîne de Recherche

                $rows = $db->get_results($rech, ARRAY_A);
                if ($rows) {
                    $first = TRUE;
                    $i = 0;

                    foreach ($rows as $row) {
                        $row = encode_str($row);
                        // Affichage résumé relevé

                        // vérification si problème(s) non affecté(s)
                        // Si oui, on affiche (sinon, non)
                        $rech2 = 'SELECT COUNT(*) FROM `' . TBRPBM . "`  WHERE rpbm_codecli = '" . $row['cli_code'] . "' AND rpbm_codeint IS NULL";
                        $nb_rs = $db->get_var($sql);
                        if ($nb_rs > 0) {
                            if ($first == TRUE) {
                                // *** Affichage de la table
                                echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                                // création entête
                                titlst($rel_titre_col, FALSE);
                                echo '<th>' . _('Cliquer') . '</th>';

                                $first = FALSE;
                            }

                            // création de l'entête de ligne (TR)
                            echo '<tr>';

                            echo '<td>';
                            echo $row['rel_code'];
                            echo '</td>';
                            echo '<td>' . datetolocal($row['rel_datecrea']) . '</td>';
                            echo '<td>' . datetolocal($row['rel_datemod']) . '</td>';
                            echo '<td>' . $row['rel_codecli'];

                            // Affichage détail client

                            $detailcli = '->';
                            if ($row['cli_ste'] <> '') {
                                $detailcli .= $row['cli_ste'] . ', ';
                            }
                            $detailcli .= $row['cli_civilite'] . ' ' . $row['cli_nom'];
                            echo '<br />';
                            echo '<span class="annot_std_it">';
                            echo $detailcli;
                            echo '</span>';

                            // Fin affichage détail client

                            echo '</td>';
                            if ($row['rel_codeage'] <> '') {
                                echo '<td>' . $row['rel_codeage'] . '</td>';
                            } else {
                                echo '<td>&nbsp;</td>';
                            }

                            // CREATION lien dynamique sur icône (édition, suppression, etc...)
                            echo '<td align="center">';
                            $lst_maj = TRUE;
                            cre_falselnk_img('', 'rel_edit_' . $row['rel_id'], 'span', 'center', _('Edition'), 'lnk', 'rel_maj.php?td=edit&cr=' . $row['rel_code'] . '&cc=' . $row['rel_codecli'] . '&ca=' . $row['rel_codeage'], '../img/edit.png');
                            $lst_imp = TRUE;
                            $urlimp = 'rel_pdf.php?cr=' . $row['rel_code'] . '&pbm=0';
                            cre_falselnk_img('', 'rel_prn_' . $row['rel_id'], 'span', 'center', _('Imprimer le dossier relevé'), 'lnkpop', $urlimp, '../img/print.png');
                            $lst_impp = TRUE;
                            $urlimp = 'rel_pdf.php?cr=' . $row['rel_code'] . '&pbm=1';
                            cre_falselnk_img('', 'rel_prnp_' . $row['rel_id'], 'span', 'center', _('Imprimer le dossier relevé avec les problèmes'), 'lnkpop', $urlimp, '../img/printc.png');
                            $lst_del = TRUE;
                            cre_falselnk_img('', 'rel_del_' . $row['rel_id'], 'span', 'center', _('Suppression'), 'lnk', 'rel_maj.php?td=edit&cr=' . $row['rel_code'] . '&cc=' . $row['rel_codecli'] . '&ca=' . $row['rel_codeage'], '../img/del.png');
                            echo '</td>';

                            echo '</tr>';
                            // Fin affichage résumé intervention

                            $i++;
                        }
                    }

                    if ($first == FALSE) {
                        echo '</table>';
                    } // *** Fin affichage de la table
                    else {
                        echo '<div class="annot_gras_it">';
                        echo '<br />';
                        echo _('Pas de problème déclaré non affecté');
                        echo '</div>';
                    }
                } else {
                    echo '<div class="annot_gras_it">';
                    echo '<br />' . _('Pas de Relevé sur cette agence');
                    echo '</div>';
                }
                close_database();

                $taille_piedla = '';
                include '../inc/piedla.inc.php'; ?>
            </div>

            <div id="idx_cocle">
                <span
                    class="annot_std_it"><?php echo _('Signés, non renouvelés, avec moins de 60 minutes de solde sur quota horaire ou à échéance dans 30 jours maximum'); ?></span>
                <?php
                // RAZ variables pour les pieds de liste
                include '../inc/init_varpl.inc.php';

                $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

                $rech = cree_strrechlstcocl();
                if (stripos($rech,'WHERE ') == FALSE) {
                    $rech .= ' WHERE ';
                } else {
                    $rech .= ' AND ';
                }
                $rech .= TBCOCL . ".cocl_datefin ='0000-00-00' AND " . TBCOCL . ".cocl_datesig <>'0000-00-00' AND " . TBCOCL . '.cocl_renouv =0';
                $rech .= '  AND ' . TBCOCL . ".cocl_dated<='" . $datea . "'";
                $rech .= ' AND (' . TBCOCL . '.cocl_typh=1';
                $rech .= ' OR (' . TBCOCL . ".cocl_datef <='" . nouv_date_plus_jours($datea, 30) . "' AND " . TBCOCL . ".cocl_datef<>'0000-00-00'))";
                $rech .= ' ORDER BY ' . TBCOCL . '.cocl_code DESC';
                // *** Fin de chaîne de Recherche

                $rows = $db->get_results($rech, ARRAY_A);
                if ($rows) {
                    echo '<span class="annot_petit_it">';
                    echo _('Laisser la souris sur une icône pour le détail') . '<br />';
                    echo '</span>';

                    echo ' <a href="coclren_lst.php?ord=DES&tri=Code">' . _('Renouveler des contrats') . '</a>';

                    // *** Affichage de la table
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    titlst($cocl_titre_col, FALSE);
                    echo '<th>' . _('Cliquer') . '</th>';

                    $i = 0;
                    foreach ($rows as $row) {
                        $row = encode_str($row);
                        // Affichage résumé Contrat Client

                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        $aff_ok = TRUE;

                        $soldes_reel = solde_contrat_sec($row['cocl_code'], FALSE);
                        if ($row['cocl_typh'] == 1) {
                            if ($soldes_reel > 3600) {
                                $aff_ok = FALSE;
                            }
                        }

                        if ($aff_ok == TRUE) {
                            $echeance_ok = TRUE;
                            if (datetolocal($row['cocl_datef']) <> '') {
                                if (echeance_depassee_date($datea, $row['cocl_datef']) == TRUE) {
                                    $echeance_ok = FALSE;
                                }
                            }

                            echo '<td>' . $row['cocl_code'];

                            // détail contrat
                            echo '<br />';
                            echo '<span class="annot_petit_it">';
                            $txt = formatetxt($row['co_nom']);
                            echo '->' . _('Type') . ' : ' . $txt;
                            echo '</span>';

                            echo '</td>';

                            // Type de contrat
                            echo '<td align="center">' . $typ_horaire[$row['cocl_typh']] . '</td>';

                            echo '<td>';
                            echo $row['cocl_codecli'];
                            cre_falselnk_img('', 'cli_edit_' . $row['cli_id'], 'span', 'center', _('Edition client'), 'lnk', 'cli_maj.php?td=edit&cc=' . $row['cocl_codecli'] . '&dep=' . $row['cli_dep'], '../img/edit.png');

                            // Affichage détail client

                            $detailcli = '->';
                            if ($row['cli_ste'] <> '') {
                                $detailcli .= $row['cli_ste'] . ', ';
                            }
                            $detailcli .= $row['cli_civilite'] . ' ' . $row['cli_nom'];
                            echo '<br />';
                            echo '<span class="annot_petit_it">';
                            echo $detailcli;
                            echo '</span>';

                            // Fin affichage détail client

                            echo '</td>';

                            // création
                            echo '<td>';
                            echo '<div align="center">';
                            echo datetolocal($row['cocl_datecrea']);
                            echo '</div>';
                            echo '</td>';
                            // début
                            echo '<td>';
                            echo '<div align="center">';
                            echo datetolocal($row['cocl_dated']);
                            echo '</div>';
                            echo '</td>';
                            // Fin
                            echo '<td>';
                            echo '<div align="center">';
                            if (datetolocal($row['cocl_datef']) == '') {
                                echo '&nbsp;';
                            } else {
                                echo datetolocal($row['cocl_datef']);
                            }
                            echo '</div>';
                            echo '</td>';
                            // Temps
                            echo '<td>';
                            echo '<div align="center">';
                            echo '<span class="annot_petit_it">';
                            if ($row['cocl_typh'] == 1) {
                                echo _('Solde initial') . ' : ' . heure_to_hhmm(sec_heure($row['cocl_nbs'], 3, TRUE));
                                if (datetolocal($row['cocl_datesig']) <> '') {
                                    $soldes = solde_contrat_sec($row['cocl_code'], FALSE);
                                    $soldeass = $soldes_reel - $soldes;
                                    echo '<br />' . _('Solde actuel') . ' : ' . heure_to_hhmm(sec_heure($soldes, 3, TRUE));
                                    echo '<br />' . _('A sortir') . ' : ' . heure_to_hhmm(sec_heure($soldeass, 3, TRUE));
                                    echo '<br />' . _('Solde réel') . ' : ';
                                    echo heure_to_hhmm(sec_heure($soldes_reel, 3, TRUE));
                                }
                            } else {
                                echo '-';
                            }
                            echo '</span>';
                            echo '</div>';
                            echo '</td>';
                            // relancé le
                            echo '<td>';
                            echo '<div align="center">';
                            if (datetolocal($row['cocl_daterel']) == '') {
                                echo '-';
                            } else {
                                echo datetolocal($row['cocl_daterel']);
                            }
                            echo '</div>';
                            echo '</td>';

                            // Renouvellement
                            echo '<td>';

                            // Affichage détail renouvelé
                            echo '<div align="center">';
                            echo $non_oui[$row['cocl_renouv']];

                            if ($row['cocl_renouv'] == 1) {
                                // Affichage détail renouvellement

                                $detailren = '(' . $row['cocl_rnum'] . ')';
                                echo '<br />';
                                echo '<span class="annot_petit_it">';
                                echo $detailren;
                                echo '</span>';

                                // Fin affichage détail renouvellement
                            }

                            echo '</div>';
                            // Fin affichage détail renouvelé

                            echo '</td>';

                            // CREATION lien dynamique sur icône (édition, suppression, etc...)
                            echo '<td align="center">';

                            if ((datetolocal($row['cocl_datefin']) == '') && ($echeance_ok == TRUE)) {
                                $lst_maj = TRUE;
                                cre_falselnk_img('', 'cocl_edit_' . $row['cocl_id'], 'span', 'center', _('Edition'), 'lnk', 'cocl_maj.php?td=edit&co=' . $row['cocl_code'] . '&cc=' . $row['cocl_codecli'], '../img/edit.png');
                            } else {
                                $lst_voir = TRUE;
                                cre_falselnk_img('', 'cocl_view_' . $row['cocl_id'], 'span', 'center', _('Visualisation'), 'lnk', 'cocl_maj.php?td=view&co=' . $row['cocl_code'] . '&cc=' . $row['cocl_codecli'], '../img/eye.png');
                            }
                            if ((datetolocal($row['cocl_datesig']) <> '') && (datetolocal($row['cocl_datefin']) == '') && (tps_trav_non_clot_sec($row['cocl_code'], FALSE) == 0)) {
                                $lst_clore = TRUE;
                                cre_falselnk_img('', 'cocl_clore_' . $row['cocl_id'], 'span', 'center', _('Clore'), 'lnk', 'coclclos_maj.php?co=' . $row['cocl_code'], '../img/clore.png');
                            }

                            if ((datetolocal($row['cocl_datefin']) == '') && (datetolocal($row['cocl_datesig']) <> '') && ($echeance_ok == TRUE)) {
                                $lst_int = TRUE;
                                $url_int = 'int_maj.php?td=add&ci=&cc=' . $row['cocl_codecli'] . '&ca=' . $row['cocl_codeage'] . '&co=' . $row['cocl_code'];
                                cre_falselnk_img('', 'int_add_' . $row['cocl_id'], 'span', 'center', _('Saisir intervention sur le contrat') . $row['cocl_code'], 'lnk', $url_int, '../img/int.png');
                            }

                            $lst_histo = TRUE;
                            $urlhisto = 'cocls_pdf.php?co=' . $row['cocl_code'];
                            cre_falselnk_img('', 'cocl_syn_' . $row['cocl_id'], 'span', 'center', _('Synthèse du contrat'), 'lnkpop', $urlhisto, '../img/histo.png');

                            $lst_imp = TRUE;
                            $urlimp = 'cocl_pdf.php?code=' . $row['cocl_code'];
                            cre_falselnk_img('', 'cocl_prn_' . $row['cocl_id'], 'span', 'center', _('Imprimer'), 'lnkpop', $urlimp, '../img/print.png');

                            echo '</td>';

                            echo '</tr>';
                            // Fin affichage résumé Contrat Client

                            $i++;
                        }
                    }
                    echo '</table>';
                    // *** Fin affichage de la table
                } else {
                    echo '<div class="annot_gras_it">';
                    echo '<br />' . _('Pas de contrat bientôt à échéance');
                    echo '</div>';
                }
                close_database();

                $taille_piedla = '';
                include '../inc/piedla.inc.php';
                ?>
            </div>

            <div id="idx_dosc">
                <?php
                // RAZ variables pour les pieds de liste
                include '../inc/init_varpl.inc.php';

                $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

                $rech = cree_strrechlstdos();
                if (stripos($rech,'WHERE ') == FALSE) {
                    $rech .= ' WHERE ';
                } else {
                    $rech .= ' AND ';
                }
                $rech .= TBDOS . ".dos_datefin ='0000-00-00'";
                $rech .= ' ORDER BY ' . TBDOS . '.dos_datefinp ASC';
                // *** Fin de chaîne de Recherche

                $rows = $db->get_results($rech, ARRAY_A);
                if ($rows) {
                    echo '<span class="annot_petit_it">';
                    echo _('Laisser la souris sur une icône pour le détail') . '<br />';
                    echo '</span>';

                    // *** Affichage de la table
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    titlst($dos_titre_col, FALSE);
                    echo '<th>' . _('Cliquer') . '</th>';

                    $i = 0;

                    // Inclusion module affichage liste dossiers
                    include_once '../inc/dosr_lst.inc.php';

                    echo '</table>';
                    // *** Fin affichage de la table
                } else {
                    echo '<div class="annot_gras_it">';
                    echo '<br />' . _('Pas de dossier de suivi en cours');
                    echo '</div>';
                }
                close_database();

                $taille_piedla = '';
                include '../inc/piedla.inc.php';
                ?>
            </div>
        </div>
        <?php
    } else {
        cre_ent_form(_('BACKOFFICE'), '', '', '', FALSE);
        if ((existe_cdg() == FALSE) || (exist_logo('cge') == FALSE)) {
            ?>
            <br/>
            <div align="center"><span class="alerte1"><?php echo _('Centre de gestion non paramétré'); ?></span></div>
            <br/>
            <div align="center" class="annot_gras_it"><a href="cge_maj.php"><?php echo _('Configurer'); ?></a></div>
            <?php
        }
        ?>
        <?php
        if (exist_logo_allage() == FALSE) {
            ?>
            <br/>
            <div align="center"><span class="alerte1"><?php echo _("Certaines agences n'ont pas de logo"); ?></span>
            </div>
            <br/>
            <div align="center" class="annot_gras_it"><a href="logo_maj.php?td=age"><?php echo _('Configurer'); ?></a>
            </div>
            <?php
        }
        ?>
        <p align="center" class="annot_std_gras"><?php echo _('Etat des fichiers'); ?></p>

        <table class="Mtable" border="0" width="500" cellpadding="0" cellspacing="0" align="center">
            <tr>
                <td width="75%" align="right"><span
                        class="annot_std_gras"><?php echo _("Nombre d'opérateurs téléphoniques"); ?></span></td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_ope(); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span class="annot_std_gras"><?php echo _("Nombre d'agences"); ?></span>
                </td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_age(); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span
                        class="annot_std_gras"><?php echo _('Nombre de techniciens agences'); ?></span></td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_tec(''); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span
                        class="annot_std_gras"><?php echo _("Nombre de donneurs d'ordres"); ?></span></td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_do(); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span
                        class="annot_std_gras"><?php echo _("Nombre de techniciens donneurs d'ordres"); ?></span></td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_tec_do(''); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span
                        class="annot_std_gras"><?php echo _('Nombre de sous-traitants'); ?></span></td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_st(); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span
                        class="annot_std_gras"><?php echo _('Nombre de techniciens sous-traitants'); ?></span></td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_tec_st(''); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span class="annot_std_gras"><?php echo _('Nombre de clients'); ?></span>
                </td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_cli(''); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span
                        class="annot_std_gras"><?php echo _("Nombre d'interventions"); ?></span></td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_int(''); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span
                        class="annot_std_gras"><?php echo _('Nombre de bons de travail'); ?></span></td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_ot(''); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span class="annot_std_gras"><?php echo _('Nombre de contrats'); ?></span>
                </td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_cocl(''); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span
                        class="annot_std_gras"><?php echo _('Nombre de relevés de parcs'); ?></span></td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_rela(''); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span class="annot_std_gras"><?php echo _("Nombre d'articles"); ?></span>
                </td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_pdt(); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span
                        class="annot_std_gras"><?php echo _('Nombre de locations'); ?></span></td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_coloc(); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span
                        class="annot_std_gras"><?php echo _('Nombre de dossiers de suivi'); ?></span></td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_dos(); ?></span></td>
            </tr>
            <tr>
                <td width="75%" align="right"><span class="annot_std_gras"><?php echo _('Nombre de tâches'); ?></span>
                </td>
                <td align="center"><span class="annot_std_gras"><?php echo nb_tac(0, ''); ?></span></td>
            </tr>
        </table>
        <?php
    }
    include_once 'pied.php';
} else {
    ?>
    <p align="center"><span class="titrepageerr"><?php echo _('PROBLEME DE CONFIGURATION'); ?></span></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <?php
    session_start();
    session_destroy();
    unset($_SESSION);
}
?>
