<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_fic.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/func_txtcm.inc.php';
include_once '../inc/func_mail.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/fic_hum.inc.php';
include_once '../inc/fic_int.inc.php';
include_once '../inc/fic_ope.inc.php';
include_once '../inc/fic_txt.inc.php';
include_once '../classes/phpmailer/class.phpmailer.php';
include_once '../classes/phpmailer/class.smtp.php';
include_once '../inc/mail.inc.php';

include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$datecrea = datetomysql(valpost('datecreaf'));
$dateoutf = valpost('dateoutf');
$dateout = '';
if ($dateoutf <> '') {
    $dateout = datetomysql($dateoutf);
}
$dconges = valpost('dconges');
if ($dconges <> '') {
    $dconges = datetomysql($dconges);
}
$fconges = valpost('fconges');
if ($fconges <> '') {
    $fconges = datetomysql($fconges);
}
$code = valpost('code');
$civil = valpost('civil');
$prenom = ucname(valpost('prenom'));
$nom = str_majuscules(valpost('nom'));
$adr1 = str_majuscules(valpost('adr1'));
$adr2 = str_majuscules(valpost('adr2'));
$dep = str_majuscules(valpost('dep'));
$ville = str_majuscules(valpost('ville'));
$pays = str_majuscules(valpost('pays'));
$telf = valpost('telf');
$telp = valpost('telp');
$email = strtolower(valpost('email'));
$nota = valpost('nota');

$codecrea = valsession('code_log');

$pass = cremdp(FALSE);
$passcrypt = md5($pass);

$retourliste = TRUE;

switch ($td) {
    // Ajout de la fiche Technicien
    case 'add' :
        $codeo = crecode('O');

        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

        $rech = 'SELECT COUNT(*) FROM `' . TBOPE . "` WHERE ope_code = '$codeo'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $rech = 'INSERT INTO `' . TBOPE . '`';
            $rech .= ' (ope_datecrea,ope_codecrea,ope_datemod,ope_congd,ope_congf,ope_code,ope_pass,ope_civilite,';
            $rech .= 'ope_prenom,ope_nom,ope_adr1,ope_adr2,ope_dep,ope_ville,ope_codepays,ope_telf,ope_telp,ope_email,ope_nota,ope_out,ope_dateout) VALUES';
            $rech .= " ('$datea','$codecrea','$datea','$dconges','$fconges','$codeo','$passcrypt','$civil','";
            $rech .= $db->escape($prenom) . "','" . $db->escape($nom) . "','";
            $rech .= $db->escape($adr1) . "','" . $db->escape($adr2) . "','";
            $rech .= $db->escape($dep) . "','$ville','$pays','$telf','$telp','$email','" . $db->escape($nota) . "','','')";
            $db->query($rech);

            // Ajout du compte pour connexion
            // Niveau par défaut : 2
            // Actif par défaut

            $log_ip = $_SERVER['REMOTE_ADDR']; // Récupération adresse IP
            $rech2 = 'INSERT INTO `' . TBPW . "` (pw_code,pw_pass,pw_level,pw_lastsuccess,pw_lastip,pw_actif) VALUES ('$codeo','$passcrypt','2','$dateheurea','$log_ip','1')";
            $db->query($rech2);

            $msg = _('Fiche ajoutée');
        } else {
            $msg = _('Ce code existe déjà');
            $retourliste = FALSE;
        }

        close_database();

        if ($retourliste == TRUE) {
            // Envoi d'email vers l'Opérateur
            envoi_mail('', _('Création de votre compte Opérateur'), 'ope', 'cre', 'xxx', 'ope', $codeo, $pass, '', TRUE);
        }
        break;

    // MAJ de la fiche Opérateur
    case 'edit' :
        if (datetolocal($dateout) <> '') // Si l'Opérateur n'est plus salarié, quelques contrôles sont nécessaires
        {
            // Plus besoin de dates de congés si licencié
            $dconges = '';
            $fconges = '';
            $parti = 1;
        }

        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

        $rech = 'UPDATE `' . TBOPE . "` SET `ope_datemod`='" . $datea . "', `ope_congd`='" . $dconges . "', `ope_congf`='" . $fconges . "',";
        $rech .= " `ope_civilite`='" . $civil . "', `ope_prenom`='" . $db->escape($prenom) . "', `ope_nom`='" . $db->escape($nom) . "', `ope_adr1`='" . $db->escape($adr1) . "',";
        $rech .= " `ope_adr2`='" . $db->escape($adr2) . "', `ope_dep`='" . $db->escape($dep) . "', `ope_ville`='" . $ville . "', `ope_codepays`='" . $pays . "',";
        $rech .= " `ope_telf`='" . $telf . "', `ope_telp`='" . $telp . "', `ope_email`='" . $email . "', `ope_nota`='" . $db->escape($nota) . "',";
        $rech .= " `ope_out`='" . $parti . "', `ope_dateout`='" . $dateout . "'  WHERE `ope_code` = '" . $db->escape($code) . "'";
        $db->query($rech);

        if (datetolocal($dateout) <> '') {
            // Désactivation du mot de passe rattaché
            $rech = 'UPDATE `' . TBPW . "` SET `pw_actif`='0'  WHERE `pw_code` = '" . $db->escape($code) . "'";
            $db->query($rech);
        }

        close_database();

        $msg = _('Fiche modifiée');
        break;

    // Suppression de la fiche Opérateur
    case 'del' :
        // Vérifie si utilisé dans une fiche intervention
        if (exist_in_int_codecrea($code) == TRUE) {
            $msg = _('Cet Opérateur a déjà saisi des interventions (vous ne pouvez ne pouvez pas le supprimer)') . '<br />' . _("Il suffit de le noter 'licencié'");
            $retourliste = FALSE;
        } else {
            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

            $rech = 'DELETE FROM `' . TBOPE . "` WHERE `ope_code` = '" . $db->escape($code) . "'";
            $db->query($rech);

            // Suppression du mot de passe rattaché
            $rech = 'DELETE FROM `' . TBPW . "` WHERE `pw_code` = '" . $db->escape($code) . "'";
            $db->query($rech);

            close_database();

            $msg = _('Fiche supprimée');
        }
        break;
    default :
        $msg = _('Problème de paramètres');
        $retourliste = FALSE;
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche Opérateur'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            <?php
            if ($retourliste == FALSE)
                {echo "warn_txt('" . str_escape($msg) . "');";}
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>
<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    aff_ret_idx_man($td, 'ope_lst.php', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'ope_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>