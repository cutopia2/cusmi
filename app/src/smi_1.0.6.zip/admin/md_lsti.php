<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Impression Liste Modes de Demandes'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            warn_print(1);
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>


</head>

<body>

<?php
entimplst(_('MODES DE DEMANDES'));

$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

$rech = cree_strrechlstmd();
$rech .= crestr_triord($md_titre_col, 'md_code', FALSE, $limit);

$rows = $db->get_results($rech, ARRAY_A);

$numrows = count($rows); // Nombre de résultats à la requête

// *** Affichage de la table
echo '<table class="MItable" border="0" width="100%" cellpadding="0" cellspacing="0">';

// création entête
titimplst($md_titre_col);

// création des lignes
foreach ($rows as $row) {
    $row = encode_str($row);
    echo '<tr>';
    echo '<td>' . $row['md_code'] . '</td>';
    echo '<td>' . $row['md_nom'] . '</td>';
}
echo '</table>';
// *** Fin affichage de la table


close_database();
?>
</body>
</html>