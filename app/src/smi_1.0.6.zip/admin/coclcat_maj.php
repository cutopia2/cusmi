<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_cocl.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$td = $_GET['td'];
$coderech = $_GET['code'];

$pbm_coclcat = FALSE;

if ($coderech <> '') {
    $row = lit_enr_coclcat($coderech);
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);
    } else {
        $pbm_coclcat = TRUE;
    }
} else {
    if ($td <> 'add') {
        $pbm_coclcat = TRUE;
    }
}

$titre = '';
if ($pbm_coclcat == FALSE) {
    switch ($td) {
        case 'add' :
            $titre = _('CREATION CATEGORIE CONTRAT');
            $coclcat_typarr = 3;
            break;
        case 'edit' :
            $titre = _('MISE A JOUR CATEGORIE CONTRAT');
            break;
        case 'del' :
            $titre = _('SUPPRESSION CATEGORIE CONTRAT');
            break;
        default :
            $pbm_coclcat = TRUE;
            break;
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-type=" content="text/html; charset=utf-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche catégorie contrat'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab_champ = ["nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?> ; lmn:1 ; lmx:10; stok:frmok ; stbad:frmbad",
            "nom:desc ; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?>; lmn:1 ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:actif ; format:txt ; req:Y ; txt:<?php echo _('Actif'); ?>; lmn:1 ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:pourm ; format:reel_ns ; req:Y ; txt:<?php echo _('Pourcentage hausse manuelle'); ?>; lmn:1 ; lmx:10; stok:frmok ; stbad:frmbad",
            "nom:pour1 ; format:reel_ns ; req:Y ; txt:<?php echo _('Pourcentage hausse auto. n°1'); ?>; lmn:1 ; lmx:10; stok:frmok ; stbad:frmbad",
            "nom:pour2 ; format:reel_ns ; req:Y ; txt:<?php echo _('Pourcentage hausse auto. n°2'); ?>; lmn:1 ; lmx:10; stok:frmok ; stbad:frmbad",
            "nom:pour3 ; format:reel_ns ; req:Y ; txt:<?php echo _('Pourcentage hausse auto. n°3'); ?>; lmn:1 ; lmx:10; stok:frmok ; stbad:frmbad"];

        //-->
    </script>

    <?php if ($pbm_coclcat == FALSE) { ?>
        <script type="text/javascript">
            <!--
            $(function () {
                $("#code").Setcase({caseValue: 'upper', changeonFocusout: true});
                $("#desc").Setcase({caseValue: 'upper', changeonFocusout: true});
            });

            function init_all() {
                init_Body();
                init_fdeci('pourm', 2, '');
                init_fdeci('pour1', 2, '');
                init_fdeci('pour2', 2, '');
                init_fdeci('pour3', 2, '');
                <?php
                switch ($td)
                {
                    case 'add' :
                        echo "init_valid_form('enr','coclcat_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                        break;
                    case 'edit' :
                        echo "init_valid_form('enr','coclcat_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                        echo "readonly_id('code',false);";
                        break;
                    case 'view' :
                    case 'del' :
                        echo 'readonly_all();';
                        if ($td=='del') {echo "warn_del('');";}
                        break;
                }
                ?>
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';
if ($pbm_coclcat == FALSE) {
    cre_ent_form($titre, 'coclcat_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="coclcat_maj" method="post" id="coclcat_maj" action="coclcat_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="10%" class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                <td width="47%">
                    <?php if ($td == 'add') { ?>
                        <input name="code" type="text" id="code" value="<?php echo $coclcat_code ?>" size="10">
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    <?php } else { ?>
                    <input name="code" type="text" id="code" value="<?php echo $coclcat_code ?>" size="5" readonly="1">
                </td>
                <?php } ?>
            </tr>
            <tr>
                <td class="rubfrm" id="f_desc" align="right"><?php echo _('Libellé'); ?></td>
                <td><input name="desc" type="text" id="desc" value="<?php echo $coclcat_desc; ?>" size="50">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_actif" align="right"><?php echo _('Modèle par défaut'); ?></td>
                <td>
                    <?php
                    cre_select('default', 'default', $non_oui, (int)$coclcat_default);
                    echo '<div class="annot_petit_it">';
                    echo _('La catégorie par défaut sera celle qui sera proposée lors des créations de contrats');
                    echo '</div>';
                    ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_actif" align="right"><?php echo _('Actif'); ?></td>
                <td>
                    <?php
                    cre_select('actif', 'actif', $non_oui, (int)$coclcat_actif);
                    echo '<div class="annot_petit_it">';
                    echo _('Vous ne pouvez pas désactiver une catégorie de contrat déjà utilisée dans un contrat');
                    echo '</div>';
                    ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_typarr" align="right"><?php echo _('Type arrondi'); ?></td>
                <td>
                    <?php
                    cre_select('typarr', 'typarr', $tab_txt_typarr, (int)$coclcat_typarr);
                    ?>
                    <br/><span
                        class="annot_petit_it">(<?php echo _("'Aucun' : aucun arrondi") . '. ' . _("'Inférieur' : Arrondi à l'entier inférieur") . '. ' . _("'Supérieur' : Arrondi à l'entier supérieur") . '. ' . _("'Décimal' : Arrondi à") . ' ' . valsession('num_nbdec') . ' ' . _('décimales'); ?>
                        )</span>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_codeper" align="right"><?php echo _('Période de référence'); ?></td>
                <td>
                    <?php
                    $tab_per = [];
                    // Création de la liste des périodicités
                    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                    $rech = 'SELECT * FROM `' . TBPER . '` WHERE `per_coclcat` = 1 ORDER BY per_nbj';
                    $rows = $db->get_results($rech, ARRAY_A);

                    if ($rows) {
                        foreach ($rows as $row) {
                            $row = encode_str($row);
                            extract($row);
                            $txt_nbj = '(à la demande)';
                            if ($per_nbj <> 0) {
                                $txt_nbj = '(tous les ' . $per_nbj . ' jours)';
                            }
                            $tab_per[$per_code] = $per_desc . ' ' . $txt_nbj;
                        }
                    }
                    close_database();
                    cre_select('codeper', 'codeper', $tab_per, $coclcat_codeper);
                    ?>
                </td>
            </tr>
        </table>
        <table width="100%" border="0">
            <tr>
                <td class="rubfrm" id="f_titprmhaussesr" align="center"
                    colspan="2"><?php echo _('Paramétrage des hausses sur renouvellements'); ?></td>
            </tr>
            <tr>
                <td class="annot_petit_it" id="f_detprmhaussesr" align="center" colspan="2">
                    (<?php echo _("Ces taux permettront, soit en cas de renouvellement manuel, d'afficher une proposition de nouveau tarif, soit en cas de renouvellement automatique, de calculer les nouveaux tarifs"); ?>
                    )
                </td>
            </tr>
            <tr>
                <td class="annot_std_gras" id="f_titprmhaussesrdet" align="center"
                    colspan="2"><?php echo _('Paramétrage de la hausse (pourcentage) à appliquer en cas de renouvellement manuel'); ?></td>
            </tr>
            <tr>
                <td width="40%" class="rubfrm" id="f_infpourm"
                    align="right"><?php echo _('Sur renouvellement manuel'); ?></td>
                <td>
                    <?php cre_input_num('pourm', $coclcat_pourm); ?>
                </td>
            </tr>
            <tr>
                <td class="annot_std_gras" id="f_titprmhaussesrdet" align="center"
                    colspan="2"><?php echo _('Paramétrage des hausses (pourcentages) à appliquer en cas de renouvellement automatique'); ?></td>
            </tr>
            <tr>
                <td width="40%" class="rubfrm" id="f_infp1"
                    align="right"><?php echo _('Inférieur ou égal à 1 fois la période de référence'); ?></td>
                <td>
                    <?php cre_input_num('pour1', $coclcat_pour1); ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_infp2"
                    align="right"><?php echo _('Inférieur ou égal à 2 fois et supérieur à 1 fois la période de référence'); ?></td>
                <td>
                    <?php cre_input_num('pour2', $coclcat_pour2); ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_infp3"
                    align="right"><?php echo _('Supérieur à 2 fois la période de référence'); ?></td>
                <td>
                    <?php cre_input_num('pour3', $coclcat_pour3); ?>
                </td>
            </tr>
        </table>
        <p align="center">
            <?php if (($td == 'add') || ($td == 'edit')) { ?>
                <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="<?php echo _('Réinitialiser'); ?>">
                <input name="enr" type="button" class="bton_std" id="enr" value="<?php echo _('Enregistrer'); ?>">
            <?php } ?>
            <?php if ($td == 'del') { ?>
                <input name="del" type="submit" class="bton_std" id="del" value="<?php echo _('Supprimer'); ?>">
            <?php } ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'coclcat_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>