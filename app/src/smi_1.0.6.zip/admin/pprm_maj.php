<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_age.inc.php';
include_once '../inc/fic_cli.inc.php';
include_once '../inc/fic_cocl.inc.php';
include_once '../inc/fic_dde.inc.php';
include_once '../inc/fic_dos.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/fic_loc.inc.php';
include_once '../inc/fic_ope.inc.php';
include_once '../inc/fic_ot.inc.php';
include_once '../inc/fic_rel.inc.php';
include_once '../inc/fic_ret.inc.php';
include_once '../inc/fic_tac.inc.php';
include_once '../inc/fic_tec.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));

// Lecture des paramètres planning
$row = lit_enr_pprm();
if ($row) {
    $row = encode_str($row);
    extract($row);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Paramètres planning'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab1_champ = ["nom:modeplan ; format:liste ; req:Y ; txt:<?php echo _('Mode plan par défaut'); ?> ; stok:frmok ; stbad:frmbad",
            "nom:firsthour ; format:unsigned ; req:Y ; txt:<?php echo _('Première heure affichée'); ?> ; lmn:1 ; lmx:2 ; vmx:24 ; stok:frmok ; stbad:frmbad",
            "nom:lasthour ; format:unsigned ; req:Y ; txt:<?php echo _('Dernière heure affichée'); ?> ; lmn:1 ; lmx:2 ; vmx:24 ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            <?php
            echo "init_valid_form('enr','pprm_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php
include_once '../inc/entete.inc.php';
cre_ent_form(_('PARAMETRES PLANNING'), '', '', '', FALSE);
?>
<form name="pprm_maj" id="pprm_maj" method="post" action="pprm_enr.php">
    <input name="nbutton" type="hidden" id="nbutton" value="">
    <table width="40%" border="0" align="center">
        <tr>
            <td class="rubfrm" id="f_modeplan" align="right"><?php echo _('Mode plan par défaut'); ?></td>
            <td>
                <?php
                cre_select('modeplan', 'modeplan', $pla_mode, $pprm_modeplan);
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_firsthour" align="right"><?php echo _('Première heure affichée'); ?></td>
            <td>
                <input name="firsthour" type="text" id="firsthour" value="<?php echo $pprm_firsthour ?>" size="4">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_lasthour" align="right"><?php echo _('Dernière heure affichée'); ?></td>
            <td>
                <input name="lasthour" type="text" id="lasthour" value="<?php echo $pprm_lasthour ?>" size="4">
            </td>
        </tr>
    </table>
    <p align="center">
        <?php
        echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Valider') . '">';
        echo ' <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="' . _('Réinitialiser') . '">';
        ?>
    </p>
</form>
<?php
include_once 'pied.php';
?>
</body>
</html>