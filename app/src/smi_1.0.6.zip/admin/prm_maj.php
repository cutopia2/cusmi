<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_age.inc.php';
include_once '../inc/fic_cli.inc.php';
include_once '../inc/fic_cocl.inc.php';
include_once '../inc/fic_dde.inc.php';
include_once '../inc/fic_dos.inc.php';
include_once '../inc/fic_loc.inc.php';
include_once '../inc/fic_ope.inc.php';
include_once '../inc/fic_ot.inc.php';
include_once '../inc/fic_plan.inc.php';
include_once '../inc/fic_prm.inc.php';
include_once '../inc/fic_prmmail.inc.php';
include_once '../inc/fic_rel.inc.php';
include_once '../inc/fic_ret.inc.php';
include_once '../inc/fic_tac.inc.php';
include_once '../inc/fic_tec.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));

$codeprm = '';
if (isset($_GET['prm'])) {
    $codeprm = $_GET['prm'];
}

// Lecture des paramètres planning
$row = lit_enr_pprm();
if ($row) {
    $row = encode_str($row);
    extract($row);
}

// Lecture des constantes / paramètres
$row = lit_enr_cons();
if ($row) {
    $row = encode_str($row);
    extract($row);
}

// Lecture des constantes / paramètres mail
$row = lit_enr_consmail();
if ($row) {
    $row = encode_str($row);
    extract($row);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Paramètres'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>
    <?php
    switch ($codeprm)
    {
        case 'num' :
            $ntab = 0;
            break;
        case 'cocl' :
            $ntab = 1;
            break;
        case 'int' :
            $ntab = 2;
            break;
        case 'pla' :
            $ntab = 3;
            break;
        case 'prm' :
            $ntab = 4;
            break;
        default :
            break;
    }
    ?>

    <script language="javascript">
        <!--
        const tab_champ = ["nom:relmin ; format:unsigned ; req:Y ; txt:<?php echo _('Minimum pour les préavis'); ?> ; lmx:3 ; stok:frmok ; stbad:frmbad",
            "nom:relmax ; format:unsigned ; req:Y ; txt:<?php echo _('Maximum pour les préavis'); ?> ; lmx:3 ; stok:frmok ; stbad:frmbad",
            "nom:rtec ; format:alphanum ; req:Y ; txt:<?php echo _('Techniciens'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ntec ; format:unsigned ; req:Y ; txt:<?php echo _('Techniciens'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rcli ; format:alphanum ; req:Y ; txt:<?php echo _('Clients'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ncli ; format:unsigned ; req:Y ; txt:<?php echo _('Clients'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rint ; format:alphanum ; req:Y ; txt:<?php echo _('Interventions'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nint ; format:unsigned ; req:Y ; txt:<?php echo _('Interventions'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rope ; format:alphanum ; req:Y ; txt:<?php echo _('Opérateurs téléphoniques'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nope ; format:unsigned ; req:Y ; txt:<?php echo _('Opérateurs téléphoniques'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rcon ; format:alphanum ; req:Y ; txt:<?php echo _('Contrats'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ncon ; format:unsigned ; req:Y ; txt:<?php echo _('Contrats'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rdde ; format:alphanum ; req:Y ; txt:<?php echo _('Demandes'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ndde ; format:unsigned ; req:Y ; txt:<?php echo _('Demandes'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rrel ; format:alphanum ; req:Y ; txt:<?php echo _('Dossiers de Relevés'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nrel ; format:unsigned ; req:Y ; txt:<?php echo _('Dossiers de Relevés'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rrlic ; format:alphanum ; req:Y ; txt:<?php echo _('Relevés de licences'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nrlic ; format:unsigned ; req:Y ; txt:<?php echo _('Relevés de licences'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rrpdt ; format:alphanum ; req:Y ; txt:<?php echo _('Relevés de matériels'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nrpdt ; format:unsigned ; req:Y ; txt:<?php echo _('Relevés de matériels'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rord ; format:alphanum ; req:Y ; txt:<?php echo _('Ordres de travail'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nord ; format:unsigned ; req:Y ; txt:<?php echo _('Ordres de travail'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rretp ; format:alphanum ; req:Y ; txt:<?php echo _('Produit à retourner'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nretp ; format:unsigned ; req:Y ; txt:<?php echo _('Produit à retourner'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rrete ; format:alphanum ; req:Y ; txt:<?php echo _('Envois de retours produits'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nrete ; format:unsigned ; req:Y ; txt:<?php echo _('Envois de retours produits'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rloc ; format:alphanum ; req:Y ; txt:<?php echo _('Contrats de locations'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nloc ; format:unsigned ; req:Y ; txt:<?php echo _('Contrats de locations'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rdos ; format:alphanum ; req:Y ; txt:<?php echo _('Dossiers de suivi'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ndos ; format:unsigned ; req:Y ; txt:<?php echo _('Dossiers de suivi'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rtac ; format:alphanum ; req:Y ; txt:<?php echo _('Tâches'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ntac ; format:unsigned ; req:Y ; txt:<?php echo _('Tâches'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nivtrace ; format:liste ; req:Y ; txt:<?php echo _('Traçabilité'); ?> ; vmn:0 ; stok:frmok ; stbad:frmbad",
            <?php if ($mod_planning == TRUE) { ?>
            "nom:modeplan ; format:liste ; req:Y ; txt:<?php echo _('Mode plan par défaut'); ?> ; stok:frmok ; stbad:frmbad",
            "nom:firsthour ; format:unsigned ; req:Y ; txt:<?php echo _('Première heure affichée'); ?> ; lmn:1 ; lmx:2 ; vmx:24 ; stok:frmok ; stbad:frmbad",
            "nom:lasthour ; format:unsigned ; req:Y ; txt:<?php echo _('Dernière heure affichée'); ?> ; lmn:1 ; lmx:2 ; vmx:24 ; stok:frmok ; stbad:frmbad",
            <?php } ?>
            "nom:intpolpied ; format:unsigned ; req:Y ; txt:<?php echo _('Interventions - Taille police pied'); ?>; lmn:1 ; lmx:2; vmn:1; vmx:16; stok:frmok ; stbad:frmbad",
            "nom:intpolcgv ; format:unsigned ; req:Y ; txt:<?php echo _('Interventions - Taille police CGV'); ?>; lmn:1 ; lmx:2; vmn:1; vmx:16; stok:frmok ; stbad:frmbad",
            "nom:colocpolcgv ; format:unsigned ; req:Y ; txt:<?php echo _('Locations - Taille police CGV'); ?>; lmn:1 ; lmx:2; vmn:1; vmx:16; stok:frmok ; stbad:frmbad",
            "nom:coclpolcgv ; format:unsigned ; req:Y ; txt:<?php echo _('Contrats - Taille police CGV'); ?>; lmn:1 ; lmx:2; vmn:1; vmx:16; stok:frmok ; stbad:frmbad",
            "nom:retdpolpied ; format:unsigned ; req:Y ; txt:<?php echo _('Retours demandes - Taille police pied'); ?>; lmn:1 ; lmx:2; vmn:1; vmx:16; stok:frmok ; stbad:frmbad",
            "nom:retepolpied; format:unsigned ; req:Y ; txt:<?php echo _('Retours envois - Taille police pied'); ?>; lmn:1 ; lmx:2; vmn:1; vmx:16; stok:frmok ; stbad:frmbad",
            "nom:pour1 ; format:reel_ns ; req:Y ; txt:<?php echo _('Pourcentage hausse auto. n°1'); ?>; lmn:1 ; lmx:10; stok:frmok ; stbad:frmbad",
            "nom:codeper ; format:list ; req:Y ; txt:<?php echo _('Périodicité'); ?>; lmn:1 ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:pourm ; format:reel_ns ; req:Y ; txt:<?php echo _('Pourcentage hausse manuelle'); ?>; lmn:1 ; lmx:10; stok:frmok ; stbad:frmbad",
            "nom:pour1 ; format:reel_ns ; req:Y ; txt:<?php echo _('Pourcentage hausse auto. n°1'); ?>; lmn:1 ; lmx:10; stok:frmok ; stbad:frmbad",
            "nom:pour2 ; format:reel_ns ; req:Y ; txt:<?php echo _('Pourcentage hausse auto. n°2'); ?>; lmn:1 ; lmx:10; stok:frmok ; stbad:frmbad",
            "nom:pour3 ; format:reel_ns ; req:Y ; txt:<?php echo _('Pourcentage hausse auto. n°3'); ?>; lmn:1 ; lmx:10; stok:frmok ; stbad:frmbad",
            "nom:intcoupman ; format:unsigned ; req:N ; txt:<?php echo _('Nombre de coupons'); ?>; vmn:1 ; stok:frmok ; stbad:frmbad",
            "nom:admname ; format:txt ; req:Y ; txt:<?php echo _('Nom Administrateur'); ?>; lmn:1 ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:admmail ; format:mail ; req:Y ; txt:<?php echo _('Adresse adminitrateur'); ?>; lmn:1 ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:smtppausem ; format:unsigned ; req:Y ; txt:<?php echo _('Pause entre chaque envoi'); ?>; lmn:1 ; lmx:2; vmn:1; vmx:99; stok:frmok ; stbad:frmbad",
            "nom:smtpnom ; format:url_npref ; req:Y ; txt:<?php echo _('Serveur SMTP'); ?>; lmn:1 ; lmx:50 ; stbad:frmbad",
            "nom:smtpport ; format:unsigned ; req:Y ; txt:<?php echo _('Port serveur SMTP'); ?>; lmn:1 ; lmx:6; vmn:1; vmx:65536; stok:frmok ; stbad:frmbad",
            "nom:smtplogin ; format:txt ; req:N ; txt:<?php echo _('Code serveur SMTP'); ?>; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:smtpmdp ; format:alphanum ; req:N ; txt:<?php echo _('Mot de passe serveur SMTP'); ?>; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:smtpsecure ; format:liste ; req:N ; txt:<?php echo _('Mode sécurité serveur SMTP'); ?>; stok:frmok ; stbad:frmbad",
            "nom:popbefore ; format:liste ; req:N ; txt:<?php echo _('Mode POP before SMTP'); ?>; stok:frmok ; stbad:frmbad",
            "nom:popnom ; format:url_npref ; req:N ; txt:<?php echo _('Serveur POP'); ?>; lmx:50 ; stbad:frmbad",
            "nom:popport ; format:unsigned ; req:N ; txt:<?php echo _('Port serveur POP'); ?>; lmx:6; vmn:1; vmx:65536; stok:frmok ; stbad:frmbad",
            "nom:poptimeout ; format:unsigned ; req:N ; txt:<?php echo _('Timeout du serveur POP'); ?>; lmx:3; vmn:1; vmx:999; stok:frmok ; stbad:frmbad",
            "nom:poplogin ; format:alphanum ; req:N ; txt:<?php echo _('Code serveur POP'); ?>; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:popmdp ; format:alphanum ; req:N ; txt:<?php echo _('Mot de passe serveur POP'); ?>; lmx:50; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            init_Tabs('onglets_prm');
            fdeci('intcoupman', 0);
            init_fdeci('intcoupman', 0);
            <?php
            echo "init_valid_form('enr','prm_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php
include_once '../inc/entete.inc.php';
cre_ent_form(_('PARAMETRES'), '', '', '', FALSE);
?>
<form name="prm_maj" id="prm_maj" method="post" action="prm_enr.php">
    <input type="hidden" name="ntab" id="ntab" value="<?php echo $ntab; ?>">
    <input name="nbutton" type="hidden" id="nbutton" value="">
    <div id="onglets_prm">
        <ul>
            <li><a href="#prm_num"><?php echo _('Numérotation'); ?></a></li>
            <li><a href="#prm_cocl"><?php echo _('Contrats'); ?></a></li>
            <li><a href="#prm_int"><?php echo _('Interventions'); ?></a></li>
            <li><a href="#prm_coloc"><?php echo _('Location'); ?></a></li>
            <?php if ($mod_planning == TRUE) { ?>
            <li><a href="#prm_pla"><?php echo _('Planning'); ?></a></li>
            <?php } ?>
            <li><a href="#prm_tra"><?php echo _('Traçabilité'); ?></a></li>
            <li><a href="#prm_ret"><?php echo _('Retours'); ?></a></li>
            <li><a href="#prm_mail"><?php echo _('Messagerie'); ?></a></li>
        </ul>
        <div id="prm_num">
            <table width="40%" border="0" cellspacing="0" align="center">
                <tr>
                    <td align="center" class="annot_gras_it"><?php echo _('Type de numérotation'); ?></td>
                    <td align="center" class="annot_gras_it" width="80"><?php echo _('Radical'); ?></td>
                    <td align="center" class="annot_gras_it" width="80"><?php echo _('Numéro'); ?></td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_ntec" align="right"><?php echo _('Techniciens'); ?></td>
                    <td>
                        <input name="rtec" type="text" id="rtec" value="<?php echo $cons_rtec ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_tec('') == 0) {
                            ?>
                            <input name="ntec" type="text" id="ntec" value="<?php echo $cons_ntec ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="ntec" type="text" id="ntec" value="<?php echo $cons_ntec ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_ncli" align="right"><?php echo _('Clients'); ?></td>
                    <td>
                        <input name="rcli" type="text" id="rcli" value="<?php echo $cons_rcli ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_cli('') == 0) {
                            ?>
                            <input name="ncli" type="text" id="ncli" value="<?php echo $cons_ncli ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="ncli" type="text" id="ncli" value="<?php echo $cons_ncli ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_nint"><?php echo _('Interventions'); ?></td>
                    <td>
                        <input name="rint" type="text" id="rint" value="<?php echo $cons_rint ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_int('') == 0) {
                            ?>
                            <input name="nint" type="text" id="nint" value="<?php echo $cons_nint ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="nint" type="text" id="nint" value="<?php echo $cons_nint ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_nope"><?php echo _('Opérateurs téléphoniques'); ?></td>
                    <td>
                        <input name="rope" type="text" id="rope" value="<?php echo $cons_rope ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_ope() == 0) {
                            ?>
                            <input name="nope" type="text" id="nope" value="<?php echo $cons_nope ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="nope" type="text" id="nope" value="<?php echo $cons_nope ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_ncon"><?php echo _('Contrats'); ?></td>
                    <td>
                        <input name="rcon" type="text" id="rcon" value="<?php echo $cons_rcon ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_cocl('') == 0) {
                            ?>
                            <input name="ncon" type="text" id="ncon" value="<?php echo $cons_ncon ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="ncon" type="text" id="ncon" value="<?php echo $cons_ncon ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_ncon"><?php echo _('Certificats de destruction'); ?></td>
                    <td>
                        <input name="rcer" type="text" id="rcer" value="<?php echo $cons_rcer ?>" size="10">
                    </td>
                    <td><input name="ncer" type="text" id="ncer" value="<?php echo $cons_ncer ?>" size="10"></td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_ndde"><?php echo _('Demandes'); ?></td>
                    <td>
                        <input name="rdde" type="text" id="rdde" value="<?php echo $cons_rdde ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_dde() == 0) {
                            ?>
                            <input name="ndde" type="text" id="ndde" value="<?php echo $cons_ndde ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="ndde" type="text" id="ndde" value="<?php echo $cons_ndde ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_nrel"><?php echo _('Dossiers de Relevés'); ?></td>
                    <td>
                        <input name="rrel" type="text" id="rrel" value="<?php echo $cons_rrel ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_rela('') == 0) {
                            ?>
                            <input name="nrel" type="text" id="nrel" value="<?php echo $cons_nrel ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="nrel" type="text" id="nrel" value="<?php echo $cons_nrel ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_nrlic"><?php echo _('Relevés de licences'); ?></td>
                    <td>
                        <input name="rrlic" type="text" id="rrlic" value="<?php echo $cons_rrlic ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_rlica('') == 0) {
                            ?>
                            <input name="nrlic" type="text" id="nrlic" value="<?php echo $cons_nrlic ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="nrlic" type="text" id="nrlic" value="<?php echo $cons_nrlic ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_nrpdt"><?php echo _('Relevés de matériels'); ?></td>
                    <td>
                        <input name="rrpdt" type="text" id="rrpdt" value="<?php echo $cons_rrpdt ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_rpdta('') == 0) {
                            ?>
                            <input name="nrpdt" type="text" id="nrpdt" value="<?php echo $cons_nrpdt ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="nrpdt" type="text" id="nrpdt" value="<?php echo $cons_nrpdt ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_nrord"><?php echo _('Ordres de travail'); ?></td>
                    <td>
                        <input name="rord" type="text" id="rord" value="<?php echo $cons_rord ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_ot('') == 0) {
                            ?>
                            <input name="nord" type="text" id="nord" value="<?php echo $cons_nord ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="nord" type="text" id="nord" value="<?php echo $cons_nord ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_nretp"><?php echo _('Produit à retourner'); ?></td>
                    <td>
                        <input name="rretp" type="text" id="rretp" value="<?php echo $cons_rretp ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_retp() == 0) {
                            ?>
                            <input name="nretp" type="text" id="nretp" value="<?php echo $cons_nretp ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="nretp" type="text" id="nretp" value="<?php echo $cons_nretp ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_nrete"><?php echo _('Envois de retours produits'); ?></td>
                    <td>
                        <input name="rrete" type="text" id="rrete" value="<?php echo $cons_rrete ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_rete('') == 0) {
                            ?>
                            <input name="nrete" type="text" id="nrete" value="<?php echo $cons_nrete ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="nrete" type="text" id="nrete" value="<?php echo $cons_nrete ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_nrloc"><?php echo _('Contrats de locations'); ?></td>
                    <td>
                        <input name="rloc" type="text" id="rloc" value="<?php echo $cons_rloc ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_coloc() == 0) {
                            ?>
                            <input name="nloc" type="text" id="nloc" value="<?php echo $cons_nloc ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="nloc" type="text" id="nloc" value="<?php echo $cons_nloc ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_nrdos"><?php echo _('Dossiers de suivi'); ?></td>
                    <td>
                        <input name="rdos" type="text" id="rdos" value="<?php echo $cons_rdos ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_dos() == 0) {
                            ?>
                            <input name="ndos" type="text" id="ndos" value="<?php echo $cons_ndos ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="ndos" type="text" id="ndos" value="<?php echo $cons_ndos ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" align="right" id="f_nrtac"><?php echo _('Tâches'); ?></td>
                    <td>
                        <input name="rtac" type="text" id="rtac" value="<?php echo $cons_rtac ?>" size="10">
                    </td>
                    <td>
                        <?php
                        if (nb_tac(0, '') == 0) {
                            ?>
                            <input name="ntac" type="text" id="ntac" value="<?php echo $cons_ntac ?>" size="10">
                            <?php
                        } else {
                            ?>
                            <input name="ntac" type="text" id="ntac" value="<?php echo $cons_ntac ?>" size="10" readonly>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
            </table>
        </div>
        <div id ="prm_cocl">
            <div class="title_box" id="cocl_polices">
                <div id="title"><?php echo _('Tailles polices'); ?></div>
                <div class="annot_petit_it" align="center"><?php echo _("Ces paramètres permettent de décider de la taille des caratères lors de l'impression de certains textes d'un contrat de maintenance"); ?></div>
                <table width="30%" border="0" align="center">
                    <tr>
                        <td class="rubfrm" id="f_coclpolcgv" align="right"><?php echo _('Taille police du texte conditions générales de vente'); ?></td>
                        <td>
                            <?php
                            echo '<input name="coclpolcgv" type="text" id="coclpolcgv" value="'.(int)$cons_cocl_polcgv.'" size="2">';
                            echo '<div class="annot_petit_it">';
                            echo _('Entre 1 et 16');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
            <br />
            <div class="title_box" id="cocl_preavis">
                <div id="title"><?php echo _('Préavis de relance sur les contrats'); ?></div>
                <table width="100%" border="0" cellspacing="0" align="center">
                <tr>
                    <td class="rubfrm" width="180" id="f_relmin" align="right"><?php echo _('Minimum pour les préavis'); ?></td>
                    <td>
                        <input name="relmin" type="text" id="relmin" value="<?php echo $cons_relmin ?>" size="10">
                        <br />
                        <div class="annot_petit_it"><?php echo _('Minimum = nombre de jours à partir desquels on peut commencer à relancer'); ?></div>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_relmax" align="right"><?php echo _('Maximum pour les préavis'); ?></td>
                    <td>
                        <input name="relmax" type="text" id="relmax" value="<?php echo $cons_relmax ?>" size="10">
                        <div class="annot_petit_it"><?php echo _('Maximum = nombre de jours à partir desquels on ne peut plus relancer'); ?></div>
                    </td>
                </tr>
                </table>
            </div>
            <br />
            <div class="title_box" id="cocl_renouv">
                <div id="title"><?php echo _('Paramètres de renouvellement par défaut'); ?></div>
                <div class="annot_petit_it" align="center"><?php echo _('Ces paramètres sont ceux repris, si demandé, dans les renouvellements des contrats sans catégorie'); ?></div>
                <table width="100%" border="0">
                    <tr>
                        <td class="rubfrm" id="f_coclrenactif" align="right"><?php echo _('Actif'); ?></td>
                        <td>
                            <?php
                            cre_select('coclrenactif', 'coclrenactif', $non_oui, (int)$cons_coclcat_default);
                            echo '<div class="annot_petit_it">';
                            echo _("Si 'oui', ces paramètres seront appliqués aux renouvellements des contrats sans catégorie");
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_typarr" align="right"><?php echo _('Type arrondi'); ?></td>
                        <td>
                            <?php
                            cre_select('typarr', 'typarr', $tab_txt_typarr, (int)$cons_coclcat_typarr);
                            ?>
                            <br/><span
                                class="annot_petit_it">(<?php echo _("'Aucun' : aucun arrondi") . '. ' . _("'Inférieur' : Arrondi à l'entier inférieur") . '. ' . _("'Supérieur' : Arrondi à l'entier supérieur") . '. ' . _("'Décimal' : Arrondi à") . ' ' . valsession('num_nbdec') . ' ' . _('décimales'); ?>
                                )</span>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_codeper" align="right"><?php echo _('Période de référence'); ?></td>
                        <td>
                            <?php
                            $tab_per = [];
                            // Création de la liste des périodicités
                            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                            $rech = 'SELECT * FROM `' . TBPER . '` WHERE `per_coclcat` = 1 ORDER BY per_nbj';
                            $rows = $db->get_results($rech, ARRAY_A);

                            if ($rows) {
                                foreach ($rows as $row) {
                                    $row = encode_str($row);
                                    extract($row);
                                    $txt_nbj = '(à la demande)';
                                    if ($per_nbj <> 0) {
                                        $txt_nbj = '(tous les ' . $per_nbj . ' jours)';
                                    }
                                    $tab_per[$per_code] = $per_desc . ' ' . $txt_nbj;
                                }
                            }
                            close_database();
                            cre_select('codeper', 'codeper', $tab_per, $cons_coclcat_codeper);
                            ?>
                        </td>
                    </tr>
                </table>
                <table width="100%" border="0">
                    <tr>
                        <td class="rubfrm" id="f_titprmhaussesr" align="center"
                            colspan="2"><?php echo _('Paramétrage des hausses sur renouvellements'); ?></td>
                    </tr>
                    <tr>
                        <td class="annot_petit_it" id="f_detprmhaussesr" align="center" colspan="2">
                            (<?php echo _("Ces taux permettront, soit en cas de renouvellement manuel, d'afficher une proposition de nouveau tarif, soit en cas de renouvellement automatique, de calculer les nouveaux tarifs"); ?>
                            )
                        </td>
                    </tr>
                    <tr>
                        <td class="annot_std_gras" id="f_titprmhaussesrdet" align="center"
                            colspan="2"><?php echo _('Paramétrage de la hausse (pourcentage) à appliquer en cas de renouvellement manuel'); ?></td>
                    </tr>
                    <tr>
                        <td width="40%" class="rubfrm" id="f_infpourm"
                            align="right"><?php echo _('Sur renouvellement manuel'); ?></td>
                        <td>
                            <?php cre_input_num('pourm', $cons_coclcat_pourm); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="annot_std_gras" id="f_titprmhaussesrdet" align="center"
                            colspan="2"><?php echo _('Paramétrage des hausses (pourcentages) à appliquer en cas de renouvellement automatique'); ?></td>
                    </tr>
                    <tr>
                        <td width="40%" class="rubfrm" id="f_infp1"
                            align="right"><?php echo _('Inférieur ou égal à 1 fois la période de référence'); ?></td>
                        <td>
                            <?php cre_input_num('pour1', $cons_coclcat_pour1); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_infp2"
                            align="right"><?php echo _('Inférieur ou égal à 2 fois et supérieur à 1 fois la période de référence'); ?></td>
                        <td>
                            <?php cre_input_num('pour2', $cons_coclcat_pour2); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_infp3"
                            align="right"><?php echo _('Supérieur à 2 fois la période de référence'); ?></td>
                        <td>
                            <?php cre_input_num('pour3', $cons_coclcat_pour3); ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div id ="prm_int">
            <div class="title_box" id="int_polices">
                <div id="title"><?php echo _('Tailles polices'); ?></div>
                <div class="annot_petit_it" align="center"><?php echo _("Ces paramètres permettent de décider de la taille des caratères lors de l'impression de certains textes d'une intervention"); ?></div>
                <table width="30%" border="0" align="center">
                    <tr>
                        <td class="rubfrm" id="f_intpolpied" align="right"><?php echo _('Taille police du texte de pied'); ?></td>
                        <td>
                            <?php
                            echo '<input name="intpolpied" type="text" id="intpolpied" value="'.(int)$cons_int_polpied.'" size="2">';
                            echo '<div class="annot_petit_it">';
                            echo _('Entre 1 et 16');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_intpolcgv" align="right"><?php echo _('Taille police du texte conditions générales de vente'); ?></td>
                        <td>
                            <?php
                            echo '<input name="intpolcgv" type="text" id="intpolcgv" value="'.(int)$cons_int_polcgv.'" size="2">';
                            echo '<div class="annot_petit_it">';
                            echo _('Entre 1 et 16');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
            <br />
            <div class="title_box" id="int_coupons">
                <div id="title"><?php echo _('Coupons'); ?></div>
                <div class="annot_petit_it" align="center"><?php echo _("Ces paramètres permettent de déterminer si vous souhaitez imprimer des coupons lors de l'impression d'une intervention"); ?></div>
                <table width="40%" border="0" align="center">
                    <tr>
                        <td class="rubfrm" id="f_intcoupactif" align="right"><?php echo _('Actif'); ?></td>
                        <td>
                            <?php
                            cre_select('intcoupactif', 'intcoupactif', $non_oui, (int)$cons_int_coupactif);
                            echo '<div class="annot_petit_it">';
                            echo _("Si 'oui', ces paramètres seront appliqués lors des impressions d'interventions, en création");
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_intcoupc" align="right"><?php echo _('Coupon client ?'); ?></td>
                        <td>
                            <?php
                            cre_select('intcoupc', 'intcoupc', $non_oui, (int)$cons_int_coupc);
                            echo '<div class="annot_petit_it">';
                            echo _("Si 'oui', un coupon, à destination du client, sera imprimé, en création d'intervention");
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_intcoupm" align="right"><?php echo _('Coupon(s) matériel(s) ?'); ?></td>
                        <td>
                            <?php
                            cre_select('intcoupm', 'intcoupm', $non_oui, (int)$cons_int_coupm);
                            echo '<div class="annot_petit_it">';
                            echo _("Si 'oui', des coupons, pour les matériels, pourront être imprimés, en création d'intervention");
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_intcoupma" align="right"><?php echo _('Mode automatique ?'); ?></td>
                        <td>
                            <?php
                            cre_select('intcoupma', 'intcoupma', $non_oui, (int)$cons_int_coupma);
                            echo ' ';
                            cre_input_num('intcoupman', (int)$cons_int_coupman, FALSE, FALSE, FALSE, TRUE, 5);
                            echo '<div class="annot_petit_it">';
                            echo _("Si 'oui', le nombre de coupons qui suit sera systématique imprimé, pour les matériels");
                            echo '</div>';
                            echo '<div class="annot_petit_it">';
                            echo _("Si 'non', il faudra indiquer le nombre de coupons matériels à imprimer, lors de la saise d'intervention");
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_intcoupsdp" align="right"><?php echo _('Saut de page ?'); ?></td>
                        <td>
                            <?php
                            cre_select('intcoupsdp', 'intcoupsdp', $non_oui, (int)$cons_int_coupsdp);
                            echo '<div class="annot_petit_it">';
                            echo _("Si 'oui', les coupons client et matériels seront imprimés sur 2 pages séparées");
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div id="prm_coloc">
            <div class="title_box" id="coloc_polices">
                <div id="title"><?php echo _('Tailles polices'); ?></div>
                <div class="annot_petit_it" align="center"><?php echo _("Ces paramètres permettent de décider de la taille des caratères lors de l'impression de certains textes d'une location"); ?></div>
                <table width="30%" border="0" align="center">
                    <tr>
                        <td class="rubfrm" id="f_colocpolcgv" align="right"><?php echo _('Taille police du texte conditions générales de vente'); ?></td>
                        <td>
                            <?php
                            echo '<input name="colocpolcgv" type="text" id="colocpolcgv" value="'.(int)$cons_coloc_polcgv.'" size="2">';
                            echo '<div class="annot_petit_it">';
                            echo _('Entre 1 et 16');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <?php if ($mod_planning == TRUE) { ?>
        <div id ="prm_pla">
            <div class="annot_petit_it" align="center"><?php echo _("Ces paramètres sont utilisés dans l'affichage du planning et dans les listes de choix des horaires"); ?></div>
            <table width="40%" border="0" align="center">
                <tr>
                    <td class="rubfrm" id="f_modeplan" align="right"><?php echo _('Mode plan par défaut'); ?></td>
                    <td>
                        <?php
                        cre_select('modeplan', 'modeplan', $pla_mode, $pprm_modeplan);
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_firsthour" align="right"><?php echo _('Première heure affichée'); ?></td>
                    <td>
                        <input name="firsthour" type="text" id="firsthour" value="<?php echo $pprm_firsthour ?>" size="4">
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_lasthour" align="right"><?php echo _('Dernière heure affichée'); ?></td>
                    <td>
                        <input name="lasthour" type="text" id="lasthour" value="<?php echo $pprm_lasthour ?>" size="4">
                    </td>
                </tr>
            </table>
        </div>
        <?php } ?>
        <div id="prm_tra">
            <table width="40%" border="0" cellspacing="0" align="center">
                <tr>
                    <td class="rubfrm" id="f_nivtrace" align="right"><?php echo _('Niveau de traçabilité'); ?> </td>
                    <td>
                        <?php
                        cre_select('nivtrace', 'nivtrace', $niv_trace, (int)$cons_nivtra);
                        ?>
                    </td>
                </tr>
            </table>
        </div>
        <div id ="prm_ret">
            <div class="title_box" id="ret_polices">
                <div id="title"><?php echo _('Tailles polices'); ?></div>
                <div class="annot_petit_it" align="center"><?php echo _("Ces paramètres permettent de décider de la taille des caratères lors de l'impression de certains textes sur les retours"); ?></div>
                <table width="30%" border="0" align="center">
                    <tr>
                        <td class="rubfrm" id="f_retdpolpied" align="right"><?php echo _("Taille police du texte de pied d'une demande de retour"); ?></td>
                        <td>
                            <?php
                            echo '<input name="retdpolpied" type="text" id="retdpolcgv" value="'.(int)$cons_retd_polpied.'" size="2">';
                            echo '<div class="annot_petit_it">';
                            echo _('Entre 1 et 16');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_retepolpied" align="right"><?php echo _("Taille police du texte de pied d'un envoi de retour"); ?></td>
                        <td>
                            <?php
                            echo '<input name="retepolpied" type="text" id="retepolpied" value="'.(int)$cons_rete_polpied.'" size="2">';
                            echo '<div class="annot_petit_it">';
                            echo _('Entre 1 et 16');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div id ="prm_mail">
            <div class="title_box" id="mail_admin">
                <div id="title"><?php echo _('Administrateur'); ?></div>
                <table width="50%" border="0" align="center">
                    <tr>
                        <td width="200" class="rubfrm" id="f_admname" align="right"><?php echo _('Nom administrateur'); ?></td>
                        <td>
                            <?php
                            echo '<input name="admname" type="text" id="admname" value="'.$consmail_admname.'" size="50">';
                            echo '<div class="annot_petit_it">';
                            echo _("Nom affiché pour l'envoi des mails");
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_admmail" align="right"><?php echo _('Adresse administrateur'); ?></td>
                        <td>
                            <?php
                            echo '<input name="admmail" type="text" id="admmail" value="'.$consmail_admmail.'" size="50">';
                            echo '<div class="annot_petit_it">';
                            echo _("Adresse mail affichée pour l'envoi des mails");
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
            <br />
            <div class="title_box" id="mail_emailing">
                <div id="title"><?php echo _('Emailings'); ?></div>
                <table width="50%" border="0" align="center">
                    <tr>
                        <td width="200" class="rubfrm" id="f_smtppausem" align="right"><?php echo _('Pause entre chaque envoi'); ?></td>
                        <td>
                            <?php
                            echo '<input name="smtppausem" type="text" id="smtppausem" value="'.$consmail_smtppausem.'" size="5">';
                            echo '<div class="annot_petit_it">';
                            echo _('Pause en secondes entre chaque envoi de mail');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
            <br />
            <div class="title_box" id="mail_smtp">
                <div id="title"><?php echo _('Paramètres envoi'); ?></div>
                <table width="50%" border="0" align="center">
                    <tr>
                        <td width="200" class="rubfrm" id="f_smtpnom" align="right"><?php echo _('Serveur SMTP'); ?></td>
                        <td>
                            <?php
                            echo '<input name="smtpnom" type="text" id="smtpnom" value="'.$consmail_smtpnom.'" size="50">';
                            echo '<div class="annot_petit_it">';
                            echo _("Serveur d'envoi (SMTP)");
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_smtpport" align="right"><?php echo _('Port serveur SMTP'); ?></td>
                        <td>
                            <?php
                            echo '<input name="smtpport" type="text" id="smtpport" value="'.$consmail_smtpport.'" size="6">';
                            echo '<div class="annot_petit_it">';
                            echo _('Port du serveur SMTP');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_smtplogin" align="right"><?php echo _('Code serveur SMTP'); ?></td>
                        <td>
                            <?php
                            echo '<input name="smtplogin" type="text" id="smtplogin" value="'.$consmail_smtplogin.'" size="50">';
                            echo '<div class="annot_petit_it">';
                            echo _('Utilisé uniquement si serveur SMTP authentifié');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_smtpmdp" align="right"><?php echo _('Mot de passe serveur SMTP'); ?></td>
                        <td>
                            <?php
                            echo '<input name="smtpmdp" type="text" id="smtpmdp" value="'.$consmail_smtpmdp.'" size="50">';
                            echo '<div class="annot_petit_it">';
                            echo _('Utilisé uniquement si serveur SMTP authentifié');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_smtpsecure" align="right"><?php echo _('Mode sécurité serveur SMTP'); ?></td>
                        <td>
                            <?php
                            cre_select('smtpsecure', 'smtpsecure', $smtp_secure, $consmail_smtpsecure);
                            echo '<div class="annot_petit_it">';
                            echo _('Utilisé uniquement si serveur SMTP authentifié');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_popbefore" align="right"><?php echo _('Mode POP before SMTP ?'); ?></td>
                        <td>
                            <?php
                            cre_select('popbefore', 'popbefore', $non_oui, (int)$consmail_popbefore);
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_popnom" align="right"><?php echo _('Serveur POP'); ?></td>
                        <td>
                            <?php
                            echo '<input name="popnom" type="text" id="popnom" value="'.$consmail_popnom.'" size="50">';
                            echo '<div class="annot_petit_it">';
                            echo _('Utilisé uniquement si POP before SMTP');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_popport" align="right"><?php echo _('Port serveur POP'); ?></td>
                        <td>
                            <?php
                            echo '<input name="popport" type="text" id="popport" value="'.$consmail_popport.'" size="6">';
                            echo '<div class="annot_petit_it">';
                            echo _('Utilisé uniquement si POP before SMTP');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_poptimeout" align="right"><?php echo _('Timeout du serveur POP'); ?></td>
                        <td>
                            <?php
                            echo '<input name="poptimeout" type="text" id="poptimeout" value="'.$consmail_poptimeout.'" size="6">';
                            echo '<div class="annot_petit_it">';
                            echo _('En secondes - Utilisé uniquement si POP before SMTP');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_poplogin" align="right"><?php echo _('Code serveur POP'); ?></td>
                        <td>
                            <?php
                            echo '<input name="poplogin" type="text" id="poplogin" value="'.$consmail_poplogin.'" size="50">';
                            echo '<div class="annot_petit_it">';
                            echo _('Utilisé uniquement si POP before SMTP');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_popmdp" align="right"><?php echo _('Mot de passe serveur POP'); ?></td>
                        <td>
                            <?php
                            echo '<input name="popmdp" type="text" id="popmdp" value="'.$consmail_popmdp.'" size="50">';
                            echo '<div class="annot_petit_it">';
                            echo _('Utilisé uniquement si POP before SMTP');
                            echo '</div>';
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

    </div>
    <p align="center">
        <?php
        echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Valider') . '">';
        echo '<input name="RAZ" type="reset" class="bton_std" id="RAZ" value="' . _('Réinitialiser') . '">';
        ?>
    </p>
</form>
<?php
include_once 'pied.php';
?>
</body>
</html>