<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if (CheckURLLog(TRUE) == FALSE) {
    header('Location: ../index.php');
}
if (CheckNivLog('9') == FALSE) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_time.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_age.inc.php';
include_once '../inc/fic_cli.inc.php';
include_once '../inc/fic_tec.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$codec = $_GET['cc']; // Récupération code connecté

$code_ok = TRUE;

if ($codec <> '') {
    // Récupération du niveau utilisateur
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
    $rech = 'SELECT * FROM `' . TBPW . "` WHERE `pw_code` = '" . $db->escape($codec) . "'";
    $row = $db->get_row($rech, ARRAY_A);
    if ($row) {
        $row = encode_str($row);
        extract($row);
    } else {
        $code_ok = FALSE;
    }
    close_database();
    // Récupération des informations
    if ($code_ok == TRUE) {
        if ($pw_actif == 0) {
            $actif = _('Compte désactivé');
        } else {
            $actif = _('Compte actif');
        }
        $ste = '';
        $ctact = '';
        $txt_adr = '';
        $tel = '';
        $fax = '';
        $email = '';
        switch ($pw_level) {
            // Client
            case 1 :
                $row = lit_enr_cli($codec);
                if (is_array($row)) {
                    $row = encode_str($row);
                    extract($row);
                    $titre = _('DETAIL COMPTE LOG CLIENT');
                    $type_u = _('Client');
                    $ste = $cli_ste;
                    $ctact = $cli_civilite . ' ' . $cli_prenom . ' ' . $cli_nom;
                    $txt_adr = $cli_adr1 . "\n";
                    if ($cli_adr2 <> '') {
                        $txt_adr .= $cli_adr2 . "\n";
                    }
                    $txt_adr .= Retournecp_Id($cli_ville) . ' ' . Retourneville_Id($cli_ville);
                    $tel = $cli_telf;
                    $fax = $cli_fax;
                    $email = $cli_email;
                } else {
                    $code_ok = FALSE;
                }
                break;

            // Opérateur
            case 2 :
                $row = lit_enr_cli($codec);
                if (is_array($row)) {
                    $row = encode_str($row);
                    extract($row);
                    $titre = _('DETAIL COMPTE LOG OPERATEUR');
                    $type_u = _('Opérateur');
                    $ctact = $ope_civilite . ' ' . $ope_prenom . ' ' . $ope_nom;
                    $txt_adr = $ope_adr1 . "\n";
                    if ($ope_adr2 <> '') {
                        $txt_adr .= $ope_adr2 . "\n";
                    }
                    $txt_adr .= Retournecp_Id($ope_ville) . ' ' . Retourneville_Id($ope_ville);
                    $tel = $ope_telf;
                    $email = $cli_email;
                } else {
                    $code_ok = FALSE;
                }
                break;

            // Technicien
            case 3 :
            case 7 :
            case 11 :
                $row = lit_enr_tec($codec);
                if (is_array($row)) {
                    $row = encode_str($row);
                    extract($row);
                    $titre = _('DETAIL COMPTE LOG TECHNICIEN');
                    $type_u = _('Technicien');
                    $ctact = $tec_civilite . ' ' . $tec_prenom . ' ' . $tec_nom;
                    $txt_adr = $tec_adr1 . "\n";
                    if ($tec_adr2 <> '') {
                        $txt_adr .= $tec_adr2 . "\n";
                    }
                    $txt_adr .= Retournecp_Id($tec_ville) . ' ' . Retourneville_Id($tec_ville);
                    $tel = $tec_telf;
                    $email = $tec_email;
                } else {
                    $code_ok = FALSE;
                }
                break;

            // Agence
            case 4 :
                $row = lit_enr_age($codec);
                if (is_array($row)) {
                    $row = encode_str($row);
                    extract($row);
                    $titre = _('DETAIL COMPTE LOG AGENCE');
                    $type_u = _('Agence');
                    $ste = $age_nom;
                    $ctact = $age_resp_civilite . ' ' . $age_resp_prenom . ' ' . $age_resp_nom;
                    $txt_adr = $age_adr1 . "\n";
                    if ($age_adr2 <> '') {
                        $txt_adr .= $age_adr2 . "\n";
                    }
                    $txt_adr .= Retournecp_Id($age_ville) . ' ' . Retourneville_Id($age_ville);
                    $tel = $age_telf;
                    $fax = $age_fax;
                    $email = $age_email;
                } else {
                    $code_ok = FALSE;
                }
                break;

            // Centre gestion
            case 5 :
                $row = lit_enr_cdg();
                if (is_array($row)) {
                    $row = encode_str($row);
                    extract($row);
                    $titre = _('DETAIL COMPTE LOG CENTRE DE GESTION');
                    $type_u = _('Centre de gestion');
                    $ste = $cge_nom;
                    $txt_adr = $cge_adr1 . "\n";
                    if ($cge_adr2 <> '') {
                        $txt_adr .= $cge_adr2 . "\n";
                    }
                    $txt_adr .= Retournecp_Id($cge_ville) . ' ' . Retourneville_Id($cge_ville);
                    $tel = $cge_telf;
                    $fax = $cge_fax;
                    $email = $cge_email;
                }
                break;

            // Donneur d'ordres
            case 6 :
                $row = lit_enr_do($codec);
                if (is_array($row)) {
                    $row = encode_str($row);
                    extract($row);
                    $titre = _("DETAIL COMPTE LOG DONNEUR D'ORDRES");
                    $type_u = _("Donneur d'ordres");
                    $ste = $do_nom;
                    $txt_adr = $do_adr1 . "\n";
                    if ($do_adr2 <> '') {
                        $txt_adr .= $do_adr2 . "\n";
                    }
                    $txt_adr .= Retournecp_Id($do_ville) . ' ' . Retourneville_Id($do_ville);
                    $tel = $do_telf;
                    $fax = $do_fax;
                    $email = $do_email;
                } else {
                    $code_ok = FALSE;
                }
                break;

            // Administrateur
            case 9 :
                $titre = _('DETAIL COMPTE LOG ADMINISTRATEUR');
                $type_u = _('Administrateur');
                break;

            // Sous-traitant
            case 10 :
                $row = lit_enr_st($codec);
                if (is_array($row)) {
                    $row = encode_str($row);
                    extract($row);
                    $titre = _('DETAIL COMPTE LOG DONNEUR SOUS-TRAITANT');
                    $type_u = _('Sous-traitant');
                    $ste = $st_nom;
                    $txt_adr = $st_adr1 . "\n";
                    if ($st_adr2 <> '') {
                        $txt_adr .= $st_adr2 . "\n";
                    }
                    $txt_adr .= Retournecp_Id($st_ville) . ' ' . Retourneville_Id($st_ville);
                    $tel = $st_telf;
                    $fax = $st_fax;
                    $email = $st_email;
                } else {
                    $code_ok = FALSE;
                }
                break;

            default :
                $code_ok = FALSE;
                break;
        }
    }

} else {
    $code_ok = FALSE;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Détail compte log'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            add_func_click('ferm', 'sclose', '');
            readonly_all();
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>
<?php
if ($code_ok == TRUE) {
    cre_ent_form($titre, '', '', '', FALSE);
    ?>
    <p align="center"><span class="titre_gras"><?php echo _('Code'); ?> : <?php echo $codec; ?></span></p>
    <br/>
    <table width="100%" border="0">
        <tr>
            <td width="160" class="rubfrm" id="f_typu" align="right"><?php echo _('Type utilisateur'); ?></td>
            <td>
                <input name="typu" type="text" id="typu" value="<?php echo $type_u ?>" size="50">
            </td>
        </tr>
        <tr>
            <td width="160" class="rubfrm" id="f_actif" align="right"><?php echo _('Actif/Inactif'); ?></td>
            <td>
                <input name="actif" type="text" id="actif" value="<?php echo $actif ?>" size="50">
            </td>
        </tr>
        <?php if ($ste <> '') { ?>
            <tr>
                <td width="160" class="rubfrm" id="f_ste" align="right"><?php echo _('Société'); ?></td>
                <td>
                    <input name="ste" type="text" id="ste" value="<?php echo $ste ?>" size="110">
                </td>
            </tr>
        <?php } ?>
        <?php if ($ctact <> '') { ?>
            <tr>
                <td width="160" class="rubfrm" id="f_ctact" align="right"><?php echo _('Contact principal'); ?></td>
                <td>
                    <input name="ctact" type="text" id="ctact" value="<?php echo $ctact ?>" size="110">
                </td>
            </tr>
        <?php } ?>
        <?php if ($txt_adr <> '') { ?>
            <tr>
                <td width="160" class="rubfrm" id="f_adr" align="right"><?php echo _('Adresse'); ?></td>
                <td>
                    <textarea name="adr" id="adr" rows="3"><?php echo $txt_adr; ?></textarea>
                </td>
            </tr>
        <?php } ?>
        <?php if ($tel <> '') { ?>
            <tr>
                <td width="160" class="rubfrm" id="f_tel" align="right"><?php echo _('Téléphone'); ?></td>
                <td>
                    <input name="tel" type="text" id="tel" value="<?php echo $tel ?>" size="25">
                </td>
            </tr>
        <?php } ?>
        <?php if ($fax <> '') { ?>
            <tr>
                <td width="160" class="rubfrm" id="f_fax" align="right"><?php echo _('Télécopieur'); ?></td>
                <td>
                    <input name="fax" type="text" id="fax" value="<?php echo $fax ?>" size="25">
                </td>
            </tr>
        <?php } ?>
        <?php if ($email <> '') { ?>
            <tr>
                <td width="160" class="rubfrm" id="f_mail" align="right"><?php echo _('Email'); ?></td>
                <td>
                    <input name="mail" type="text" id="mail" value="<?php echo $email ?>" size="50">
                </td>
            </tr>
        <?php } ?>
    </table>

    <!-- bouton de fermeture de la fenêtre -->
    <p align="center">
        <input name="ferm" type="button" class="bton_std" id="ferm" value="<?php echo _('Quitter'); ?>">
    </p>
    <?php
}/* else
    close_fen_auto('', '', '');*/
?>
</body>
</html>
