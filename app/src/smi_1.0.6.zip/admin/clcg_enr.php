<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$code = str_majuscules(valpost('code'));
$desc = str_majuscules(valpost('desc'));

$tab_clc = [];
$tabtmp_clc = $_POST['clcclcg'];
if (count($tabtmp_clc) > 0) {
    foreach ($tabtmp_clc as $selval) {
        if ($selval <> '') {
            $tab_clc[] = $selval;
        }
    }
}

$retourliste = TRUE;

$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
switch ($td) {
    // Ajout de la fiche groupement champs Check-List
    case 'add' :
        $rech = 'SELECT COUNT(*) FROM `' . TBCLCG . "` WHERE `clcg_code` = '" . $db->escape($code) . "'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $rech = 'INSERT INTO `' . TBCLCG . '` (clcg_code,clcg_desc)';
            $rech .= " VALUES ('" . $db->escape($code) . "','" . $db->escape($desc) . "')";
            $db->query($rech);

            // Ajout des champs check-list
            if (count($tab_clc) > 0) {
                foreach ($tab_clc as $key => $clc) {
                    if (trim($clc) <> '') {
                        $rech2 = 'INSERT INTO `' . TBCLCCLCG . '` (clcclcg_codeclc,clcclcg_codeclcg) VALUES';
                        $rech2 .= " ('" . $db->escape($clc) . "','" . $db->escape($code) . "')";
                        $db->query($rech2);
                    }
                }
            }

            $msg = _('Fiche ajoutée');
        } else {
            $msg = _('Ce code existe déjà');
            $retourliste = FALSE;
        }
        break;

    // Modification de la fiche groupement champs Check-List
    case 'edit' :
        $rech = 'UPDATE `' . TBCLCG . "` SET `clcg_desc`='" . $db->escape($desc) . "'";
        $rech .= " WHERE `clcg_code` = '" . $db->escape($code) . "'";
        $db->query($rech);

        // On supprime d'abord les anciens check-lists
        $rech = 'DELETE FROM `' . TBCLCCLCG . "` WHERE `clcclcg_codeclcg` = '" . $db->escape($code) . "'";
        $db->query($rech);

        // Mise à jour des champs check-list
        if (count($tab_clc) > 0) {
            // On ajoute les check-lists sélectionnés
            foreach ($tab_clc as $key => $clc) {
                if (trim($clc) <> '') {
                    $rech2 = 'INSERT INTO `' . TBCLCCLCG . '` (clcclcg_codeclc,clcclcg_codeclcg) VALUES';
                    $rech2 .= " ('" . $db->escape($clc) . "','" . $db->escape($code) . "')";
                    $db->query($rech2);
                }
            }
        }

        $msg = _('Fiche modifiée');
        break;

    // Suppression de la fiche groupement champs Check-List
    case 'del' :
        $rech = 'SELECT COUNT(*) FROM `' . TBCLCGINTC . "` WHERE `clcgintc_codeclcg` = '" . $db->escape($code) . "'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            // SUPPRESSION des groupements check-list rattachées
            $rech = 'DELETE FROM `' . TBCLCCLCG . "` WHERE `clcclcg_codeclcg` = '" . $db->escape($code) . "'";
            $db->query($rech);

            // Non -> suppression de la fiche groupement
            $rech = 'DELETE FROM `' . TBCLCG . "` WHERE `clcg_code` = '" . $db->escape($code) . "'";
            $db->query($rech);

            $msg = _('Fiche supprimée');
        } else {
            $msg = _('Ce groupement de champs check-list est utilisé dans une catégorie intervention');
            $retourliste = FALSE;
        }
        break;
    default :
        $msg = _('Problème de paramètres');
        $retourliste = FALSE;
        break;
}
close_database();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche groupement champs check-list'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            <?php
            if ($retourliste == FALSE)
                {echo "warn_txt('" . str_escape($msg) . "');";}
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    aff_ret_idx_man($td, 'clcg_lst.php', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'clcg_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>