<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_dde.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$code = str_majuscules(valpost('code'));
$desc = str_majuscules(valpost('desc'));

$pub = (int)valpost('pub');
$cli = (int)valpost('client');
$age = (int)valpost('age');
$tec = (int)valpost('tec');
$ope = (int)valpost('ope');
$cge = (int)valpost('cge');
$stt = (int)valpost('stt');
$st = (int)valpost('st');
$dot = (int)valpost('dot');
$do = (int)valpost('do');

$retourliste = TRUE;


switch ($td) {
    // Ajout de la fiche type de demande
    case 'add' :
        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
        $rech = 'SELECT COUNT(*) FROM `' . TBDDET . "` WHERE `ddet_code` = '" . $db->escape($code) . "'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $rech = 'INSERT INTO `' . TBDDET . '` (ddet_code,ddet_desc,ddet_pub,ddet_cli,ddet_age,ddet_tec,ddet_ope,ddet_cge,ddet_stt,ddet_st,ddet_dot,ddet_do,ddet_delok)';
            $rech .= " VALUES ('" . $db->escape($code) . "','" . $db->escape($desc) . "','$pub','$cli','$age','$tec','$ope','$cge','$stt','$st','$dot','$do','1')";
            $db->query($rech);
            $msg = _('Fiche ajoutée');
        } else {
            $msg = _('Ce code existe déjà');
            $retourliste = FALSE;
        }
        close_database();
        break;

    // MAJ de la fiche Type de demande
    case 'edit' :
        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
        $rech = 'UPDATE `' . TBDDET . "` SET `ddet_code`='" . $db->escape($code) . "', `ddet_desc`='" . $db->escape($desc) . "', `ddet_pub`='" . $pub . "',";
        $rech .= "  `ddet_cli`='" . $cli . "', `ddet_age`='" . $age . "',";
        $rech .= " `ddet_tec`='" . $tec . "', `ddet_ope`='" . $ope . "', `ddet_cge`='" . $cge . "',";
        $rech .= " `ddet_stt`='" . $stt . "', `ddet_st`='" . $st . "', `ddet_dot`='" . $dot . "', `ddet_do`='" . $do . "'";
        $rech .= " WHERE `ddet_code` = '" . $db->escape($code) . "'";
        $db->query($rech);
        close_database();

        $msg = _('Fiche modifiée');
        break;

    // Suppression de la fiche type de demande
    case 'del' :
        // Vérifie si utilisé dans une demande
        if (exist_ddet_in_dde($code) == TRUE) {
            $msg = _('Ce type de demande a déjà été utilisé dans une demande');
            $retourliste = FALSE;
        } else {
            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

            // SUPPRESSION de la fiche type de demande
            $rech = 'DELETE FROM `' . TBDDET . "` WHERE `ddet_code` = '" . $db->escape($code) . "'";
            $db->query($rech);
            close_database();

            $msg = _('Fiche supprimée');
        }
        break;

    default :
        $msg = _('Problème de paramètres');
        $retourliste = FALSE;
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche Type de Demande'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            <?php
            if ($retourliste == FALSE)
                {echo "warn_txt('" . str_escape($msg) . "');";}
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    aff_ret_idx_man($td, 'ddet_lst.php', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'ddet_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>