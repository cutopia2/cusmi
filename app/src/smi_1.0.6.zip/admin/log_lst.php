<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if (CheckURLLog(FALSE) == FALSE) {
    header('Location: ../index.php');
}
if (CheckNivLog('9') == FALSE) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
$_SESSION['typ_filtres'] = 'log';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Logs de Connexion'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab_champ = ["nom:date1f ; format:date ; req:Y ; txt:<?php echo _('Date de début'); ?> ; masque:<?php echo $_SESSION['date_fmtfull']; ?> ; stok:frmok ; stbad:frmbad",
            "nom:date2f ; format:date ; req:Y ; txt:<?php echo _('Date de fin'); ?> ; masque:<?php echo $_SESSION['date_fmtfull']; ?> ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <script type="text/javascript">
        <!--
        function init_datepicker() {
            <?php include_once '../jscript/datepicker_prm.js.php'; ?>
            $("#date1f").datepicker({
                onSelect: function (datesel) {
                    $("#date1f").blur();
                    chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, '', '', 'date2f', false);
                }
            });
            $("#date2f").datepicker({
                onSelect: function (datesel) {
                    $("#date2f").blur();
                    chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, 'date1f', '', 'today', false);
                }
            });
        }

        function init_all() {
            init_Body();
            init_autohref_classe('falselnkimg', '');
            init_datepicker();
            init_autoraz('razdate1f', 'date1f', 'click');
            init_autoraz('razdate2f', 'date2f', 'click');
            init_valid_log('purge', 'log_purge', '<?php echo valsession('date_fmtshort'); ?>', tab_champ, '', '');
            init_valid_log('purgea', 'log_purge', '<?php echo valsession('date_fmtshort'); ?>', tab_champ, '', '');
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>

<body>

<?php
include_once '../inc/entete.inc.php';
cre_ent_form(_('LOGS DES CONNEXIONS'), '', '', '', FALSE);
$fic_imp = 'log_lsti.php';

// Détermination du nombre total d'enregistrements
$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

$rech = cree_strrechlstlog();
$rech .= crestr_triord($log_titre_col, 'log_date', FALSE, $limitlog);

$rows = $db->get_results($rech, ARRAY_A);
close_database();

if ($rows) {
    $numrows = count($rows);

    include_once '../inc/formr.inc.php';

    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

    $rech = modstr_triord($rech, $log_titre_col, 'log_date', TRUE, $limitlog);

    $rows = $db->get_results($rech, ARRAY_A);

    // *** Pagination de pied
    pagine_lst($numrows, $limitlog);

    // *** Affichage de la table
    echo '<span class="annot_petit_it">' . _('Cliquez sur les codes ou les IP pour les détails') . '</span>';
    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

    // création entête
    titlst($log_titre_col);

    $i = 0;

    foreach ($rows as $row) {
        $row = encode_str($row);
        // création de l'entête de ligne (TR)
        echo '<tr>';

        echo '<td>';
        if ($row['log_code'] != '?') {
            echo $row['log_code'];
            $url_code = 'log_detc.php?cc=' . $row['log_code'];
            cre_falselnk_img('', 'det_code_' . $row['log_id'], 'span', 'center', _('Détail'), 'lnkpop', $url_code, '../img/eye.png', 1024, 600);
        } else {
            echo $row['log_code'];
        }
        echo '</td>';
        echo '<td align="center">' . datetolocal($row['log_date']) . '</td>';
        echo '<td align="center">' . $row['log_heure'] . '</td>';
        echo '<td>' . $row['log_urlprec'] . '</td>';
        echo '<td>' . $row['log_url'] . '</td>';
        echo '<td align="center">';
        echo $row['log_ip'];
        $url_detlog = 'log_trace.php?ip=' . $row['log_ip'];
        cre_falselnk_img('', 'det_ip_' . $row['log_id'], 'span', 'center', _('Détail'), 'lnkpop', $url_detlog, '../img/eye.png', 1024, 600);
        echo '</td>';

        echo '</tr>';

        $i++;
    }
    echo '</table>';
    // *** Fin affichage de la table

    close_database();

    // *** Pagination de pied
    pagine_lst($numrows, $limitlog);

    $taille_piedla = '';
    include_once '../inc/piedla.inc.php';
} else {
    retpp();
}

if (count($rows) > 0) {
    ?>
    <!-- Permet de purger des logs sur une fourchette de dates -->
    <form name="log_purge" id="log_purge" method="post" action="log_enr.php?td=del">
        <input name="today" type="hidden" id="today" value="<?php echo $datef; ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">

        <p align="center" class="titre_gras_soul"><?php echo _('PURGE DES LOGS'); ?></p>
        <table width="400" border="0" align="center">
            <tr>
                <td width="30" class="rubfrm" id="f_date1f" align="right"><?php echo _('Du'); ?>...</td>
                <td>
                    <input name="date1f" type="text" id="date1f" size="10" maxlength="10" readonly>
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    <img src="../img/raz.png" id="razdate1f" border="0" align="absmiddle">
                </td>
                <td width="30" class="rubfrm" id="f_date2f" align="right"><?php echo _('Au'); ?>...</td>
                <td>
                    <input name="date2f" type="text" id="date2f" size="10" maxlength="10" readonly>
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    <img src="../img/raz.png" id="razdate2f" border="0" align="absmiddle">
                </td>
            </tr>
        </table>
        <p align="center">
            <input name="purge" type="button" class="bton_std" id="purge" value="<?php echo _('Purger'); ?>">
            <input name="purgea" type="button" class="bton_std" id="purgea" value="<?php echo _('Tout Purger'); ?>">
        </p>
    </form>
    <?php
}
include_once 'pied.php';
?>
</body>
</html>