<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if (CheckURLLog(FALSE) == FALSE) {
    header('Location: ../index.php');
}
if (CheckNivLog('9') == FALSE) {
    header('Location: ../index.php');
}
include_once '../inc/fic_cocl.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_time.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
$pbm_maint = FALSE;

// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);
$_POST = clean_str($_POST);

$type = $_GET['td'];

$tr = -1;
if (!isset($_GET['tr'])) {
    $pbm_maint = TRUE;
} else {
    if (!is_numeric($_GET['tr'])) {
        $pbm_maint = TRUE;
    } else {
        $tr = (int)$_GET['tr'];
    }
}

$rep = FALSE;
if (isset($_GET['rep'])) {
    switch ($_GET['rep']) {
        case 'Y' :
            $rep = TRUE;
            break;
        case 'N' :
            $rep = FALSE;
            break;
        default :
            $pbm_maint = TRUE;
            break;
    }
}

$titre ='';
switch ($type) {
    case 'cli' :
        $titre = _('MAINTENANCE CLIENTS');
        if (($tr < 0) || ($tr > 2)) {
            $pbm_maint = TRUE;
        }
        break;
    case 'conc' :
        $titre = _('MAINTENANCE CONTRATS CLIENTS');
        if (($tr < 0) || ($tr > 2)) {
            $pbm_maint = TRUE;
        }
        break;
    case 'int' :
        $titre = _('MAINTENANCE INTERVENTIONS');
        if (($tr < 0) || ($tr > 2)) {
            $pbm_maint = TRUE;
        }
        break;
    case 'pla' :
        $titre = _('MAINTENANCE INTERVENTIONS');
        if (($tr < 0) || ($tr > 2)) {
            $pbm_maint = TRUE;
        }
        break;
    default :
        $pbm_maint = TRUE;
        break;
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Maintenance'); ?></title>


    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            <?php
            if (($rep == FALSE) && ($errglob == TRUE))
                {echo "init_autohref('rep', 'click', '', true);";}
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';

if ($pbm_maint == FALSE) {
    cre_ent_form($titre, '', '', '', FALSE);
    echo '<p align="center">';
    echo '<span class="annot_std_it">';
    if ($rep == TRUE) {
        echo _('Mode réparation');
    } else {
        echo _('Mode analyse');
    }
    echo '</span></p>';
    $errglob = FALSE;
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
    switch ($type) {
        case 'cli' :
            $rech = 'SELECT * FROM `' . TBCLI . '` ORDER BY `cli_code`';
            $rows = $db->get_results($rech, ARRAY_A);
            if ($rows && count($rows) <> 0) {
                // *** vérification types de clients
                if (($tr == 0) || ($tr == 1)) {
                    echo '<span class="annot_gras_it">';
                    echo _('Vérification des types de clients');
                    echo '</span>';
                    echo '<div id="Layer1" class="lst_fen2">';
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    echo '<th>';
                    echo _('Code');
                    echo '</th>';
                    echo '<th>';
                    echo _('Type');
                    echo '</th>';
                    echo '<th>';
                    echo _('Interventions ?');
                    echo '</th>';
                    echo '<th>';
                    echo _('Interventions closes ?');
                    echo '</th>';
                    echo '<th>';
                    echo _('Cohérent ?');
                    echo '</th>';
                    if ($rep == TRUE) {
                        echo '<th>';
                        echo _('Réparé ?');
                        echo '</th>';
                    }

                    $i = 0;

                    foreach ($rows as $row) {
                        $row = encode_str($row);
                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        echo '<td align="center">' . $row['cli_code'] . '</td>';
                        echo '<td align="center">';
                        echo $typ_client[$row['cli_type']];
                        echo '</td>';
                        $typcli = -1;
                        $cliint = FALSE;
                        $err = FALSE;
                        // déjà utilisé dans une intervention ?
                        echo '<td align="center">';
                        $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . "` WHERE `int_codecli`='" . $row['cli_code'] . "'";
                        $nb_rs = $db->get_var($rech2);
                        if ($nb_rs <> 0) {
                            $cliint = TRUE;
                            echo _('Oui');
                            if ($row['cli_type'] == 0) {
                                $err = TRUE;
                                $typcli = 1;
                            }
                        } else {
                            echo _('Non');
                            if ($row['cli_type'] > 0) {
                                $err = TRUE;
                                $typcli = 0;
                            }
                        }
                        echo '</td>';
                        // déjà utilisé dans une intervention close ?
                        echo '<td align="center">';
                        $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . "` WHERE `int_codecli`='" . $row['cli_code'] . "' AND `int_datefin`<>'0000-00-00'";
                        $nb_rs = $db->get_var($rech2);
                        if ($nb_rs <> 0) {
                            echo _('Oui');
                            if ($row['cli_type'] <= 1) {
                                $err = TRUE;
                                $typcli = 2;
                            }
                        } else {
                            echo _('Non');
                            if ($row['cli_type'] > 1) {
                                $err = TRUE;
                                $typcli = 0;
                                if ($cliint == TRUE) {
                                    $typcli = 1;
                                }
                            }
                        }
                        echo '</td>';


                        echo '<td align="center">';
                        if ($err == TRUE) {
                            $errglob = TRUE;
                            echo '<span class="annot_gras_it">';
                            echo _('pas ok');
                            echo '</span>';
                        } else {
                            echo _('ok');
                        }
                        echo '</td>';

                        if ($rep == TRUE) {
                            echo '<td align="center">';
                            // On ne met à jour que si erreur
                            if ($err == TRUE) {
                                $rech3 = 'UPDATE `' . TBCLI . '` SET';
                                $rech3 .= " `cli_type`='" . $typcli . "'";
                                $rech3 .= " WHERE `cli_code` = '" . $row['cli_code'] . "'";
                                $db->query($rech3);
                                echo _('Oui');
                                echo '<span class="annot_petit_it">';
                                echo '<br />' . _('Passé en') . " '" . $typ_client[$typcli] . "'";
                                echo '</span>';
                            } else {
                                echo _('Non');
                            }
                            echo '</td>';
                        }

                        echo '</th>';
                        $i++;
                    }

                    echo '</table>';
                    echo '</div>';
                    echo '<br />';
                }

                // *** vérification des répertoires clients
                if (($tr == 0) || ($tr == 2)) {
                    // vérification du répertoire principal pour les clients
                    $rep_clients = $url_gfc . '/clients';
                    $desc_rep_clients = _('Répertoire spécifique aux clients');
                    $detail_rep_clients = _('Répertoire permettant le stockage des fichiers pour les clients');
                    // Si le sous-répertoire spécifique aux clients n'existe pas, on le crée
                    if (cree_dir($rep_clients)) {
                        $rech = 'INSERT INTO `' . TBFIC . '`';
                        $rech .= ' (fic_nom,fic_type,fic_desc,fic_detail,fic_datecrea,fic_codecrea,fic_nbtel) VALUES';
                        $rech .= " ('$rep_clients','0','$desc_rep_clients','$detail_rep_clients','$datea','$admin_code','')";
                        $db->query($rech);
                    }

                    echo '<span class="annot_gras_it">';
                    echo _('Vérification des répertoires privés clients');
                    echo '</span>';
                    echo '<div id="Layer1" class="lst_fen2">';
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    echo '<th>';
                    echo _('Code');
                    echo '</th>';
                    echo '<th>';
                    echo _('Répertoire physique ?');
                    echo '</th>';
                    echo '<th>';
                    echo _('Répertoire MySQL ?');
                    echo '</th>';
                    echo '<th>';
                    echo _('Cohérent ?');
                    echo '</th>';
                    if ($rep == TRUE) {
                        echo '<th>';
                        echo _('Réparé ?');
                        echo '</th>';
                    }

                    $i = 0;

                    foreach ($rows as $row) {
                        $row = encode_str($row);
                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        echo '<td align="center">' . $row['cli_code'] . '</td>';
                        $err = FALSE;
                        $repphys = TRUE;
                        $repsql = TRUE;
                        $rep_ce_client = $rep_clients . '/' . strtolower($row['cli_code']);
                        $rep_pj_ce_client = $rep_clients . '/' . strtolower($row['cli_code']) . '/PJ';

                        // Répertoire physique ?
                        echo '<td align="center">';
                        if (is_dir($rep_ce_client)) {
                            echo _('Oui');
                        } else {
                            echo _('Non');
                            $err = TRUE;
                            $repphys = FALSE;
                        }
                        echo '</td>';

                        // Répertoire MySQL ?
                        echo '<td align="center">';
                        $rech2 = 'SELECT COUNT(*) FROM `' . TBFIC . "` WHERE `fic_nom`='" . $rep_ce_client . "'";
                        $nb_rs = $db->get_var($rech2);
                        if ($nb_rs <> 0) {
                            echo _('Oui');
                        } else {
                            echo _('Non');
                            $err = TRUE;
                            $repsql = FALSE;
                        }
                        echo '</td>';

                        echo '<td align="center">';
                        if ($err == TRUE) {
                            $errglob = TRUE;
                            echo '<span class="annot_gras_it">';
                            echo _('pas ok');
                            echo '</span>';
                        } else {
                            echo _('ok');
                        }
                        echo '</td>';

                        if ($rep == TRUE) {
                            echo '<td align="center">';
                            // On ne met à jour que si erreur
                            if ($err == TRUE) {
                                $msg = '';
                                if ($row['cli_ste'] <> '') {
                                    $desc_rep_ce_client = _('Répertoire client') . $row['cli_ste'] . ' (' . $row['cli_code'] . ')';
                                    $detail_rep_ce_client = _('Répertoire permettant le stockage des fichiers pour le client') . $row['cli_ste'] . ' (' . $row['cli_code'] . ')';
                                } else {
                                    $desc_rep_ce_client = _('Répertoire client') . $row['cli_nom'] . ' ' . $row['cli_prenom'] . ' (' . $row['cli_code'] . ')';
                                    $detail_rep_ce_client = _('Répertoire permettant le stockage des fichiers pour le client') . $row['cli_nom'] . ' ' . $row['cli_prenom'] . ' (' . $row['cli_code'] . ')';
                                }

                                $desc_rep_ce_client = clean_str($desc_rep_ce_client);
                                $detail_rep_ce_client = clean_str($detail_rep_ce_client);

                                if ($repphys == FALSE) {
                                    // On crée sous-répertoire spécifique à ce client
                                    if (cree_dir($rep_ce_client)) {
                                        $msg = _('Répertoire physique créé');
                                    } else {
                                        $msg = _('Problème création répertoire physique');
                                    }
                                }

                                if ($repsql == FALSE) {
                                    // On ajoute le détail dans le fichier MySQL
                                    $rech3 = 'INSERT INTO `' . TBFIC . '`';
                                    $rech3 .= ' (fic_nom,fic_type,fic_desc,fic_detail,fic_datecrea,fic_codecrea,fic_nbtel) VALUES';
                                    $rech3 .= " ('$rep_ce_client','0','" . $db->escape($desc_rep_ce_client) . "',";
                                    $rech3 .= "	'" . $db->escape($detail_rep_ce_client) . "','$datea','$admin_code','')";
                                    $db->query($rech3);
                                    if ($msg <> '') {
                                        $msg .= '<br />' . _('Répertoire MySQL créé');
                                    } else {
                                        $msg .= _('Répertoire MySQL créé');
                                    }
                                }
                                echo _('Oui');
                                echo '<span class="annot_petit_it">';
                                echo '<br />' . $msg;
                                echo '</span>';
                            } else {
                                echo _('Non');
                            }
                            echo '</td>';
                        }

                        echo '</th>';
                        $i++;
                    }

                    echo '</table>';
                    echo '</div>';
                    echo '<br />';
                }
            } else {
                echo '<br /><span class="annot_std_gras">' . _('Aucun client') . '</span><br />';
            }
            break;

        // Contrats clients
        case 'conc' :
            $rech = 'SELECT * FROM `' . TBCOCL . '` ORDER BY `cocl_code`';
            $rows = $db->get_results($rech, ARRAY_A);
            if ($rows && (count($rows) <> 0)) {
                // *** vérification signatures & réceptions_
                if (($tr == 0) || ($tr == 1)) {
                    echo '<span class="annot_gras_it">';
                    echo _('Vérification des signatures & réceptions de contrats');
                    echo '</span>';
                    echo '<div id="Layer1" class="lst_fen2">';
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    echo '<th>';
                    echo _('Code');
                    echo '</th>';
                    echo '<th>';
                    echo _('Type');
                    echo '</th>';
                    echo '<th>';
                    echo _('Signé le');
                    echo '</th>';
                    echo '<th>';
                    echo _('Reçu le');
                    echo '</th>';
                    echo '<th>';
                    echo _('Clôt le');
                    echo '</th>';
                    echo '<th>';
                    echo _('Cohérent ?');
                    echo '</th>';
                    if ($rep == TRUE) {
                        echo '<th>';
                        echo _('Réparé ?');
                        echo '</th>';
                    }

                    $i = 0;

                    foreach ($rows as $row) {
                        $row = encode_str($row);
                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        echo '<td align="center">' . $row['cocl_code'] . '</td>';
                        echo '<td align="center">';
                        if ($row['cocl_typh'] == 0) {
                            echo _('Temps/Intervention');
                        } else {
                            echo _('Quota Horaire');
                        }
                        echo '</td>';
                        echo '<td align="center">';
                        if (datetolocal($row['cocl_datesig']) <> '') {
                            echo datetolocal($row['cocl_datesig']);
                        } else {
                            echo '-';
                        }
                        echo '</td>';
                        echo '<td align="center">';
                        if (datetolocal($row['cocl_daterec']) <> '') {
                            echo datetolocal($row['cocl_daterec']);
                        } else {
                            echo '-';
                        }
                        echo '</td>';
                        echo '<td align="center">';
                        if (datetolocal($row['cocl_datefin']) <> '') {
                            echo datetolocal($row['cocl_datefin']);
                        } else {
                            echo '-';
                        }
                        echo '</td>';
                        echo '<td align="center">';
                        $datesig = '';
                        $daterec = '';
                        $signepar = '';
                        // déjà utilisé dans une intervention ?
                        $rech2 = 'SELECT MIN(int_datedde) AS mindate FROM `' . TBINT . "` WHERE `int_codecocl`='" . $row['cocl_code'] . "'";
                        $row2 = $db->get_row($rech2, ARRAY_A);
                        $row2 = encode_str($row2);

                        $err = FALSE;

                        // Il y a une date de signature ?
                        // Non
                        if (datetolocal($row['cocl_datesig']) == '') {
                            // déjà reçu ?
                            // Oui : pas ok
                            if (datetolocal($row['cocl_daterec']) <> '') {
                                $err = TRUE;
                                // MAJ possible uniquement si déjà utilisé
                                if (datetolocal($row2['mindate']) <> '') {
                                    $datesig = $row2['mindate']; // Au moins la 1ère date d'intervention
                                    // La date de signature ne doit pas dépasser celle de réception
                                    if (echeance_depassee_date($datesig, $row['cocl_daterec']) == TRUE) {
                                        $daterec = $datesig;
                                    }
                                }
                            }

                            // déjà fini ?
                            // Oui : pas ok
                            if (datetolocal($row['cocl_datefin']) <> '') {
                                $err = TRUE;
                                // déjà reçu ?
                                // Non : pas ok
                                if (datetolocal($row['cocl_daterec']) == '') {
                                    if (datetolocal($row2['mindate']) <> '') {
                                        $datesig = $row2['mindate']; // Au moins la 1ère date d'intervention
                                        $daterec = $row2['mindate']; // Au moins la 1ère date d'intervention
                                    }
                                } else {
                                    $datesig = $row['cocl_daterec'];
                                } // Au moins la date de réception
                            }
                        } else // Oui
                        {
                            // déjà reçu ?
                            // Non : pas ok si déjà utilisé
                            if ((datetolocal($row['cocl_daterec']) == '') && (datetolocal($row2['mindate']) <> '')) {
                                $err = TRUE;
                                $daterec = $row2['mindate']; // Au moins la 1ère date d'intervention
                            }
                        }

                        // Si date signature modifiée ou date signature existante, on vérifie signataire
                        if (($datesig <> '') || (datetolocal($row['cocl_datesig']) <> '')) {
                            // signé par ?
                            if (trim($row['cocl_signe']) == '') // Si pas signé, on prend au moins le contact principal
                            {
                                $err = TRUE;
                                $rech3 = 'SELECT * FROM `' . TBCLI . "` WHERE `cli_code`='" . $row['cocl_codecli'] . "'";
                                $row3 = $db->get_row($rech3, ARRAY_A);
                                if ($row3) {
                                    $row3 = encode_str($row3);
                                    $signepar = $row3['cli_civilite'] . ' ' . $row3['cli_prenom'] . ' ' . $row3['cli_nom'];
                                }
                            }
                        }
                        if ($err == TRUE) {
                            $errglob = TRUE;
                            echo '<span class="annot_gras_it">';
                            echo _('pas ok');
                            echo '</span>';
                        } else {
                            echo _('ok');
                        }
                        echo '</td>';
                        if ($rep == TRUE) {
                            echo '<td align="center">';
                            // On ne met à jour que si erreur
                            if ($err == TRUE) {
                                $rech3 = 'UPDATE `' . TBCOCL . '` SET';
                                if ($datesig <> '') {
                                    $rech3 .= " `cocl_datesig`='" . $datesig . "'";
                                }
                                if ($daterec <> '') {
                                    if ($datesig <> '') {
                                        $rech3 .= ',';
                                    }
                                    $rech3 .= " `cocl_daterec`='" . $daterec . "'";
                                }
                                if ($signepar <> '') {
                                    if (($daterec <> '') || ($datesig <> '')) {
                                        $rech3 .= ',';
                                    }
                                    $rech3 .= " `cocl_signe`='" . $signepar . "'";
                                }
                                $rech3 .= " WHERE `cocl_code` = '" . $row['cocl_code'] . "'";
                                $db->query($rech3);
                                echo _('Oui');
                                echo '<span class="annot_petit_it">';
                                if ($datesig <> '') {
                                    echo '<br />' . _('Signé au') . ' ' . datetolocal($datesig);
                                }
                                if ($daterec <> '') {
                                    echo '<br />' . _('Reçu le') . ' ' . datetolocal($daterec);
                                }
                                if ($signepar <> '') {
                                    echo '<br />' . _('Signé par') . ' ' . $signepar;
                                }
                                echo '</span>';
                            } else {
                                echo _('Non');
                            }
                            echo '</td>';
                        }

                        echo '</th>';
                        $i++;
                    }

                    echo '</table>';
                    echo '</div>';
                    echo '<br />';
                }

                // *** vérification sites couverts
                if (($tr == 0) || ($tr == 2)) {
                    echo '<span class="annot_gras_it">';
                    echo _('Vérification des sites couverts');
                    echo '</span>';
                    echo '<div id="Layer1" class="lst_fen2">';
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    echo '<th>';
                    echo _('Code');
                    echo '</th>';
                    echo '<th>';
                    echo _('Type');
                    echo '</th>';
                    echo '<th>';
                    echo _('Site principal');
                    echo '</th>';
                    echo '<th>';
                    echo _('Sites secondaires');
                    echo '</th>';
                    echo '<th>';
                    echo _('Cohérent ?');
                    echo '</th>';
                    if ($rep == TRUE) {
                        echo '<th>';
                        echo _('Réparé ?');
                        echo '</th>';
                    }

                    $i = 0;

                    foreach ($rows as $row) {
                        $row = encode_str($row);
                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        echo '<td align="center">' . $row['cocl_code'] . '</td>';
                        echo '<td align="center">';
                        if ($row['cocl_typh'] == 0) {
                            echo _('Temps/Intervention');
                        } else {
                            echo _('Quota Horaire');
                        }
                        echo '</td>';
                        echo '<td align="center">';
                        $sitep = TRUE;
                        if ($row['cocl_sitep'] == 1) {
                            echo _('Oui');
                        } else {
                            echo '-';
                            $sitep = FALSE;
                        }
                        echo '</td>';
                        echo '<td align="center">';
                        $sites = FALSE;
                        // Sites secondaires
                        $rech2 = 'SELECT COUNT(*) FROM `' . TBSCLIC . "` WHERE `sclic_codecocl`='" . $row['cocl_code'] . "'";
                        $nb_rs2 = $db->get_var($rech2);
                        if ($nb_rs2 > 0) {
                            $sites = TRUE;
                            echo _('Oui');
                        } else {
                            echo '-';
                        }
                        echo '</td>';
                        echo '<td align="center">';
                        $err = FALSE;
                        if (($sitep == FALSE) && ($sites == FALSE)) {
                            $err = TRUE;
                        }
                        if ($err == TRUE) {
                            $errglob = TRUE;
                            echo '<span class="annot_gras_it">';
                            echo _('pas ok');
                            echo '</span>';
                        } else {
                            echo _('ok');
                        }
                        echo '</td>';
                        if ($rep == TRUE) {
                            echo '<td align="center">';
                            // "Pas ok"...on répare
                            if ($err == TRUE) {
                                $rech3 = 'UPDATE `' . TBCOCL . '` SET';
                                $rech3 .= " `cocl_sitep`='1'";
                                $rech3 .= " WHERE `cocl_code` = '" . $row['cocl_code'] . "'";
                                $db->query($rech3);
                                echo _('Oui');
                                echo '<span class="annot_petit_it">';
                                echo '<br />' . _('Site principal rajouté');
                                echo '</span>';
                            } else {
                                echo _('Non');
                            }
                            echo '</td>';
                        }

                        $i++;
                    }

                    echo '</table>';
                    echo '</div>';
                    echo '<br />';
                }
            } else {
                echo '<br /><span class="annot_std_gras">' . _('Aucun contrat créé') . '</span><br />';
            }
            break;

        // Interventions
        case 'int' :
            // *** création des multi rendez-vous
            if (($tr == 0) || ($tr == 1)) {
                $rech = 'SELECT * FROM `' . TBINT . '` ORDER BY `int_code`';
                $rows = $db->get_results($rech, ARRAY_A);
                if ($rows && (count($rows) <> 0)) {
                    $codeuser = valsession('code_log');

                    echo '<span class="annot_gras_it">';
                    echo _('Génération des multi rendez-vous interventions');
                    echo '</span>';
                    echo '<div id="Layer1" class="lst_fen2">';
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    echo '<th>';
                    echo _('Code');
                    echo '</th>';
                    echo '<th>';
                    echo _('Date RDV saisie?');
                    echo '</th>';
                    echo '<th>';
                    echo _('Avec historique ?');
                    echo '</th>';
                    echo '<th>';
                    echo _('En multi RDV ?');
                    echo '</th>';
                    echo '<th>';
                    echo _('Pour chaque historique ?');
                    echo '</th>';
                    echo '<th>';
                    echo _('Cohérent ?');
                    echo '</th>';
                    if ($rep == TRUE) {
                        echo '<th>';
                        echo _('Réparé ?');
                        echo '</th>';
                    }

                    $i = 0;

                    foreach ($rows as $row) {
                        $row = encode_str($row);
                        $err = FALSE;

                        extract($row);

                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        echo '<td align="center">';
                        echo $int_code;
                        echo '</td>';

                        // On Contrôle s'il y a une date de RDV dans l'intervention
                        $exist_daterdv_int = FALSE;
                        echo '<td align="center">';
                        if (datetolocal($int_daterdv) <> '') {
                            echo _('date oui');
                            $exist_daterdv_int = TRUE;
                        } else {
                            echo _('date non');
                        }
                        echo '</td>';

                        // On vérifie s'il y a un historique
                        $exist_histo_int = FALSE;
                        $rech2 = 'SELECT COUNT(*) FROM `' . TBINTH . "` WHERE inth_codeint = '$int_code'";
                        $rech2 .= ' ORDER BY inth_date';
                        $nb_rs2 = $db->get_var($rech2);
                        if ($nb_rs2 > 0) {
                            $exist_histo_int = TRUE;
                        }
                        echo '<td align="center">';
                        if ($exist_histo_int == TRUE) {
                            echo _('oui');
                        } else {
                            echo _('non');
                        }
                        echo '</td>';

                        // On vérifie s'il y a un RDV déjà saisi
                        $exist_rdv_int = FALSE;
                        $rech2 = 'SELECT rdv_id FROM `' . TBRDV . '`';
                        $rech2 .= " WHERE rdv_typrat='1' AND rdv_coderat='$int_code'";
                        $nb_rs2 = $db->get_var($rech2);
                        if ($nb_rs2 > 0) {
                            $exist_rdv_int = TRUE;
                        }
                        echo '<td align="center">';
                        if ($exist_rdv_int == TRUE) {
                            echo _('oui');
                        } else {
                            echo _('non');
                        }
                        echo '</td>';

                        // On vérifie si c'est bien saisi pour chaque historique
                        $exist_each_rdv_inth = TRUE;
                        $rech2 = 'SELECT rdv_id FROM `' . TBRDV . "` WHERE rdv_typrat=1 AND rdv_coderat = '$int_code'";
                        $rows2 = $db->get_results($rech2, ARRAY_A);
                        if ($rows2 && (count($rows) > 0)) {
                            foreach ($rows2 as $row2) {
                                $row2 = encode_str($row2);
                                extract($row2);

                                // Calcul de la durée
                                $durees = diff_time_sec($inth_heurea, $inth_heured);
                                $dureem = floor($durees / 60);

                                $rech3 = 'SELECT COUNT(*) FROM `' . TBINTH . '`';
                                $rech3 .= ' WHERE inth_idrdv=' . $rdv_id;
                                $nb_rs3 = $db->get_var($rech3);
                                if ($nb_rs3 == 0) {
                                    $exist_each_rdv_inth = FALSE;
                                }
                            }
                        } else {
                            $exist_each_rdv_inth = FALSE;
                        }
                        echo '<td align="center">';
                        if ($exist_each_rdv_inth == TRUE) {
                            echo _('oui');
                        } else {
                            echo _('non');
                        }
                        echo '</td>';

                        // On teste la cohérence
                        $err = FALSE;
                        $int_close = FALSE;
                        if ($int_datefinf <> '') {
                            $int_close = TRUE;
                        }
                        // Si date de RDV saisie dans intervention, et pas dans multi RDV et intervention non close
                        // => erreur
                        if (($exist_daterdv_int == TRUE) && ($exist_rdv_int == FALSE) && ($int_close == FALSE)) {
                            $err = TRUE;
                        }
                        // Si historique dans intervention, et pas dans multi RDV
                        // => erreur
                        if (($exist_histo_int == TRUE) && ($exist_rdv_int == FALSE)) {
                            $err = TRUE;
                        }
                        // Si pas tous les historiques répertoriés dans multi RDV
                        // => erreur
                        if (($exist_histo_int == TRUE) && ($exist_each_rdv_inth == FALSE)) {
                            $err = TRUE;
                        }
                        echo '<td align="center">';
                        if ($err == TRUE) {
                            $errglob = TRUE;
                            echo _('non');
                        } else {
                            echo _('oui');
                        }
                        echo '</td>';

                        if ($rep == TRUE) // On répare (si mode réparation)
                        {
                            $mess_rep = '';
                            // S'il y a un historique, on reconstruit
                            if ($exist_histo_int == TRUE) {
                                // On reconstruit à partir des historiques
                                $rech2 = 'SELECT * FROM `' . TBINTH . "` WHERE inth_codeint = '$int_code'";
                                $rech2 .= ' ORDER BY inth_date';
                                $rows2 = $db->get_results($rech2, ARRAY_A);
                                if ($rows2 && (count($rows2) > 0)) {
                                    foreach ($rows as $row2) {
                                        $row2 = encode_str($row2);
                                        extract($row2);

                                        // Calcul de la durée
                                        $durees = diff_time_sec($inth_heurea, $inth_heured);
                                        $dureem = floor($durees / 60);

                                        // On vérifie si le RDV a déjà été pris pour cet historique
                                        $rech3 = 'SELECT COUNT(*) FROM `' . TBRDV . '`';
                                        $rech3 .= " WHERE rdv_typrat=1 AND rdv_coderat='" . $int_code . "'";
                                        $rech3 .= " AND rdv_date='" . $inth_date . "' AND rdv_heure='" . $inth_heurea . "' AND rdv_dureem=" . $dureem;

                                        $rows3 = $db->get_results($rech3, ARRAY_A);
                                        if (datetolocal($inth_date) <> '') {
                                            if ($rows3 && (count($rows3) > 0)) {
                                                foreach ($rows3 as $row3) {
                                                    $row3 = encode_str($row3);
                                                    extract($row3);
                                                    $rech4 = 'UPDATE `' . TBRDV . "` SET `rdv_datemod`='" . $datea . "', `rdv_codemod`='" . $codeuser . "',";
                                                    $rech4 .= " `rdv_date`='" . $inth_date . "',`rdv_codelieu`='" . $inth_codelieu . "', `rdv_heure`='" . $inth_heurea . "', `rdv_dureem`='" . $dureem . "',";
                                                    $rech4 .= " `rdv_honore`='1',";
                                                    $rech4 .= " `rdv_nivurg`='" . $int_urg . "'";
                                                    $rech4 .= " WHERE `rdv_id` = '" . $rdv_id . "'";
                                                    $db->query($rech4);
                                                    $last_id = $rdv_id;
                                                }
                                            } else // Pas saisi : on ajoute
                                            {
                                                $rech4 = 'INSERT INTO `' . TBRDV . '`';
                                                $rech4 .= ' (rdv_datecrea,rdv_codecrea,rdv_datemod,rdv_codemod,rdv_typrat,rdv_coderat,rdv_date,rdv_codelieu,';
                                                $rech4 .= 'rdv_heure,rdv_dureem,rdv_nivurg,rdv_honore)';
                                                $rech4 .= ' VALUES';
                                                $rech4 .= " ('$datea','$codeuser','$datea','$codeuser','1','$int_code','$inth_date','$inth_codelieu',";
                                                $rech4 .= "'$inth_heurea','$dureem','$int_urg','1')";
                                                $db->query($rech4);
                                                $last_id = $db->insert_id;
                                            }

                                            // On met à jour l'enregistrement historique concerné
                                            $rech4 = 'UPDATE `' . TBINTH . '` SET `inth_idrdv`=' . $last_id;
                                            $rech4 .= ' WHERE `inth_id` = ' . $inth_id;
                                            $db->query($rech4);
                                        }

                                    }
                                    $mess_rep = _('Historiques réintégrés dans multi RDV');
                                }

                                // Si date de RDV saisie dans l'intervention et intervention non close
                                // On met à jour le multi RDV
                                // (On considère que la date saisie est le prochain RDV)
                                if (($exist_daterdv_int == TRUE) && ($int_close == FALSE)) {
                                    // On vérifie si le RDV a déjà été pris pour cetet date de RDV
                                    $rech2 = 'SELECT COUNT(*) FROM `' . TBRDV . '`';
                                    $rech2 .= " WHERE rdv_typrat='1' AND rdv_coderat='" . $int_code . "'";
                                    $rech2 .= " AND rdv_date='" . $int_daterdv . "' AND rdv_heure='" . $int_hrdv . "' AND rdv_dureem=" . $int_dureem;
                                    $nbres2 = $db->get_var($rech2);
                                    // Si cette date est déjà dans multi-RDV : on ne fait rien
                                    // Si pas encore dans multi RDV : on met à jour
                                    if ($nbres2 == 0) {
                                        $rech3 = 'INSERT INTO `' . TBRDV . '`';
                                        $rech3 .= ' (rdv_datecrea,rdv_codecrea,rdv_datemod,rdv_codemod,rdv_typrat,rdv_coderat,rdv_date,rdv_codelieu,';
                                        $rech3 .= 'rdv_heure,rdv_dureem,rdv_nivurg)';
                                        $rech3 .= ' VALUES';
                                        $rech3 .= " ('$datea','$codeuser','$datea','$codeuser','1','$int_code','$int_daterdv','$int_codelieu',";
                                        $rech3 .= "'$int_hrdv','$int_dureem','$int_urg')";
                                        $db->query($rech3);
                                        if (trim($mess_rep) <> '') {
                                            $mess_rep .= '<br />';
                                        }
                                        $mess_rep .= _('RDV intervention réintégré dans multi RDV');
                                    }
                                }
                            } else {
                                // Si date de RDV saisie dans intervention et intervention non close
                                // on transfère en multi RDV
                                if (($exist_daterdv_int == TRUE) && ($int_close == FALSE)) {
                                    // On vérifie si le RDV a déjà été pris pour cette date de RDV
                                    $rech2 = 'SELECT COUNT(*) FROM `' . TBRDV . '`';
                                    $rech2 .= " WHERE rdv_typrat='1' AND rdv_coderat='" . $int_code . "'";
                                    $rech2 .= " AND rdv_date='" . $int_daterdv . "' AND rdv_heure='" . $int_hrdv . "' AND rdv_dureem=" . $int_dureem;
                                    $nbres2 = $db->get_var($rech2);
                                    // Si cette date est déjà dans multi-RDV : on ne fait rien
                                    // Si pas encore dans multi RDV : on met à jour
                                    if ($nbres2 == 0) {
                                        $rech3 = 'INSERT INTO `' . TBRDV . '`';
                                        $rech3 .= ' (rdv_datecrea,rdv_codecrea,rdv_datemod,rdv_codemod,rdv_typrat,rdv_coderat,rdv_date,rdv_codelieu,';
                                        $rech3 .= 'rdv_heure,rdv_dureem,rdv_nivurg)';
                                        $rech3 .= ' VALUES';
                                        $rech3 .= " ('$datea','$codeuser','$datea','$codeuser','1','$int_code','$int_daterdv','$int_codelieu',";
                                        $rech3 .= "'$int_hrdv','$int_dureem','$int_urg')";
                                        $db->query($rech3);
                                        $mess_rep .= _('RDV intervention réintégré dans multi RDV');
                                    }
                                }
                            }

                            // On vide la date de RDV de l'intervention si intervention close
                            if (($exist_daterdv_int == TRUE) && ($int_close == TRUE)) {
                                $rech2 = 'UPDATE `' . TBINT . "` SET `int_daterdv`='0000-00-00'";
                                $rech2 .= " WHERE `int_code` = '" . $int_code . "'";
                                $db->query($rech2);
                            }

                            echo '<td align="center">';
                            if (trim($mess_rep) <> '') {
                                echo $mess_rep;
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                        }

                        echo '</tr>';
                        $i++;
                    }
                    echo '</table>';
                    echo '</div>';
                    echo '<br />';
                } else {
                    echo '<br /><span class="annot_std_gras">' . _('Aucune intervention') . '</span><br />';
                }
            }

            // *** vérification des facturations
            if (($tr == 0) || ($tr == 2)) {
                $rech = 'SELECT * FROM `' . TBINT . '` ORDER BY `int_code`';
                $rows = $db->get_results($rech, ARRAY_A);
                if ($rows && (count($rows) <> 0)) {
                    $codeuser = valsession('code_log');

                    echo '<span class="annot_gras_it">';
                    echo _('Vérification de cohérence des facturations');
                    echo '</span>';
                    echo '<div id="Layer1" class="lst_fen2">';
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    echo '<th>';
                    echo _('Code');
                    echo '</th>';
                    echo '<th>';
                    echo _('Noté facturé ?');
                    echo '</th>';
                    echo '<th>';
                    echo _('Facture saisie ?');
                    echo '</th>';
                    echo '<th>';
                    echo _('Cohérent ?');
                    echo '</th>';
                    if ($rep == TRUE) {
                        echo '<th>';
                        echo _('Réparé ?');
                        echo '</th>';
                    }

                    $i = 0;

                    foreach ($rows as $row) {
                        $row = encode_str($row);
                        $err = FALSE;

                        extract($row);

                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        echo '<td align="center">';
                        echo $int_code;
                        echo '</td>';

                        echo '<td align="center">';
                        if ($int_fact == 1) {
                            echo _('oui');
                        } else {
                            echo _('non');
                        }
                        echo '</td>';

                        // On vérifie s'il y a au moins une facture de saisie
                        $exist_fact_int = FALSE;
                        $rech2 = 'SELECT COUNT(*) FROM `' . TBINTF . "` WHERE intf_codeint = '$int_code'";
                        $nb_rs2 = $db->get_var($rech2);
                        if ($nb_rs2 > 0) {
                            $exist_fact_int = TRUE;
                        }
                        echo '<td align="center">';
                        if ($exist_fact_int == TRUE) {
                            echo _('oui');
                        } else {
                            echo _('non');
                        }
                        echo '</td>';

                        // On teste la cohérence
                        $err = FALSE;
                        if (($int_fact == 0) && ($exist_fact_int == TRUE)) {
                            $err = TRUE;
                        }
                        if (($int_fact == 1) && ($exist_fact_int == FALSE)) {
                            $err = TRUE;
                        }
                        echo '<td align="center">';
                        if ($err == TRUE) {
                            $errglob = TRUE;
                            echo _('non');
                        } else {
                            echo _('oui');
                        }
                        echo '</td>';

                        if ($rep == TRUE) // On répare (si mode réparation)
                        {
                            $mess_rep = '';
                            if ($err == TRUE) {
                                // S'il y a au moins une facture, on met à jour l'intervention
                                if ($exist_fact_int == TRUE) {
                                    $rech2 = 'UPDATE `' . TBINT . "` SET `int_fact`='1'";
                                    $rech2 .= " WHERE `int_code` = '" . $int_code . "'";
                                    $db->query($rech2);
                                } else {
                                    $rech2 = 'UPDATE `' . TBINT . "` SET `int_fact`='0'";
                                    $rech2 .= " WHERE `int_code` = '" . $int_code . "'";
                                    $db->query($rech2);

                                }
                                $mess_rep = _('Intervention mise à jour');
                            }

                            echo '<td align="center">';
                            if (trim($mess_rep) <> '') {
                                echo $mess_rep;
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                        }

                        echo '</tr>';
                        $i++;
                    }
                    echo '</table>';
                    echo '</div>';
                    echo '<br />';
                } else {
                    echo '<br /><span class="annot_std_gras">' . _('Aucune intervention') . '</span><br />';
                }
            }
            break;

        // Planning
        case 'pla' :
            // *** Cohérence Interventions
            if (($tr == 0) || ($tr == 1)) {
                $rech = 'SELECT * FROM `' . TBPEVT . '` ORDER BY `pevt_date` AND `pevt_typrat`=1';
                $rs = $db->get_results($rech, ARRAY_A);
                if ($rows && (count($rows) <> 0)) {
                    echo '<span class="annot_gras_it">';
                    echo _('Vérification de cohérence évènements planning/interventions');
                    echo '</span>';
                    echo '<div id="Layer1" class="lst_fen2">';
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    echo '<th>';
                    echo _('Date');
                    echo '</th>';
                    echo '<th>';
                    echo _('Heure');
                    echo '</th>';
                    echo '<th>';
                    echo _('Durée');
                    echo '</th>';
                    echo '<th>';
                    echo _('Titre');
                    echo '</th>';
                    echo '<th>';
                    echo _('Intervention');
                    echo '</th>';
                    echo '<th>';
                    echo _('Cohérent ?');
                    echo '</th>';
                    if ($rep == TRUE) {
                        echo '<th>';
                        echo _('Réparé ?');
                        echo '</th>';
                    }

                    $i = 0;

                    foreach ($rows as $row) {
                        $row = encode_str($row);
                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        echo '<td align="center">';
                        if (datetolocal($row['pevt_date']) <> '') {
                            echo datetolocal($row['pevt_date']);
                        } else {
                            echo '-';
                        }
                        echo '</td>';
                        echo '<td align="center">';
                        echo $row['pevt_heure'];
                        echo '</td>';
                        echo '<td align="center">';
                        echo substr(sec_heure($row['pevt_dureem'] * 60), 0, 5);
                        echo '</td>';
                        echo '<td align="center">';
                        echo $row['pevt_titre'];
                        echo '</td>';
                        echo '<td align="center">';
                        echo $row['pevt_coderat'];
                        echo '</td>';
                        echo '<td align="center">';

                        $err = FALSE;

                        // L'intervention existe ?
                        $rech2 = 'SELECT * FROM `' . TBINT . "` WHERE `int_code`='" . $row['pevt_coderat'] . "'";
                        $rows2 = $db->get_results($rech2, ARRAY_A);
                        if ($rows2 && (count($rows2) == 1)) {
                            foreach ($rows2 as $row2) {
                                $row2 = encode_str($row2);
                                echo '<span class="annot_petit_it">';
                                echo _('Intervention trouvée') . '<br />';
                                echo '(' . datetolocal($row2['int_daterdv']) . ' - ' . $row2['int_hrdv'] . ' - ' . substr(sec_heure($row2['int_dureem'] * 60), 0, 5) . ')<br />';
                                echo '</span>';

                                // Oui : les dates - horaires sont cohérents ?
                                if (($row['pevt_date'] == $row2['int_daterdv']) && ($row['pevt_heure'] == $row2['int_hrdv']) && ($row['pevt_dureem'] == $row2['int_dureem'])) {
                                    // Oui : Le titre semble "logique" ?
                                    $titre = _('INTERVENTION ') . $row2['int_code'];
                                    // Non
                                    if ($row['pevt_titre'] <> $titre) {
                                        echo '<span class="annot_gras_it">';
                                        echo _('Titre incohérent') . '<br />';
                                        $err = TRUE;
                                        // Si mode réparation, on répare
                                        if ($rep == TRUE) {
                                            // On corrige le titre
                                            $rech3 = 'UPDATE `' . TBPEVT . "` SET `pevt_titre`='" . $titre . "'";
                                            $rech3 .= " WHERE `pevt_id` = '" . $row['pevt_id'] . "'";
                                            $db->query($rech3);
                                            echo _('Titre corrigé');
                                        }
                                        echo '</span>';
                                    }
                                } // Non
                                else {
                                    echo '<span class="annot_gras_it">';
                                    echo _('Date ou Heure ou Durée incohérentes') . '<br />';
                                    $err = TRUE;
                                    // Si mode réparation, on répare
                                    if ($rep == TRUE) {
                                        // On met à jour les données horaires de l'intervention
                                        // et on signale l'intervention comme planifiée
                                        $rech3 = 'UPDATE `' . TBINT . "` SET `int_daterdv`='" . $row['pevt_date'] . "',";
                                        $rech3 .= " `int_hrdv`='" . $row['pevt_heure'] . "',";
                                        $rech3 .= " `int_dureem`='" . $row['pevt_dureem'] . "',";
                                        $rech3 .= " `int_planifie`='1'";
                                        $rech3 .= " WHERE `int_code` = '" . $row['pevt_coderat'] . "'";
                                        $db->query($rech3);

                                        // On met à jour tous les évènements rattachés à cette intervention
                                        $rech3 = 'UPDATE `' . TBPEVT . "` SET `pevt_date`='" . $row['pevt_date'] . "',";
                                        $rech3 .= " `pevt_heure`='" . $row['pevt_heure'] . "',";
                                        $rech3 .= " `pevt_dureem`='" . $row['pevt_dureem'] . "'";
                                        $rech3 .= " WHERE `pevt_coderat` = '" . $row['pevt_coderat'] . "'";
                                        $db->query($rech3);

                                        echo _('Données horaires corrigées');
                                    }
                                    echo '</span>';
                                }
                            }
                        } // Non
                        else {
                            echo '<span class="annot_gras_it">';
                            echo _('Intervention introuvable') . '<br />';
                            $err = TRUE;
                            // Si mode réparation, on répare
                            if ($rep == TRUE) {
                                // On supprime l'évènement
                                $rech3 = 'DELETE FROM `' . TBPEVT . "` WHERE `pevt_id` = '" . $row['pevt_id'] . "'";
                                $db->query($rech3);

                                // On vérifie si intervention toujours planifiée "ailleurs"
                                // ON vérifie s'il y a un évènement rattaché à cette intervention
                                $rech3 = 'SELECT COUNT(*) FROM `' . TBPEVT . "` WHERE `pevt_coderat`='" . $row['pevt_coderat'] . "'";
                                $nb_rs3 = $db->get_var($rech3);
                                //... Oui
                                if ($nb_rs3 > 0) {
                                    $rech4 = 'UPDATE `' . TBINT . "` SET `int_planifie`='1'";
                                    $rech4 .= " WHERE `int_code` = '" . $row['pevt_coderat'] . "'";
                                } else // ... Non
                                {
                                    $rech4 = 'UPDATE `' . TBINT . "` SET `int_planifie`='0'";
                                    $rech4 .= " WHERE `int_code` = '" . $row['pevt_coderat'] . "'";
                                }
                                $db->query($rech4);

                                echo _('Evènement supprimé');
                            }
                            echo '</span>';
                        }
                        echo '</td>';

                        if ($err == TRUE) {
                            $errglob = TRUE;
                        }

                        if ($rep == TRUE) {
                            echo '<td align="center">';
                            // On ne met à jour que si erreur
                            if ($err == TRUE) {
                                echo _('Oui');
                            } else {
                                echo _('Non');
                            }
                            echo '</td>';
                        }

                        echo '</tr>';
                        $i++;
                    }

                    echo '</table>';
                    echo '</div>';
                    echo '<br />';
                } else {
                    echo '<br /><span class="annot_std_gras">' . _('Aucun évènement créé') . '</span><br />';
                }
            }

            // *** Régénération évènements
            if (($tr == 0) || ($tr == 2)) {
                $rech = 'SELECT * FROM `' . TBINT . "` WHERE (`int_datefin`='0000-00-00' AND `int_daterdv`<>'0000-00-00')";
                $rows = $db->get_results($rech, ARRAY_A);
                if ($rows && (count($rows) <> 0)) {
                    echo '<span class="annot_gras_it">';
                    echo _('Génération des évènements planning/interventions');
                    echo '</span>';
                    echo '<div id="Layer1" class="lst_fen2">';
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    // création entête
                    echo '<th>';
                    echo _('Intervention');
                    echo '</th>';
                    echo '<th>';
                    echo _('Date');
                    echo '</th>';
                    echo '<th>';
                    echo _('Heure');
                    echo '</th>';
                    echo '<th>';
                    echo _('Durée');
                    echo '</th>';
                    echo '<th>';
                    echo _('Technicien');
                    echo '</th>';
                    echo '<th>';
                    echo _('Cohérent ?');
                    echo '</th>';
                    if ($rep == TRUE) {
                        echo '<th>';
                        echo _('Généré ?');
                        echo '</th>';
                    }

                    $i = 0;

                    foreach ($rows as $row) {
                        $row = encode_str($row);
                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        $err = FALSE;

                        // Zone détail intervention
                        echo '<td align="center">';
                        echo $row['int_code'];
                        echo '</td>';
                        echo '<td align="center">';
                        if (datetolocal($row['int_daterdv']) <> '') {
                            echo datetolocal($row['int_daterdv']);
                        } else {
                            echo '-';
                        }
                        echo '</td>';
                        echo '<td align="center">';
                        echo $row['int_hrdv'];
                        echo '</td>';
                        echo '<td align="center">';
                        echo substr(sec_heure($row['int_dureem'] * 60), 0, 5);
                        echo '</td>';
                        if ($rep == FALSE) {
                            echo '<td align="center" colspan="2">';
                        } else {
                            echo '<td align="center" colspan="3">';
                        }
                        echo '&nbsp;';
                        echo '</td>';
                        echo '</tr>';

                        // Zone détail techniciens rattachés
                        $rech2 = 'SELECT * FROM `' . TBINTT . "` WHERE `intt_codeint`='" . $row['int_code'] . "'";
                        $rows2 = $db->get_results($rech2, ARRAY_A);
                        if ($rows2 && (count($rows2) > 0)) {
                            foreach ($rows2 as $row2) {
                                $row2 = encode_str($row2);
                                echo '<tr>';
                                echo '<td align="center" colspan="4">';
                                echo '<td align="center">';
                                echo $row2['intt_codetec'];
                                echo '</td>';

                                // On vérifie la cohérence
                                echo '<td align="center">';

                                // Evènement existant ?
                                $rech3 = 'SELECT COUNT(*) FROM `' . TBPEVT . "` WHERE (`pevt_coderat`='" . $row['int_code'] . "' AND `pevt_dest`='" . $row2['intt_codetec'] . "')";
                                $rows3 = $db->get_results($rech3, ARRAY_A);
                                if ($rows3 && (count($rows3) > 0)) {
                                    foreach ($rows3 as $row3) {
                                        $row3 = encode_str($row3);
                                        echo '<span class="annot_petit_it">';
                                        echo _('Evènement trouvé') . '<br />';
                                        echo '(' . datetolocal($row3['pevt_date']) . ' - ' . $row3['pevt_heure'] . ' - ' . substr(sec_heure($row3['pevt_dureem'] * 60), 0, 5) . ')<br />';
                                        echo '</span>';

                                        // Oui : les dates - horaires sont cohérents ?
                                        if (($row3['pevt_date'] == $row['int_daterdv']) && ($row3['pevt_heure'] == $row['int_hrdv']) && ($row3['pevt_dureem'] == $row['int_dureem'])) {
                                            // Oui : Le titre semble "logique" ?
                                            $titre = _('INTERVENTION ') . $row['int_code'];
                                            // Non
                                            if ($row3['pevt_titre'] <> $titre) {
                                                echo '<span class="annot_gras_it">';
                                                echo _('Titre incohérent') . '<br />';
                                                $err = TRUE;
                                                // Si mode réparation, on répare
                                                if ($rep == TRUE) {
                                                    // On met à jour les données horaires de l'intervention
                                                    // et on signale l'intervention comme planifiée
                                                    $rech4 = 'UPDATE `' . TBINT . "` SET `int_planifie`='1'";
                                                    $rech4 .= " WHERE `int_code` = '" . $row['int_code'] . "'";
                                                    $db->query($rech4);

                                                    // On met à jour tous les évènements rattachés à cette intervention
                                                    $rech4 = 'UPDATE `' . TBPEVT . "` SET `pevt_titre`='" . $titre . "'";
                                                    $rech4 .= " WHERE `pevt_coderat` = '" . $row['int_code'] . "'";
                                                    $db->query($rech4);

                                                    echo _('Titre corrigé');
                                                }
                                                echo '</span>';
                                            }
                                        } // Non
                                        else {
                                            $err = TRUE;
                                            echo '<span class="annot_gras_it">';
                                            echo _('Date ou Heure ou Durée incohérentes') . '<br />';
                                            // Si mode réparation, on répare
                                            if ($rep == TRUE) {
                                                // On met à jour les données horaires de l'intervention
                                                // et on signale l'intervention comme planifiée
                                                $rech4 = 'UPDATE `' . TBINT . "` SET `int_planifie`='1'";
                                                $rech4 .= " WHERE `int_code` = '" . $row['int_code'] . "'";
                                                $db->query($rech4);

                                                // On met à jour tous les évènements rattachés à cette intervention
                                                $rech4 = 'UPDATE `' . TBPEVT . "` SET `pevt_date`='" . $row['int_daterdv'] . "',";
                                                $rech4 .= " `pevt_heure`='" . $row['int_hrdv'] . "',";
                                                $rech4 .= " `pevt_dureem`='" . $row['int_dureem'] . "'";
                                                $rech4 .= " WHERE `pevt_coderat` = '" . $row['int_code'] . "'";
                                                $db->query($rech4);

                                                echo _('Données horaires corrigées');
                                            }
                                            echo '</span>';
                                        }
                                    }
                                } // Non
                                else {
                                    $err = TRUE;
                                    echo '<span class="annot_gras_it">';
                                    echo _('Evènement inexistant') . '<br />';
                                    // Si mode réparation, on répare
                                    if ($rep == TRUE) {
                                        // On insère l'évènement
                                        $titre = _('INTERVENTION') . ' ' . $row['int_code'];
                                        $detail = _('matériel') . ' :' . chr(13) . chr(10) . $mat . chr(13) . chr(10) . chr(13) . chr(10) . 'Travail à effectuer :' . chr(13) . chr(10) . $pbm;

                                        $rech3 = 'INSERT INTO `' . TBPEVT . '`';
                                        $rech3 .= ' (pevt_datecrea,pevt_codecrea,pevt_datemod,pevt_codemod,pevt_gest,pevt_typdest,pevt_dest,pevt_typrat,pevt_coderat,';
                                        $rech3 .= 'pevt_date,pevt_heure,';
                                        $rech3 .= 'pevt_dureem,pevt_titre,pevt_detail,pevt_codelieu,pevt_codecat,pevt_nivurg) VALUES';
                                        $rech3 .= " ('$datea','$codeuser','$datea','$codeuser','$codeuser','1','" . $row2['intt_codetec'] . "','1','" . $row['int_code'] . "',";
                                        $rech3 .= "'" . $row['int_daterdv'] . "','" . $row['int_hrdv'] . "',";
                                        $rech3 .= "'" . $row['int_dureem'] . "','$titre','$detail','" . $row['int_codelieu'] . "','" . $row['int_codecat'] . "','" . $row['int_urg'] . "')";
                                        $db->query($rech3);
                                    }
                                    echo '</span>';
                                }
                                echo '</td>';
                                if ($rep == TRUE) {
                                    echo '<td align="center">';
                                    // On ne met à jour que si erreur
                                    if ($err == TRUE) {
                                        echo _('Oui');
                                    } else {
                                        echo _('Non');
                                    }
                                    echo '</td>';
                                }
                                echo '</tr>';
                            }
                        } else {
                            echo '<tr>';
                            echo '<td align="center" colspan="4">';
                            echo '<td align="center">';
                            echo '<span class="annot_gras_it">';
                            echo _('Aucun technicien affecté');
                            echo '</span>';
                            echo '</td>';
                            echo '<td align="center">';
                            echo '-';
                            echo '</td>';

                            if ($rep == TRUE) {
                                echo '<td align="center">';
                                // On ne met à jour que si erreur
                                if ($err == TRUE) {
                                    echo _('Oui');
                                } else {
                                    echo _('Non');
                                }
                                echo '</td>';
                            }
                            echo '</tr>';
                        }

                        if ($err == TRUE) {
                            $errglob = TRUE;
                        }

                        $i++;
                    }

                    echo '</table>';
                    echo '</div>';
                    echo '<br />';
                } else {
                    echo '<br /><span class="annot_std_gras">' . _('Aucune intervention') . '</span><br />';
                }
            }

            break;
    }
    close_database();
    if (($rep == FALSE) && ($errglob == TRUE)) {
        cre_falselnk('', 'rep', 'div', 'center', _('Réparer'), 'maint_data.php?td=' . $type . '&tr=' . $tr . '&rep=Y', '../img/rep.png', _('Réparer'));
    }
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'index.php');
}
include_once 'pied.php';
?>
</body>
</html>