<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if (CheckURLLog(FALSE) == FALSE) {
    header('Location: ../index.php');
}
if (CheckNivLog('9') == FALSE) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geol.inc.php';
include_once '../inc/func_log.inc.php';

include_once '../classes/geoplugin/geoplugin.class.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$ip = $_GET['ip']; // Récupération adresse IP

$ip_ok = TRUE;

if ($ip <> '') {
    $expr = "/^[0-9]{1,3}[\.][0-9]{1,3}[\.][0-9]{1,3}[\.][0-9]{1,3}$/";
    if (preg_match($expr, $ip)) {
        // Détection de l'OS du serveur
        $unix = serverOS_isunix();
    } else {
        $ip_ok = FALSE;
    }
} else {
    $ip_ok = FALSE;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Détail ip log'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            add_func_click('ferm', 'sclose', '');
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>
<?php
if ($ip_ok == TRUE) {
    cre_ent_form(_('DETAIL IP LOG'), '', '', '', FALSE);
    ?>
    <p align="center" class="titre_gras"><?php echo _("Pour l'adresse IP"); ?> : <?php echo $ip; ?></p>
    <br/>
    <div align="center">
        <form name="formulaire" action="" method="post">
            <span class="titre_gras"><?php echo _("Pays d'origine"); ?></span>
            <?php
            echo '<pre>';
            echo pays_connect($ip);
            echo '</pre>';
            ?>
            <hr align="center" width="400" size="2" style="color:#666666">
            <span class="titre_gras"><?php echo _('Traceroute'); ?></span>
            <?php
            echo '<pre>';
            if ($unix) {
                system('traceroute ' . $ip);
                system('killall -q traceroute'); // Destruction de tous les processus Traceroute en cours
            } else {
                system('tracert ' . $ip . ' 1> /tmp/output.txt 2>&1; cat /tmp/output.txt; rm /tmp/output.txt');
            }
            echo '</pre>';
            ?>
            <hr align="center" width="400" size="2" style="color:#666666">
            <span class="titre_gras"><?php echo _('Host'); ?></span>
            <br/><br/>
            <?php echo gethostbyaddr($ip); ?>
            <hr align="center" width="400" size="2" style="color:#666666">
            <span class="titre_gras"><?php echo _('NSLookup'); ?></span>
            <br/>
            <?php
            echo '<pre>';
            system('nslookup ' . $ip . ' -sil 1> /tmp/output.txt 2>&1; cat /tmp/output.txt; rm /tmp/output.txt');
            echo '</pre>';
            ?>
            <hr align="center" width="400" size="2" style="color:#666666">
            <span class="titre_gras"><?php echo _('Ping'); ?></span>
            <br/>
            <?php
            echo '<pre>';
            if ($unix) {
                system('ping -c 3 ' . $ip . ' 1> /tmp/output.txt 2>&1; cat /tmp/output.txt; rm /tmp/output.txt');
            } else {
                system('ping ' . $ip . ' 1> /tmp/output.txt 2>&1; cat /tmp/output.txt; rm /tmp/output.txt');
            }
            echo '</pre>';
            ?>
            <?php
            if ($unix) {
                ?>
                <hr align="center" width="400" size="2" style="color:#666666">
                <span class="titre_gras"><?php echo _('Tracepath'); ?></span>
                <br/>
                <?php
                echo '<pre>';
                system('tracepath ' . $ip . ' 1> /tmp/output.txt 2>&1; cat /tmp/output.txt; rm /tmp/output.txt');
                echo '</pre>';
                ?>
            <?php } ?>
        </form>
    </div>

    <!-- bouton de fermeture de la fenêtre -->
    <p align="center">
        <input name="ferm" type="button" class="bton_std" id="ferm" value="<?php echo _('Quitter'); ?>">
    </p>
    <?php
} else {
    close_fen_auto('', '');
}
?>
</body>
</html>
