<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$code = str_majuscules(valpost('code'));
$desc = str_majuscules(valpost('desc'));
$nbj = valpost('nbj');
$coclcat = (int)valpost('coclcat');

$retourliste = TRUE;

switch ($td) {
    // Ajout de la fiche périodicité
    case 'add' :
        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
        $rech = 'SELECT COUNT(*) FROM `' . TBPER . "` WHERE `per_code` = '" . $db->escape($code) . "'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $rech = 'INSERT INTO `' . TBPER . '` (per_code,per_desc,per_nbj,per_coclcat)';
            $rech .= " VALUES ('" . $db->escape($code) . "','" . $db->escape($desc) . "','$nbj','$coclcat')";
            $db->query($rech);
            $msg = _('Fiche ajoutée');
        } else {
            $msg = _('Ce code existe déjà');
            $retourliste = FALSE;
        }
        close_database();
        break;

    // MAJ de la fiche périodicité
    case 'edit' :
        $editok = true;

        // Vérifie si utilisé dans un contrat client
        if (exist_per_in_cocl($code) == TRUE) {
            $msg = _('Cette périodicité est utilisée dans un contrat client');
            $editok = false;
            $retourliste = FALSE;
        }

        // Vérifie si utilisé dans une catégorie contrat client
        if (exist_per_in_coclcat($code) == TRUE) {
            $msg = _('Cette périodicité est utilisée dans une catégorie contrat');
            $editok = false;
            $retourliste = FALSE;
        }

        // Vérifie si utilisé dans une catégorie contrat client
        if (exist_per_in_cons($code) == TRUE) {
            $msg = _('Cette périodicité est utilisée dans les paramètres');
            $editok = false;
            $retourliste = FALSE;
        }

        if ($editok == true)
        {
            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

            // MAJ de la fiche périodicité
            $rech = 'UPDATE `' . TBPER . "` SET `per_code`='" . $db->escape($code) . "', `per_desc`='" . $db->escape($desc) . "',";
            $rech .= "`per_nbj`='" . $nbj . "',`per_coclcat`='" . $coclcat . "'   WHERE `per_code` = '" . $code . "'";
            $db->query($rech);
            close_database();

            $msg = _('Fiche modifiée');
            $retourliste = TRUE;
        }
        break;

    // Suppression de la fiche périodicité
    case 'del' :
        $delok = true;

        // Vérifie si utilisé dans un contrat client
        if (exist_per_in_cocl($code) == TRUE) {
            $msg = _('Cette périodicité est utilisée dans un contrat client');
            $delok = false;
            $retourliste = FALSE;
        }

        // Vérifie si utilisé dans une catégorie contrat client
        if (exist_per_in_coclcat($code) == TRUE) {
            $msg = _('Cette périodicité est utilisée dans une catégorie contrat');
            $delok = false;
            $retourliste = FALSE;
        }

        if ($delok == true) {
            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

            // SUPPRESSION de la fiche périodicité
            $rech = 'DELETE FROM `' . TBPER . "` WHERE `per_code` = '$code'";
            $db->query($rech);
            close_database();

            $msg = _('Fiche supprimée');
        }
        break;

    default :
        $msg = _('Problème de paramètres');
        $retourliste = FALSE;
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche périodicité'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    exec_func_js("warn_txt('" . str_escape($msg) . "')");
    aff_ret_idx_man($td, 'per_lst.php', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'per_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>