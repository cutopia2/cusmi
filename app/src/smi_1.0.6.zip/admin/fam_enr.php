<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$code = str_majuscules(valpost('code'));
$desc = str_majuscules(valpost('desc'));

$retourliste = TRUE;
$msg = '';

$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

switch ($td) {
    // Ajout de la fiche Famille
    case 'add' :
        $rech = 'SELECT COUNT(*) FROM `' . TBFAM . "` WHERE `fam_code` = '$code'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $rech2 = 'INSERT INTO `' . TBFAM . "` (fam_code,fam_desc) VALUES ('" . $db->escape($code) . "','" . $db->escape($desc) . "')";
            $db->query($rech2);
            $msg = _('Fiche ajoutée');
        } else {
            $msg = _('Ce code existe déjà');
            $retourliste = FALSE;
        }
        break;

    // Modification de la fiche Famille
    case 'edit' :
        $rech = 'UPDATE `' . TBFAM . "` SET `fam_desc`='" . $db->escape($desc) . "' WHERE `fam_code` = '" . $code . "'";
        $db->query($rech);
        $msg = _('Fiche modifiée');
        break;

    // Suppression de la fiche Famille
    case 'del' :
        $used = FALSE;

        // Vérifie si utilisé dans une fiche produit
        $rech = 'SELECT COUNT(*) FROM `' . TBPDT . "` WHERE `pdt_fam` = '$code'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs <> 0) {
            $msg = _('Cette famille est utilisée dans une fiche article');
            $used = TRUE;
            $retourliste = FALSE;
        }

        // Vérifie si utilisé dans une fiche produit location
        $rexist = 'SELECT COUNT(*) FROM `' . TBPDTLOC . "` WHERE `pdtloc_fam` = '$code'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs <> 0) {
            $msg = _('Cette famille est utilisée dans une fiche article location');
            $used = TRUE;
            $retourliste = FALSE;
        }

        if ($used == FALSE) {
            // SUPPRESSION de la fiche Famille
            $rech = 'DELETE FROM `' . TBFAM . "` WHERE `fam_code` = '$code'";
            $db->query($rech);
            $msg = _('Fiche supprimée');
        }
        break;

    default :
        break;
}
close_database();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche Famille'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            <?php
            if ($retourliste == FALSE)
                {echo "warn_txt('" . str_escape($msg) . "');";}
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    aff_ret_idx_man($td, 'fam_lst.php', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'fam_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>