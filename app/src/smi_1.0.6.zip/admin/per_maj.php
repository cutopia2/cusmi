<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$td = $_GET['td'];
$coderech = $_GET['code'];

$pbm_per = FALSE;

if ($coderech <> '') {
    // Récupération des informations périodicité
    $row = lit_enr_per($coderech);
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);
    } else {
        $pbm_per = TRUE;
    }
} else {
    if ($td <> 'add') {
        $pbm_per = TRUE;
    }
}

$titre ='';
switch ($td) {
    case 'add' :
        $titre = _('CREATION PERIODICITE');
        break;
    case 'edit' :
        $titre = _('MISE A JOUR PERIODICITE');
        break;
    case 'del' :
        $titre = _('SUPPRESSION PERIODICITE');
        break;
    default :
        $pbm_per = TRUE;
        break;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche périodicité'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab1_champ = ["nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:desc; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?> ; lmx:20 ; stok:frmok ; stbad:frmbad",
            "nom:nbj; format:unsigned ; req:Y ; txt:<?php echo _('Nombre de jours'); ?> ; lmx:3 ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_per == FALSE) { ?>
        <script type="text/javascript">
            <!--
            $(function () {
                $("#code").Setcase({caseValue: 'upper', changeonFocusout: true});
                $("#desc").Setcase({caseValue: 'upper', changeonFocusout: true});
                $("#nbj").Setcase({caseValue: 'upper', changeonFocusout: true});
            });

            function init_all() {
                init_Body();
                <?php
                switch ($td)
                {
                    case 'add' :
                        echo "init_valid_form('enr','per_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'edit' :
                        echo "init_valid_form('enr','per_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        echo "readonly_id('code',false);";
                        break;
                    case 'view' :
                        echo 'readonly_all();';
                        break;
                    case 'del' :
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                }
                ?>
                init_back('annul', 'click');
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';

if ($pbm_per == FALSE) {
    cre_ent_form($titre, 'per_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="per_maj" id="per_maj" method="post" action="per_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="160" class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                <td>
                    <input name="code" type="text" id="code" value="<?php echo $per_code ?>" size="10" maxlength="10">
                </td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_desc" align="right"><?php echo _('Libellé'); ?></td>
                <td><input name="desc" type="text" id="desc" value="<?php echo $per_desc ?>" size="20">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_nbj" align="right"><?php echo _('Nombre de jours'); ?></td>
                <td>
                    <input name="nbj" type="text" id="nbj" align="right" value="<?php echo $per_nbj ?>" size="3"
                           maxlength="3">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"> <span
                        class="annot_petit_it"><?php echo _('(Nombre de jour entre 2 interventions. 0 = A la demande)'); ?></span>
                </td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_coclcat" align="right"><?php echo _('Egalement utilisable sur catégorie de contrat'); ?></td>
                <td>
                    <?php
                    cre_select('coclcat', 'coclcat', $non_oui, (int)$per_coclcat);
                    ?>
                </td>
            </tr>
        </table>
        <p align="center">
            <?php
            switch ($td) {
                case 'add' :
                    echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Valider') . '">';
                    break;
                case 'edit' :
                    echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Valider') . '">';
                    break;
                case 'del' :
                    echo '<input name="del" type="submit" class="bton_std" id="del" value="' . _('Supprimer') . '">';
                    break;
            }
            echo ' <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="' . _('Réinitialiser') . '">';
            ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'per_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>