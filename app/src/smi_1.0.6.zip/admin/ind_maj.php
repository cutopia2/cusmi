<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_int.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$td = $_GET['td'];
$coderech = $_GET['code'];

$pbm_ind = FALSE;
$ind_actif = TRUE;
$indmod = TRUE;

if ($coderech <> '') {
    $row = lit_enr_ind($coderech);
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);
        $indmod = ind_modifiable($ind_code);
    } else {
        $pbm_ind = TRUE;
    }
} else {
    if ($td <> 'add') {
        $pbm_ind = TRUE;
    }
}
$titre ='';
if ($pbm_ind == FALSE) {
    switch ($td) {
        case 'add' :
            $titre = _('CREATION INDICE HORAIRE');
            break;
        case 'edit' :
            $titre = _('MISE A JOUR INDICE HORAIRE');
            break;
        case 'del' :
            $titre = _('SUPPRESSION INDICE HORAIRE');
            break;
        default :
            $pbm_ind = TRUE;
            break;
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-type=" content="text/html; charset=utf-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Indices horaires'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab_champ = ["nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?> ; lmn:1 ; lmx:5; stok:frmok ; stbad:frmbad",
            "nom:desc ; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?>; lmn:1 ; lmx:40; stok:frmok ; stbad:frmbad",
            "nom:coeff ; format:reel_ns ; req:Y ; txt:<?php echo _('Coefficient'); ?>; lmn:1 ; lmx:10; stok:frmok ; stbad:frmbad",
            "nom:nota ; format:txt ; req:N ; txt:<?php echo _('Notes'); ?> ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_ind == FALSE) { ?>
        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                init_fdeci('coeff', <?php echo valsession('num_nbdec'); ?>);
                <?php
                switch ($td)
                {
                    case 'add' :
                        echo "init_valid_form('enr','ind_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                        break;
                    case 'edit' :
                        echo "init_valid_form('enr','ind_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                        break;
                    case 'view' :
                        echo 'readonly_all();';
                        break;
                    case 'del' :
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                }
                ?>
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';
if ($pbm_ind == FALSE) {
    cre_ent_form($titre, 'ind_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="ind_maj" id="ind_maj" method="post" action="ind_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="10%" class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                <td width="47%">
                    <input name="code" type="text" id="code" value="<?php echo $ind_code ?>"
                           size="5" <?php if (($td <> 'add') && ($td <> 'edit')) {
                        echo 'readonly="readonly"';
                    } ?>>
                    <?php if ($td == 'add') { ?>
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    <?php } ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_desc" align="right"><?php echo _('Libellé'); ?></td>
                <td><input name="desc" type="text" id="desc" value="<?php echo $ind_desc; ?>"
                           size="50" <?php if (($td <> 'add') && ($td <> 'edit')) {
                        echo 'readonly="readonly"';
                    } ?>>
                    <?php if ($td == 'add') { ?>
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    <?php } ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_taux" align="right"><?php echo _('Coefficient'); ?></td>
                <td>
                    <?php
                    cre_input_num('coeff', $ind_coeff);
                    ?>
                </td>
            </tr>
            <tr>
                <td height="37" class="rubfrm" id="f_nota" align="right"><?php echo _('Notes'); ?></td>
                <td>
                    <textarea name="nota" rows="5" id="nota"><?php echo $ind_nota; ?></textarea>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_actif" align="right"><?php echo _('Actif'); ?></td>
                <td>
                    <?php
                    cre_select('actif', 'actif', $non_oui, (int)$ind_actif);
                    ?>
                </td>
            </tr>
        </table>
        <p align="center">
            <?php
            switch ($td) {
                case 'add' :
                case 'edit' :
                    if ($nu <> -1) {
                        echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Enregistrer') . '">';
                    } else {
                        echo '<input name="valid" type="submit" class="bton_std" id="valid" value="' . _('Valider') . '">';
                    }
                    echo '<input name="RAZ" type="reset" class="bton_std" id="RAZ" value="' . _('Réinitialiser') . '">';
                    break;
                case 'del' :
                    echo '<input name="del" type="submit" class="bton_std" id="del" value="' . _('Supprimer') . '">';
                    break;
            }
            ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'ind_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>