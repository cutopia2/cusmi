<br/>
<br/>
<hr noshade>
<table width="100%" border="0">
    <tr>
        <td width="33%" align="left">&nbsp;</td>
        <td width="33%" align="center">
            <?php
            if ($url_cal <> '') {
                cre_falselnk('', 'lnkext_cal', 'div', '', _('Calendrier'), $url_cal, '../img/calendar.png', _('Calendrier'));
            }
            if ($url_fac <> '') {
                echo ' / ';
                cre_falselnk('', 'lnkext_fact', 'div', '', _('Facture'), $url_fac, '../img/fact.png', _('Facture'));
            }
            ?>
        </td>
        <td width="33%" align="right">
		<span class="annot_petit_it">
		<?php
        echo ' <img src="../img/logo_small.gif" align="absmiddle">';
        echo ' ' . $smiver;
        ?>
		</span>
        </td>
    </tr>
</table>
