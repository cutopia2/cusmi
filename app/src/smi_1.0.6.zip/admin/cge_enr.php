<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_txt.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_fic.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/func_txtcm.inc.php';
include_once '../inc/func_mail.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
include_once '../classes/phpmailer/class.phpmailer.php';
include_once '../classes/phpmailer/class.smtp.php';
include_once '../inc/mail.inc.php';

include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$creation = valpost('creation');

$code = valpost('code');
$pass = valpost('pass');

$nom = str_majuscules(valpost('nom'));
$rcs = str_majuscules(valpost('rcs'));
$ape = str_majuscules(valpost('ape'));
$tvai = str_majuscules(valpost('tvai'));
$tcom = str_majuscules(valpost('tcom'));
$adr1 = str_majuscules(valpost('adr1'));
$adr2 = str_majuscules(valpost('adr2'));
$dep = valpost('dep');
$ville = str_majuscules(valpost('ville'));
$pays = str_majuscules(valpost('pays'));
$telf = valpost('telf');
$txttelf = valpost('txttelf');
$fax = valpost('fax');
$txtfax = valpost('txtfax');
$web = valpost('web');
$heures = valpost('heures');
$email = strtolower(valpost('email'));
$emaild = strtolower(valpost('emaild'));
$emailc = strtolower(valpost('emailc'));
$emailt = strtolower(valpost('emailt'));
$emailf = strtolower(valpost('emailf'));
$emaili = strtolower(valpost('emaili'));
$emailrh = strtolower(valpost('emailrh'));
$nota = valpost('nota');

$retourliste = FALSE;
$cree = FALSE;

// MAJ de la fiche centre de gestion

$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
$sql = 'SELECT COUNT(*) FROM `' . TBCG . '`';
$nb_res = $db->get_var($sql);
$rsge = 'SELECT cge_id FROM `' . TBCG . '`';
$row = $db->get_row($rsge, ARRAY_A);

switch ($nb_res) {
    // Pas d'enregistrement : on crée
    case 0 :
        $passcrypt = md5($pass);
        $rech = 'INSERT INTO `' . TBCG . '`';
        $rech .= ' (cge_datemod,cge_code,cge_pass,cge_nom,cge_rcs,cge_ape,cge_tvai,cge_tcom,cge_adr1,cge_adr2,cge_dep,cge_ville,cge_codepays,';
        $rech .= 'cge_telf,cge_txttelf,cge_fax,cge_txtfax,cge_email,cge_emaild,cge_emailc,cge_emailt,cge_emailf,cge_emaili,cge_emailrh,';
        $rech .= 'cge_heures,cge_web,cge_nota) VALUES';
        $rech .= " ('$datea','" . $db->escape($code) . "','$passcrypt','" . $db->escape($nom) . "','$rcs','$ape','$tvai','" . $db->escape($tcom) . "','" . $db->escape($adr1) . "','" . $db->escape($adr2) . "','" . $db->escape($dep) . "','$ville','$pays','$telf',";
        $rech .= "'" . $db->escape($txttelf) . "','$fax','" . $db->escape($txtfax) . "','$email','$emaild','$emailc','$emailt','$emailf','$emaili','$emailrh','$heures','$web','" . $db->escape($nota) . "')";
        $db->query($rech);
        $msg = _('Fiche ajoutée');
        $retourliste = TRUE;

        // Ajout du compte pour connexion
        // Niveau par défaut : 5
        // Actif par défaut
        $log_ip = $_SERVER['REMOTE_ADDR']; // Récupération adresse IP
        $rech2 = 'INSERT INTO `' . TBPW . "`(pw_code,pw_pass,pw_level,pw_lastsuccess,pw_lastip,pw_actif) VALUES ('" . $db->escape($code) . "','$passcrypt','5','$datea','$log_ip','1')";
        $db->query($rech2);

        $cree = TRUE;

        break;
    // Un d'enregistrement : on met à jour
    case 1 :
        if ($row) {
            extract($row);
            $rech = 'UPDATE `' . TBCG . "` SET `cge_datemod`='" . $datea . "',`cge_nom`='" . $db->escape($nom) . "', `cge_rcs`='" . $rcs . "',";
            $rech .= " `cge_ape`='" . $ape . "', `cge_tvai`='" . $tvai . "', `cge_tcom`='" . $db->escape($tcom) . "', `cge_adr1`='" . $db->escape($adr1) . "',";
            $rech .= " `cge_adr2`='" . $db->escape($adr2) . "', `cge_dep`='" . $db->escape($dep) . "', `cge_ville`='" . $ville . "', `cge_codepays`='" . $pays . "',";
            $rech .= " `cge_telf`='" . $telf . "', `cge_txttelf`='" . $db->escape($txttelf) . "', `cge_fax`='" . $fax . "', `cge_txtfax`='" . $db->escape($txtfax) . "',";
            $rech .= " `cge_email`='" . $email . "', `cge_emaild`='" . $emaild . "', `cge_emailc`='" . $emailc . "', `cge_emailt`='" . $emailt . "',";
            $rech .= " `cge_emailf`='" . $emailf . "', `cge_emaili`='" . $emaili . "',`cge_emailrh`='" . $emailrh . "', `cge_heures`='" . $heures . "',";
            $rech .= " `cge_web`='" . $web . "', `cge_nota`='" . $db->escape($nota) . "'  WHERE `cge_id` = '" . $cge_id . "'";
            $db->query($rech);
            $msg = _('Fiche modifiée');
            $retourliste = TRUE;
        } else {
            $msg = _('Erreur dans la mise à jour du centre gestion');
        }
        break;
    // Sinon, erreur
    default :
        $msg = _('Erreur dans la création du centre gestion');
        break;
}
close_database();

// Envoi d'email vers l'agence
if ($cree == TRUE) {
    envoi_mail('', _('Création du siège'), 'cdg', 'cre', 'xxx', 'cdg', $codea, $pass, '', TRUE);
}
?>

<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche Centre de Gestion'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            <?php
            if ($retourliste == FALSE)
                {echo "warn_txt('" . str_escape($msg) . "');";}
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    aff_ret_idx_man($td, 'cge_maj.php', _('Retour à la saisie'), FALSE);
} else {
    $url_retour = 'index.php';
    if ($cree == TRUE) {
        $url_retour = 'logo_maj.php?td=cge';
        pop_ret_auto($msg, 'ok', $url_retour);
    } else {
        pop_ret_auto($msg, 'ok', $url_retour);
    }
}
include_once 'pied.php';
?>
</body>
</html>
