<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$code = str_majuscules(valpost('code'));
$nom = str_majuscules(valpost('nom'));

$retourliste = TRUE;
$msg = '';

$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
switch ($td) {
    // Ajout de la fiche Mode
    case 'add' :
        $rech = 'SELECT COUNT(*) FROM `' . TBMD . "` WHERE `md_code` = '$code'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $rech2 = 'INSERT INTO `' . TBMD . "` (md_code,md_nom) VALUES ('" . $db->escape($code) . "','" . $db->escape($nom) . "')";
            $db->query($rech2);
            $msg = _('Fiche ajoutée');
        } else {
            $msg = _('Ce code existe déjà');
            $retourliste = FALSE;
        }
        break;

    // Modification de la fiche Mode
    case 'edit' :
        $rech = 'UPDATE `' . TBMD . "` SET `md_nom`='" . $db->escape($nom) . "' WHERE `md_code` = '" . $code . "'";
        $db->query($rech);
        $msg = _('Fiche modifiée');
        break;

    // Suppression de la fiche Mode
    case 'del' :
        // Vérifie si utilisé dans une fiche demande
        $rech = 'SELECT COUNT(*) FROM `' . TBRETD . "` WHERE `retd_codemd` = '$code'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs <> 0) {
            $msg = _('Ce mode de demande est utilisé dans une demande de retour');
            $retourliste = FALSE;
        } else {
            $rech = 'SELECT COUNT(*) FROM `' . TBMD . "` WHERE `md_code` = '$code' AND `md_del` = '1'";
            $nb_rs = $db->get_var($rech);
            if ($nb_rs == 1) {
                // Non - > suppression de la fiche Mode
                $rech = 'DELETE FROM `' . TBMD . "` WHERE `md_code` = '$code'";
                $db->query($rech);
                $msg = _('Fiche supprimée');
            } else {
                $msg = _('Suppression impossible');
                $retourliste = FALSE;
            }
        }
        break;
}
close_database();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche mode de demande'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>
<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    exec_func_js("warn_txt('" . str_escape($msg) . "')");
    aff_ret_idx_man($td, 'md_lst.php', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'md_lst.php');
}

include_once 'pied.php';
?>
</body>
</html>