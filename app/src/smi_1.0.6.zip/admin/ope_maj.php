<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_geol.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/fic_hum.inc.php';
include_once '../inc/fic_ope.inc.php';
//
include_once '../classes/geoplugin/geoplugin.class.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../classes/geoplugin/geoplugin.class.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$td = $_GET['td'];
$coderech = $_GET['code'];
$ope_dep = $_GET['dep'];
$ope_codepays = $_GET['pays'];

$pbm_ope = FALSE;
$sais_dteout = TRUE;
$sais_dconges = TRUE;
$sais_fconges = TRUE;

if ($coderech <> '') {
    $row = lit_enr_ope($coderech);
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);

        if ($ope_out == TRUE) {
            $td = 'view';
        }

        $ope_datecreaf = datetolocal($ope_datecrea);
        $ope_dateoutf = datetolocal($ope_dateout);
        $ope_congd = datetolocal($ope_congd);
        $ope_congf = datetolocal($ope_congf);

    } else {
        $pbm_ope = TRUE;
    }
} else {
    if ($td == 'add') {
        $ope_code = crecodesession('O');
        $ope_codepays = pays_connect_code($_SERVER['REMOTE_ADDR']);
    } else {
        $pbm_ope = TRUE;
    }
}

switch ($td) {
    case 'add' :
        $titre = _('CREATION OPERATEUR');
        $sais_dteout = FALSE;
        $sais_dconges = FALSE;
        $sais_fconges = FALSE;
        break;
    case 'edit' :
        $titre = _('MISE A JOUR OPERATEUR');
        break;
    case 'del' :
        $titre = _('SUPPRESSION OPERATEUR');
        $sais_dteout = FALSE;
        $sais_dconges = FALSE;
        $sais_fconges = FALSE;
        break;
    case 'view' :
        $titre = _('VISUALISATION OPERATEUR');
        $sais_dteout = FALSE;
        $sais_dconges = FALSE;
        $sais_fconges = FALSE;
        break;
    default :
        $pbm_ope = TRUE;
        break;
}
?>
    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
    <html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche Opérateur'); ?></title>

        <?php include_once '../inc/header.inc.php'; ?>

        <script language="javascript">
            <!--
            const tab1_champ = [
                <?php
                if ($td=='add')
                    {echo '"nom:datecreaf ; format:date ; masque:'.$_SESSION['date_fmtfull'].' ; req:Y ; txt:'._('Date embauche').' ; stok:frmok ; stbad:frmbad",';}
                ?>
                "nom:civil ; format:liste ; req:Y ; txt:<?php echo _('Civilité'); ?> ; vmn:1 ; stok:frmok ; stbad:frmbad",
                "nom:prenom ; format:txt ; req:Y ; txt:<?php echo _('Prénom'); ?> ; lmx:50 ; stok:frmok ; stbad:frmbad",
                "nom:nom ; format:txt ; req:Y ; txt:<?php echo _('Nom'); ?> ; lmx :50 ; stok:frmok ; stbad:frmbad",
                "nom:adr1 ; format:txt ; req:Y ; txt:<?php echo _('Adresse'); ?> ; lmx:50 ; stok:frmok ; stbad:frmbad",
                "nom:adr2 ; format:txt ; req:N ; txt:<?php echo _('Adresse (2)'); ?> ; lmx:50 ; stok:frmok ; stbad:frmbad",
                "nom:ville ; format:liste ; req:Y ; txt:<?php echo _('Ville'); ?> ; vmn:1 ; stok:frmok ; stbad:frmbad",
                "nom:dep ; format:liste ; req:Y ; txt:<?php echo _('Département'); ?> ; vmn:1 ; stok:frmok ; stbad:frmbad",
                "nom:pays ; format:liste ; req:Y ; txt:<?php echo _('Pays'); ?> ; vmn:1 ; stok:frmok ; stbad:frmbad",
                "nom:telf ; format:tel ; req:Y ; txt:<?php echo _('Téléphone Fixe'); ?> ; stok:frmok ; stbad:frmbad",
                "nom:telp ; format:telp ; req:N ; txt:<?php echo _('Téléphone portable'); ?> ; stok:frmok ; stbad:frmbad",
                "nom:email ; format:mail ; req:Y ; txt:<?php echo _('Email'); ?> ; stok:frmok ; stbad:frmbad",
                "nom:nota ; format:txt ; req:N ; txt:<?php echo _('Notes'); ?> ; stok:frmok ; stbad:frmbad"];
            //-->
        </script>

        <?php if ($pbm_ope == FALSE) { ?>
            <script type="text/javascript">
                <!--
                $(function () {
                    $("#code").Setcase({caseValue: 'upper', changeonFocusout: true});
                    $("#nom").Setcase({caseValue: 'upper', changeonFocusout: true});
                    $("#adr1").Setcase({caseValue: 'upper', changeonFocusout: true});
                    $("#adr2").Setcase({caseValue: 'upper', changeonFocusout: true});
                    $("#email").Setcase({caseValue: 'lower', changeonFocusout: true});
                    $("#prenom").Setcase({caseValue: 'allfirst', changeonFocusout: true});
                });

                function init_datepicker() {
                    <?php include_once '../jscript/datepicker_prm.js.php'; ?>
                    <?php if ($sais_dteout == TRUE) { ?>
                    $("#dateoutf").datepicker({
                        onSelect: function (datesel) {
                            $("#dateoutf").blur();
                            return chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, 'datecreaf,dconges,fconges', '', 'today', false);
                        }
                    });
                    <?php }

                    if ($sais_dconges == TRUE) { ?>
                    $("#dconges").datepicker({
                        onSelect: function (datesel) {
                            $("#dconges").blur();
                            return chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, '', '', 'dateoutf,fconges', false);
                        }
                    });
                    <?php }

                    if ($sais_fconges == TRUE) { ?>
                    $("#fconges").datepicker({
                        onSelect: function (datesel) {
                            $("#fconges").blur();
                            return chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, 'dconges,today', '', 'dateoutf', false);
                        }
                    });
                    <?php } ?>
                }

                function init_all() {
                    init_Body();
                    init_datepicker();
                    init_ajax_ville();
                    init_ajax_dep();
                    init_autohref('annul', 'click', 'ope_lst.php', false);
                    init_autoraz('razdatecreaf', 'dateoutf', 'click');
                    init_autoraz('razdateoutf', 'dateoutf', 'click');
                    init_autoraz('razconges', 'dconges', 'click');
                    init_autoraz('razconges', 'fconges', 'click');
                    <?php
                     switch ($td)
                     {
                        case 'add' :
                            echo '$("#datecreaf").datepicker({';
                            echo ' onSelect: function (datesel) {';
                            echo ' $("#datecreaf").blur();';
                            echo 'var messerr = chk_dte_today(this.id, \''.valsession('date_fmtshort').'\', 0, true);';
                            echo ' if (messerr != \'\') {';
                            echo 'warn_txt(messerr);';
                            echo '}';
                            echo '},';
                            echo '});';
                            echo "init_valid_ope('val','ope_maj','".valsession('date_fmtshort')."',tab1_champ,'pays','');";
                            break;
                        case 'edit' :
                            echo "init_valid_ope('val','ope_maj','".valsession('date_fmtshort')."',tab1_champ,'pays','');";
                            break;
                         case 'del' :
                            echo 'readonly_all();';
                            echo "warn_del('ope');";
                            break;
                         case 'view' :
                            echo 'readonly_all();';
                            break;
                         default :
                            break;
                     }
                     ?>
                    Focus_first();
                }

                $(document).ready(function () {
                    init_all();
                });
                //-->
            </script>

        <?php } ?>
    </head>

<body>

<?php
include_once '../inc/entete.inc.php';

if ($pbm_ope == FALSE) {
    if (nb_civ() <> 0) {
        cre_ent_form($titre, 'ope_lst.php', $_SERVER['HTTP_REFERER']);
        ?>
        <form name="ope_maj" id="ope_maj" method="post" action="ope_enr.php">
            <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
            <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
            <input name="today" type="hidden" id="today" value="<?php echo $datef; ?>">
            <input name="nbutton" type="hidden" id="nbutton" value="">
            <?php
            if ($td == 'add') { ?>
                <input name="code" type="hidden" id="code" value="<?php echo $ope_code ?>">
                <input name="salarie" type="hidden" id="salarie" value="Oui">
                <?php
            } else { ?>
                <table width="100%" border="0">
                    <tr>
                        <td width="160" class="rubfrm" id="f_codetec" align="right"><?php echo _('Code'); ?></td>
                        <td><input name="code" type="text" id="code" value="<?php echo $ope_code ?>" readonly></td>
                    </tr>
                </table>
            <?php } ?>
            <table width="100%" border="0">
                <tr>
                    <td width="160" class="rubfrm" id="f_datecreaf" align="right">
                        <?php echo _('Embauche'); ?>
                    </td>
                    <td>
                        <?php
                        echo '<input name="datecreaf" type="text" id="datecreaf"';
                        echo ' value="' . $ope_datecreaf . '" size="10"';
                        echo 'readonly="1"';
                        echo '>';
                        if ($td == 'add') {
                            echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                            echo ' <img src="../img/raz.png" id="razdatecreaf" border="0" align="absmiddle">';
                        }
                        ?>
                    </td>
                </tr>
                <?php if (($td == 'edit') || ($td == 'del') || ($td == 'view')) { ?>
                    <tr>
                        <td width="160" class="rubfrm" id="f_dateoutf" align="right">
                            <?php echo _('Départ'); ?>
                        </td>
                        <td>
                            <?php
                            echo '<input name="dateoutf" type="text" id="dateoutf"';
                            echo ' value="' . $ope_dateoutf . '" size="10"';
                            echo 'readonly="1"';
                            echo '>';
                            echo ' <img src="../img/raz.png" id="razdateoutf" border="0" align="absmiddle">';
                            if ($ope_out == FALSE) {
                                echo '<div class="annot_petit_it">' . _("Si vous saisissez une date, l'opérateur ne sera plus considéré comme salarié") . '</div>';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td width="160" class="rubfrm" id="f_conges" align="right"><?php echo _('Congés'); ?></td>
                        <td colspan="3">
                            <span class="annot_petit_gras">du</span>
                            <input name="dconges" type="text" id="dconges" value="<?php echo $ope_congd; ?>" size="10"
                                   maxlength="10" readonly>
                            <span class="annot_petit_gras"> <?php echo _('au'); ?> </span>
                            <input name="fconges" type="text" id="fconges" value="<?php echo $ope_congf; ?>" size="10"
                                   maxlength="10" readonly>
                            <?php
                            if ($ope_out == FALSE) {
                                echo ' <img src="../img/raz.png" id="razconges" border="0" align="absmiddle">';
                                echo '<div class="annot_petit_it">' . _('Prochains congés ou congés en cours') . '</div>';
                            }
                            ?>
                        </td>
                    </tr>
                <?php } ?>
                <tr>
                    <td width="160" class="rubfrm" id="f_civil" align="right"><?php echo _('Civilité'); ?></td>
                    <td>
                        <?php
                        // Création de la liste des civilités
                        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                        $rech = 'SELECT * FROM `' . TBCIV . '` ORDER BY civ_desc';
                        $rows = $db->get_results($rech, ARRAY_A);
                        cre_select_tab('civil', 'civil', $rows, 'civ_code', 'civ_desc', '', $ope_civilite, '', _('-- Faites votre choix --'));
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_prenom" align="right"><?php echo _('Prénom'); ?></td>
                    <td><input name="prenom" type="text" id="prenom" value="<?php echo $ope_prenom ?>" size="50">
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_nom" align="right"><?php echo _('Nom'); ?></td>
                    <td><input name="nom" type="text" id="nom" value="<?php echo $ope_nom ?>" size="50">
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_adr1" align="right"><?php echo _('Adresse'); ?></td>
                    <td><input name="adr1" type="text" id="adr1" value="<?php echo $ope_adr1 ?>" size="50">
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_adr2" align="right"><?php echo _('Adresse (2)'); ?></td>
                    <td><input name="adr2" type="text" id="adr2" value="<?php echo $ope_adr2 ?>" size="50"></td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_pays" align="right"><?php echo _('Pays'); ?></td>
                    <td>
                        <?php
                        // Création de la liste des pays
                        $rows = give_rows_pays();
                        cre_select_tab('pays', 'pays', $rows, 'pays_code', 'pays_nom', '', $ope_codepays, '', _('-- Faites votre choix --'), 1, FALSE, '-1', _('-- Inconnu --'));
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_dep" align="right"><?php echo _('Département'); ?></td>
                    <td>
                        <?php
                        // Création de la liste des départements
                        $rows = give_rows_dep($ope_codepays);
                        cre_select_tab('dep', 'dep', $rows, 'dep_code', 'dep_code', 'dep_nom', $ope_dep, '', _('-- Faites votre choix --'), 1, FALSE, '-1', _('-- Inconnu --'));
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_ville" align="right"><?php echo _('Ville'); ?></td>
                    <td>
                        <?php
                        // Création de la liste des villes
                        $rows = give_rows_villes($ope_dep, $ope_codepays);
                        cre_select_tab('ville', 'ville', $rows, 'villes_id', 'villes_nom', 'villes_cp', $ope_ville, '', _('-- Faites votre choix --'), 1, FALSE, '-1', _('-- Inconnu --'));
                        ?>
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_telf" align="right"><?php echo _('Téléphone Fixe'); ?></td>
                    <td><input name="telf" type="text" id="telf" value="<?php echo $ope_telf ?>" size="20"
                               maxlength="20">
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
                </tr>
                <tr>
                    <td width="160" class="rubfrm" id="f_telp" align="right"><?php echo _('Téléphone portable'); ?></td>
                    <td><input name="telp" type="text" id="telp" value="<?php echo $ope_telp ?>" size="20"
                               maxlength="20">
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_email" align="right"><?php echo _('Email'); ?></td>
                    <td>
                        <input name="email" type="text" id="email" value="<?php echo $ope_email ?>" size="50"
                               maxlength="50">
                        <?php if ($td == 'edit') {
                            if ($ope_email <> '') {
                                ?>
                                <a href="mailto:<?php echo $ope_email ?>"><img src="../img/mail.png"
                                                                               title="<?php echo _('Envoyer e-mail'); ?>"
                                                                               border="0" align="absmiddle"></a>
                            <?php }
                        } ?>
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    </td>
                </tr>
                <tr>
                    <td class="rubfrm" id="f_nota" align="right"><?php echo _('Notes'); ?></td>
                    <td><textarea name="nota" id="nota"><?php echo $ope_nota ?></textarea></td>
                </tr>
            </table>
            <p align="center">
                <?php if (($td == 'edit') || ($td == 'add')) {
                    if ($ope_out == TRUE) {
                        ?>
                        <input name="annul" type="button" class="bton_std" id="annul"
                               value="<?php echo _('Retour liste'); ?>">
                        <?php
                    } else {
                        ?>
                        <input name="RAZ" type="reset" class="bton_std" id="RAZ"
                               value="<?php echo _('Réinitialiser'); ?>">
                        <input name="val" type="button" class="bton_std" id="val"
                               value="<?php echo _('Enregistrer'); ?>">
                        <?php
                    }
                }
                ?>
                <?php if ($td == 'del') { ?>
                    <input name="del" type="submit" class="bton_std" id="del" value="<?php echo _('Supprimer'); ?>">
                <?php } ?>
            </p>
        </form>

        <!-- Fin affiché uniquement s'il y a au moins une une civilité -->
        <?php
    } else {
        pop_ret_auto(_('Aucune civilité'), 'warn', 'civ_lst.php');
    }
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'ope_lst.php');
}
include_once 'pied.php';
?>