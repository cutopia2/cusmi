<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_pat.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);
$_SESSION['obj_idnomenc_enfants'] = [];
$_SESSION['obj_idnomenc_parents'] = [];
$_SESSION['obj_idnomenc_to_be_enfants'] = [];
$tab_obj_enfants = [];
$tab_obj_parents = [];
$tab_obj_to_be_enfants = [];

$td = $_GET['td'];
$coderech = $_GET['code'];

$pbm_robj = FALSE;
$robj_id = 0;
$sel_obj = TRUE;

if ($coderech <> '') {
    $row = lit_enr_robj($coderech);
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);

        $row2 = lit_enr_rto($robj_coderto);
        if (is_array($row2)) {
            $row2 = encode_str($row2);
            extract($row2);

            if ($rto_mob == 1) {
                $row3 = lit_enr_rmob($robj_id);
                if (is_array($row3)) {
                    $row3 = encode_str($row3);
                    extract($row3);
                }
            } else {
                $row3 = lit_enr_rimmob($robj_id);
                if (is_array($row3)) {
                    $row3 = encode_str($row3);
                    extract($row3);
                }
            }

            if ($rto_assu == 1) {
                $row3 = lit_enr_rassur($robj_id);
                if (is_array($row3)) {
                    $row3 = encode_str($row3);
                    extract($row3);
                    $rassur_dateechf = datetolocal($rassur_dateech);
                }
            }
        }


        // Formatage des dates en français
        $robj_datecreaf = datetolocal($robj_datecrea);
        $robj_datemodf = datetolocal($robj_datemod);
        $robj_datefabf = datetolocal($robj_datefab);
        $robj_dateachf = datetolocal($robj_dateach);

        // Création du tableau des objets enfants de l'objet édité
        $tab_obj_enfants = cree_tab_obj_enfants($robj_id);

        // Création du tableau des objets parents de l'objet édité
        $tab_obj_parents = cree_tab_obj_parents($robj_id);

        /*
                // Création du tableau des objets pouvant être enfants
                $tab_obj_to_be_enfants = cree_tab_obj_to_be_enfants($robj_id);

                echo "tab_enfants : ";
                print_r($tab_obj_enfants);
                echo'<br>';

                echo "tab_id_enfants : ";
                print_r($_SESSION['obj_idnomenc_enfants']);
                echo'<br>';

                echo "tab_parents : ";
                print_r($tab_obj_parents);
                echo'<br>';

                echo "tab_id_parents : ";
                print_r($_SESSION['obj_idnomenc_parents']);
                echo'<br>';

                echo "tab_to_be_enfants : ";
                print_r($tab_obj_to_be_enfants);
                echo'<br>';

                echo "tab_id_to_be_enfants : ";
                print_r($_SESSION['obj_idnomenc_to_be_enfants']);
                echo'<br>';
        */
    } else {
        $pbm_robj = TRUE;
    }
} else {
    if ($td == 'add') {
        $robj_code = '';
        $robj_desc = '';
        $robj_datecreaf = $datef;
        $robj_datemodf = $datef;
        $robj_dateachf = '';
        $robj_datefabf = '';
        $robj_daterassurechf = '';
        $robj_pa = 0;
        $robj_vr = 0;
        $robj_coderto = '';
        $rto_comp = 0;
        $rto_mque = 0;
        $rto_ns = 0;
        $rto_mob = 0;
        $rto_assu = 0;
    } else {
        $pbm_robj = TRUE;
    }
}

switch ($td) {
    case 'add' :
        $titre = _('CREATION OBJET');
        break;
    case 'edit' :
        $titre = _('MODIFICATION OBJET');
        break;
    case 'view' :
        $titre = _('VISUALISATION OBJET');
        $sel_obj = FALSE;
        break;
    case 'del' :
        $titre = _('SUPPRESSION OBJET');
        $sel_obj = FALSE;
        break;
    default :
        $pbm_robj = TRUE;
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Patrimoines - Fiche objet'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab1_champ = ["nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?> ; lmx:20 ; stok:frmok ; stbad:frmbad",
            "nom:desc; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?> ; lmx:40 ; stok:frmok ; stbad:frmbad",
            "nom:coderto; format:liste ; req:Y ; txt:<?php echo _('Type'); ?> ; vmn:1 ; stok:frmok ; stbad:frmbad",
            "nom:coderpet; format:liste ; req:Y ; txt:<?php echo _('Etat'); ?> ; vmn:1 ; stok:frmok ; stbad:frmbad",
            "nom:coderta; format:liste ; req:Y ; txt:<?php echo _('Type acquisition'); ?> ; vmn:1 ; stok:frmok ; stbad:frmbad",
            "nom:numinv; format:liste ; req:Y ; txt:<?php echo _('Numéro inventaire'); ?> ; vmn:1 ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_robj == FALSE) { ?>
        <script type="text/javascript">
            <!--
            $(function () {
                $("#code").Setcase({caseValue: 'upper', changeonFocusout: true});
                $("#desc").Setcase({caseValue: 'upper', changeonFocusout: true});
            });

            function init_datepicker() {
                <?php include_once '../jscript/datepicker_prm.js.php'; ?>
                $("#datefabf").datepicker({
                    onSelect: function (datesel) {
                        $("#datefabf").blur();
                        chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, '', '', 'dateachf,today', false);
                    }
                });
                $("#dateachf").datepicker({
                    onSelect: function (datesel) {
                        $("#dateachf").blur();
                        chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, 'datefabf', '', 'today', false);
                    }
                });
                <?php
                if ($td=='edit')
                {
                ?>
                $("#datesortief").datepicker({
                    onSelect: function (datesel) {
                        $("#datesortief").blur();
                        if (chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, 'datefabf,dateachf', '', '', false)) {
                            chk_aff_detailsortie(this.id, 'detsortie', 'detailsortie');
                        }
                    }
                });
                <?php
                }
                ?>
            }

            function init_all() {
                init_Body();
                $("#onglets_obj").tabs();
                init_datepicker();
                init_fdeci('pa', <?php echo valsession('num_nbdec'); ?>);
                init_fdeci('vr', <?php echo valsession('num_nbdec'); ?>);
                init_fdeci('vr', <?php echo valsession('num_nbdec'); ?>);
                init_fdeci('surf', <?php echo valsession('num_nbdec'); ?>);
                init_fdeci('rassurcotis', <?php echo valsession('num_nbdec'); ?>);
                init_fdeci('rassurva', <?php echo valsession('num_nbdec'); ?>);
                <?php
                 switch ($td)
                 {
                     case 'add' :
               		    echo '$( "#dateachf" ).datepicker();';
                        echo "init_autoraz('razdateachf','dateachf','click');";
               		    echo '$( "#datefabf" ).datepicker();';
                        echo "init_autoraz('razdatefabf','datefabf','click');";
               		    echo '$( "#rassurdateechf" ).datepicker();';
                        echo "init_autoraz('razrassurdateechf','rassurdateechf','click');";
                        echo 'init_ajax_to();';
                        echo "init_valid_robj('enr','robj_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                     case 'edit' :
               		    echo '$( "#dateachf" ).datepicker();';
                        echo "init_autoraz('razdateachf','dateachf','click');";
               		    echo '$( "#datefabf" ).datepicker();';
                        echo "init_autoraz('razdatefabf','datefabf','click');";
               		    echo '$( "#datesortief" ).datepicker();';
                        echo "init_autoraz('razdatesortief','datesortief','click');";
                        echo "init_autoraz('razdatesortief','detailsortie','click');";
               		    echo '$( "#rassurdateechf" ).datepicker();';
                        echo "init_autoraz('razrassurdateechf','rasssurdateechf','click');";
                        echo 'init_ajax_to();';
                        echo "readonly_id('code',false);";
                        echo "init_valid_robj('enr','robj_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                     case 'view' :
                        echo 'readonly_all();';
                        break;
                     case 'del' :
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                 }
                ?>
                init_ajax_ville();
                init_ajax_dep();
                init_ajax_robj_objachoisir();
                init_ajax_robj_add_enfant();
                init_ajax_robj_del_enfant();
                chk_aff_messcont('tocont');
                chk_aff_icocont('tcocont', true);
                chk_aff_messcomp('tocomp');
                chk_aff_icomobimmob('tomob', true);
                init_display_id('addimmob', 'popaddimmob', true, 'click');
                init_hide_id('closedetailimmob', 'popaddimmob', 'click');
                init_hide_id('valaddimmob', 'popaddimmob', 'click');
                init_display_id('addmob', 'popaddmob', true, 'click');
                init_hide_id('closedetailmob', 'popaddmob', 'click');
                init_hide_id('valaddmob', 'popaddmob', 'click');
                init_display_id('addnomenc', 'popnomenc', true, 'click');
                init_hide_id('closedetailnomenc', 'popnomenc', 'click');
                init_hide_id('valnomenc', 'popnomenc', 'click');
                chk_aff_mque('tomque');
                chk_aff_ns('tons');
                chk_aff_icoassu('toassu');
                chk_aff_detailsortie('datesortief', 'detsortie', 'detailsortie');
                init_display_id('addassu', 'popaddassu', true, 'click');
                init_hide_id('closedetailassu', 'popaddassu', 'click');
                init_hide_id('valaddassu', 'popaddassu', 'click');
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';

if ($pbm_robj == FALSE) {
    cre_ent_form($titre, 'robj_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="robj_maj" id="robj_maj" method="post" action="robj_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="today" type="hidden" id="today" value="<?php echo $datef; ?>">
        <input name="tocont" type="hidden" id="tocont" value="<?php echo $rto_cont; ?>">
        <input name="tocomp" type="hidden" id="tocomp" value="<?php echo $rto_comp; ?>">
        <input name="tomque" type="hidden" id="tomque" value="<?php echo $rto_mque; ?>">
        <input name="tons" type="hidden" id="tons" value="<?php echo $rto_ns; ?>">
        <input name="tomob" type="hidden" id="tomob" value="<?php echo $rto_mob; ?>">
        <input name="toassu" type="hidden" id="toassu" value="<?php echo $rto_assu; ?>">
        <input name="objid" type="hidden" id="objid" value="<?php echo $robj_id; ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">

        <?php
        // DIV de pop pour objets mobiles
        echo '<div align="center" id="popaddmob" class="pop_detailobj">';
        echo '<div align="right">';
        echo ' <img src="../img/close.gif" id="closedetailmob" title="' . _('Fermer') . '" border="0" align="absmiddle">';
        echo '</div>';
        echo '<div class="annot_gras_it" align="center">';
        echo _('OBJET MOBILE - COORDONNEES');
        echo '</div>';

        echo '<table width="100%" border="0">';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_immat" align="right">' . _('Immatriculation') . '</td>';
        echo '<td>';
        echo '<input name="immat" type="text" id="immat" value="' . $rmob_immat . '" size="20">';
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_cg" align="right">' . _('Carte Grise') . '</td>';
        echo '<td>';
        echo '<input name="cg" type="text" id="cg" value="' . $rmob_cg . '" size="20">';
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_km" align="right">' . _('Kilométrage') . '</td>';
        echo '<td>';
        cre_input_num('km', $rmob_km, FALSE, FALSE, FALSE);
        echo '</td>';
        echo '</tr>';
        echo '</table>';

        echo '<p align="center">';
        echo '<input name="valaddmob" id="valaddmob" type="button" class="bton_fgris_petit" value="' . _('Valider') . '">';
        echo '</p>';

        echo '</div>';

        echo '<div id="mess">';
        echo '<span id="messcont" class="annot_petit_it" style ="display:none">';
        echo _('Cet objet peut être un conteneur') . ' - ';
        echo '</span>';

        echo '<span id="messcomp" class="annot_petit_it" style ="display:none">';
        echo _('Cet objet peut être un composant');
        echo '</span>';
        echo '</div>';

        // DIV de popup pour objet asssurés
        echo '<div align="center" id="popaddassu" class="pop_detailobj">';
        echo '<div align="right">';
        echo ' <img src="../img/close.gif" id="closedetailassu" title="' . _('Fermer') . '" border="0" align="absmiddle">';
        echo '</div>';
        echo '<div class="annot_gras_it" align="center">';
        echo _('OBJET ASSURE - COMPLEMENTS');
        echo '</div>';
        echo '<table width="100%" border="0">';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_rasssurcodemque" align="right">' . _('Assureur') . '</td>';
        echo '<td>';
        $rows2 = [];

        // On récupère d'abord les marques "assureur"
        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
        $rech = 'SELECT mquet_code FROM `' . TBMQUET . '` WHERE `mquet_assu` = 1';
        $rows = $db->get_results($rech, ARRAY_A);

        if ($rows) {
            $rech2 = 'SELECT * FROM `' . TBMQUE . '` WHERE (';
            foreach ($rows as $row) {
                extract($row);
                $rech2 .= ' ' . TBMQUE . ".mque_codemquet = '" . $db->escape($mquet_code) . "' OR";
            }
            // Suppression du dernier 'OR'
            $rech2 = substr($rech2, 0, -3);
            $rech2 .= ')';
            $rows2 = $db->get_results($rech2, ARRAY_A);
        }

        close_database();
        cre_select_tab('rassurcodemque', 'rassurcodemque', $rows2, 'mque_code', 'mque_ste', '', $rassur_codemque, '', _('-- Faites votre choix --'));
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_rassurnumco" align="right">' . _('Numéro de contrat') . '</td>';
        echo '<td>';
        echo '<input name="rassurnumco" type="text" id="rassurnumco" value="' . $rassur_numco . '" size="50">';
        if (($td == 'add') || ($td == 'edit')) {
            echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
        }
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td class="rubfrm" id="f_rassurcotis" align="right">' . _('Cotisation') . '</td>';
        echo '<td>';
        cre_input_num('rassurcotis', $rassur_cotis, TRUE);
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td class="rubfrm" id="f_rassurva" align="right">' . _('Valeur assurée') . '</td>';
        echo '<td>';
        cre_input_num('rassurva', $rassur_va, TRUE);
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_rassurdateechf" align="right">' . _("Date d'échéance") . '</td>';
        echo '<td>';
        echo '<input name="rassurdateechf" type="text" id="rassurdateechf" value="' . $rassur_dateechf . '" size="10" maxlength="10" readonly="1">';
        if (($td == 'add') || ($td == 'edit')) {
            echo ' <img src="../img/raz.png" id ="razrassurdateechf" border="0" align="absmiddle">';
            echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
        }
        echo '</td>';
        echo '</tr>';
        echo '</table>';

        echo '<p align="center">';
        echo '<input name="valaddassu" id="valaddassu" type="button" class="bton_fgris_petit" value="' . _('Valider') . '">';
        echo '</p>';

        echo '</div>';

        // DIV de pop pour objets immobiles
        echo '<div align="center" id="popaddimmob" class="pop_detailobj">';
        echo '<div align="right">';
        echo ' <img src="../img/close.gif" id="closedetailimmob" title="' . _('Fermer') . '" border="0" align="absmiddle">';
        echo '</div>';
        echo '<div class="annot_gras_it" align="center">';
        echo _('OBJET IMMOBILE - COORDONNEES');
        echo '</div>';
        echo '<table width="100%" border="0">';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_adr1" align="right">' . _('Adresse') . '</td>';
        echo '<td>';
        echo '<input name="adr1" type="text" id="adr1" value="' . $rimmob_adr1 . '" size="50">';
        if (($td == 'add') || ($td == 'edit')) {
            echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
        }
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_adr2" align="right">' . _('Adresse (2)') . '</td>';
        echo '<td>';
        echo '<input name="adr2" type="text" id="adr2" value="' . $rimmob_adr2 . '" size="50">';
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td class="rubfrm" id="f_pays" align="right">' . _('Pays') . '</td>';
        echo '<td>';
        // Création de la liste des pays
        $rows = give_rows_pays();
        cre_select_tab('pays', 'pays', $rows, 'pays_code', 'pays_nom', '', $rimmob_codepays, '', _('-- Faites votre choix --'), 1, FALSE, '-1', _('-- Inconnu --'));
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td class="rubfrm" id="f_dep" align="right">' . _('Département') . '</td>';
        echo '<td>';
        // Création de la liste des départements
        $rows = give_rows_dep($rimmob_codepays);
        cre_select_tab('dep', 'dep', $rows, 'dep_code', 'dep_code', 'dep_nom', $rimmob_dep, '', _('-- Faites votre choix --'), 1, FALSE, '-1', _('-- Inconnu --'));
        echo '</td>';
        echo '</tr>';
        echo '</tr>';
        echo '<tr>';
        echo '<td class="rubfrm" id="f_ville" align="right">' . _('Ville') . '</td>';
        echo '<td>';
        // Création de la liste des villes
        $rows = give_rows_villes($rimmob_dep, $rimmob_codepays);
        cre_select_tab('ville', 'ville', $rows, 'villes_id', 'villes_nom', 'villes_cp', $rimmob_ville, '', _('-- Faites votre choix --'), 1, FALSE, '-1', _('-- Inconnu --'));
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_bat" align="right">' . _('Bâtiment') . '</td>';
        echo '<td>';
        echo '<input name="bat" type="text" id="bat" value="' . $rimmob_bat . '" size="20">';
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_ent" align="right">' . _('Entrée') . '</td>';
        echo '<td>';
        echo '<input name="ent" type="text" id="ent" value="' . $rimmob_ent . '" size="5">';
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_esc" align="right">' . _('Escalier') . '</td>';
        echo '<td>';
        echo '<input name="esc" type="text" id="esc" value="' . $rimmob_esc . '" size="5">';
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_et" align="right">' . _('Etage') . '</td>';
        echo '<td>';
        echo '<input name="et" type="text" id="et" value="' . $rimmob_et . '" size="3">';
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td width="160" class="rubfrm" id="f_surf" align="right">' . _('Surface') . '</td>';
        echo '<td>';
        cre_input_num('surf', $rimmob_surf, FALSE, FALSE, FALSE);
        echo '</td>';
        echo '</tr>';
        echo '</table>';

        echo '<p align="center">';
        echo '<input name="valaddimmob" id="valaddimmob" type="button" class="bton_fgris_petit" value="' . _('Valider') . '">';
        echo '</p>';

        echo '</div>';

        // DIV de pop pour nomenclature
        echo '<div align="center" id="popnomenc" class="pop_detailnomenc">';
        echo '<div align="right">';
        echo ' <img src="../img/close.gif" id="closedetailnomenc" title="' . _('Fermer') . '" border="0" align="absmiddle">';
        echo '</div>';
        echo '<div class="annot_gras_it" align="center">';
        echo _('NOMENCLATURE');
        echo '</div>';

        echo '<table width="100%" border="0">';
        echo '<tr>';
        echo '<td colspan="3" align="center">';
        // Création de la liste des types objets
        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
        $rech = 'SELECT * FROM `' . TBRTO . '` ORDER BY rto_desc';
        $rows = $db->get_results($rech, ARRAY_A);
        close_database();
        echo '<br />';
        echo _('Type Objet') . '<br />';
        echo '<br />';
        cre_select_tab('objto', 'objto', $rows, 'rto_code', 'rto_desc', '', '', '', _('-- Faites votre choix --'));
        echo '</td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td align="center">';
        echo _('Objet à choisir') . '<br />';
        echo '<br />';
        cre_select('objachoisir', 'objachoisir', $tab_obj_to_be_enfants, '', '', _('-- Faites votre choix --'), 10);
        echo '</td>';

        echo '<td align="center">';
        if ($sel_obj == TRUE) {
            echo '<input type="button" id="addobj" value="' . _('Ajouter') . '>>>">';
            echo '<br />';
            echo '<br />';
            echo '<input type="button" id="delobj" value="&lt;&lt;&lt; ' . _('Supprimer') . '">';
        } else {
            echo '&nbsp;';
        }
        echo '</td>';
        echo '<td align="center">';
        echo _('Objets enfants') . '<br />';
        echo '<br />';
        cre_select('objenfants[]', 'objenfants', $tab_obj_enfants, '', '', _('-- Faites votre choix --'), 10);
        echo '</td>';
        echo '</tr>';
        echo '</table>';


        echo '<p align="center">';
        echo '<input name="valnomenc" id="valnomenc" type="button" class="bton_fgris_petit" value="' . _('Valider') . '">';
        echo '</p>';

        echo '</div>';
        ?>

        <div id="onglets_obj">
            <ul>
                <li><a href="#obj_id"><?php echo _('Identité'); ?></a></li>
                <li><a href="#obj_inv"><?php echo _('Inventaire'); ?></a></li>
                <li><a href="#obj_val"><?php echo _('Valorisation'); ?></a></li>
                <li><a href="#obj_compl"><?php echo _('Compléments'); ?></a></li>
            </ul>
            <div id="obj_id">
                <table width="100%" border="0">
                    <tr>
                        <td width="160" class="rubfrm" id="f_actif" align="right"><?php echo _('Actif'); ?></td>
                        <td>
                            <?php
                            cre_select('actif', 'actif', $non_oui, (int)$robj_actif);
                            ?>
                            <div
                                class="annot_petit_it"><?php echo _("'Oui' : Cet objet peut être choisi / 'Non' : Il ne le peut pas"); ?></div>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                        <td>
                            <input name="code" type="text" id="code" value="<?php echo $robj_code ?>" size="20"
                                   maxlength="20">
                            <?php
                            if ($td == 'add') {
                                echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_desc" align="right"><?php echo _('Libellé'); ?></td>
                        <td><input name="desc" type="text" id="desc" value="<?php echo $robj_desc ?>" size="50">
                            <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_coderto" align="right"><?php echo _('Type'); ?></td>
                        <td>
                            <?php
                            // Liste choix type objet
                            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                            $rech = 'SELECT * FROM `' . TBRTO . '` ORDER BY rto_desc';
                            $rows = $db->get_results($rech, ARRAY_A);
                            close_database();
                            cre_select_tab('coderto', 'coderto', $rows, 'rto_code', 'rto_desc', '', $robj_coderto, '', _('-- Faites votre choix --'));

                            // Icône de saisie si objet immobile
                            echo ' <span id="addimmob" class="falselnk">';
                            echo ' <img src="../img/objimmob.png" title="' . _('Objet Immobile - détail') . '" border="0" align="absmiddle">';
                            echo '</span>';

                            // Icône de saisie si objet mobile
                            echo ' <span id="addmob" class="falselnk">';
                            echo ' <img src="../img/objmob.png" title="' . _('Objet Mobile - détail') . '" border="0" align="absmiddle">';
                            echo '</span>';

                            // Icône de saisie si objet assuré
                            echo ' <span id="addassu" class="falselnk">';
                            echo ' <img src="../img/objassu.png" title="' . _('Objet Assuré - détail') . '" border="0" align="absmiddle">';
                            echo '</span>';

                            // Icône de saisie pour nomenclature
                            echo ' <span id="addnomenc" class="falselnk">';
                            echo ' <img src="../img/objnomenc.png" title="' . _('Nomenclature - éditer') . '" border="0" align="absmiddle">';
                            echo '</span>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_coderpet" align="right"><?php echo _('Etat constaté'); ?></td>
                        <td>
                            <?php
                            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                            $rech = 'SELECT * FROM `' . TBRPET . '` ORDER BY rpet_desc';
                            $rows = $db->get_results($rech, ARRAY_A);
                            close_database();
                            cre_select_tab('coderpet', 'coderpet', $rows, 'rpet_code', 'rpet_desc', '', $robj_coderpet, '', _('-- Faites votre choix --'));
                            ?>
                        </td>
                    </tr>
                </table>

                <div id="detmque">
                    <table width="100%" border="0">
                        <tr>
                            <td width="160" class="rubfrm" id="f_codemque" align="right"><?php echo _('Marque'); ?></td>
                            <td>
                                <?php
                                $rows2 = [];

                                // On récupère d'abord les marques "produits" ou "licences"
                                $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                                $rech = 'SELECT mquet_code FROM `' . TBMQUET . '` WHERE `mquet_rpdt` = 1 OR `mquet_rlic` = 1';
                                $rows = $db->get_results($rech, ARRAY_A);

                                if ($rows) {
                                    $rech2 = 'SELECT * FROM `' . TBMQUE . '` WHERE (';
                                    foreach ($rows as $row) {
                                        extract($row);
                                        $rech2 .= ' ' . TBMQUE . ".mque_codemquet = '" . $db->escape($mquet_code) . "' OR";
                                    }
                                    // Suppression du dernier 'OR'
                                    $rech2 = substr($rech2, 0, -3);
                                    $rech2 .= ')';
                                    $rows2 = $db->get_results($rech2, ARRAY_A);
                                }

                                close_database();
                                cre_select_tab('codemque', 'codemque', $rows2, 'mque_code', 'mque_ste', '', $robj_codemque, '', _('-- Faites votre choix --'));
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <div id="detns">
                    <table width="100%" border="0">
                        <tr>
                            <td width="160" class="rubfrm" id="f_ns"
                                align="right"><?php echo _('Numéro de série'); ?></td>
                            <td>
                                <input name="ns" type="text" id="ns" value="<?php echo $robj_ns ?>" size="50">
                                <?php
                                if (($td == 'add') || ($td == 'edit')) {
                                    echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                                }
                                ?>

                            </td>
                        </tr>
                    </table>
                </div>

            </div>

            <div id="obj_inv">
                <table width="100%" border="0">
                    <tr>
                        <td class="rubfrm" id="f_numinv" align="right"><?php echo _('Numéro inventaire'); ?></td>
                        <td><input name="numinv" type="text" id="numinv" value="<?php echo $robj_numinv ?>" size="20">
                            <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                        </td>
                    </tr>
                    <tr>
                        <td width="160" class="rubfrm" id="f_datefabf"
                            align="right"><?php echo _('Date fabrication'); ?></td>
                        <td>
                            <input name="datefabf" type="text" id="datefabf" value="<?php echo $robj_datefabf; ?>"
                                   size="10" maxlength="10" readonly="1">
                            <img src="../img/raz.png" id="razdatefabf" border="0" align="absmiddle">
                        </td>
                    </tr>
                    <tr>
                        <td width="160" class="rubfrm" id="f_dateachf"
                            align="right"><?php echo _("Date d'achat"); ?></td>
                        <td>
                            <input name="dateachf" type="text" id="dateachf" value="<?php echo $robj_dateachf; ?>"
                                   size="10" maxlength="10" readonly="1">
                            <img src="../img/raz.png" id="razdateachf" border="0" align="absmiddle">
                        </td>
                    </tr>
                    <tr>
                        <td width="160" class="rubfrm" id="f_coderta"
                            align="right"><?php echo _('Type Acquisition'); ?></td>
                        <td>
                            <?php
                            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                            $rech = 'SELECT * FROM `' . TBRTA . '` ORDER BY rta_desc';
                            $rows = $db->get_results($rech, ARRAY_A);
                            close_database();
                            cre_select_tab('coderta', 'coderta', $rows, 'rta_code', 'rta_desc', '', $robj_coderta, '', _('-- Faites votre choix --'));
                            ?>
                        </td>
                    </tr>
                    <?php
                    if ($td <> 'add') {
                        ?>
                        <tr>
                            <td width="160" class="rubfrm" id="f_datesortief"
                                align="right"><?php echo _('Date de sortie'); ?></td>
                            <td>
                                <input name="datesortief" type="text" id="datesortief"
                                       value="<?php echo $robj_datesortief; ?>" size="10" maxlength="10" readonly="1">
                                <img src="../img/raz.png" id="razdatesortief" border="0" align="absmiddle">
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </table>
                <?php
                if ($td <> 'add') {
                    ?>
                    <div id="detsortie">
                        <table width="100%" border="0">
                            <tr>
                                <td width="160" class="rubfrm" id="f_detailsortie"
                                    align="right"><?php echo _('Détail sortie'); ?></td>
                                <td>
                                    <textarea name="detailsortie" rows="5"
                                              id="detailsortie"><?php echo $robj_detailsortie; ?></textarea>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <?php
                }
                ?>
            </div>

            <div id="obj_val">
                <table width="100%" border="0">
                    <tr>
                        <td width="160" class="rubfrm" id="f_pa" align="right"><?php echo _('Coût acquisition'); ?></td>
                        <td>
                            <?php
                            cre_input_num('pa', $robj_pa, TRUE, FALSE, FALSE);
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="rubfrm" id="f_vr" align="right"><?php echo _('Valeur résiduelle'); ?></td>
                        <td>
                            <?php
                            cre_input_num('vr', $robj_vr, TRUE, FALSE, FALSE);
                            ?>
                        </td>
                    </tr>
                </table>
            </div>

            <div id="obj_compl">
                <table width="100%" border="0">
                    <tr>
                        <td width="160" class="rubfrm" id="f_notaa" align="right"><?php echo _('Notes'); ?></td>
                        <td>
                            <textarea name="notes" rows="5" id="notes"><?php echo $robj_notes; ?></textarea>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <p align="center">
            <?php
            switch ($td) {
                case 'add' :
                case 'edit' :
                    echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Enregistrer') . '">';
                    echo '<input name="RAZ" type="reset" class="bton_std" id="RAZ" value="' . _('Réinitialiser') . '">';
                    break;
                case 'del' :
                    echo '<input name="del" type="submit" class="bton_std" id="del" value="' . _('Supprimer') . '">';
                    break;
            }
            ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'robj_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>