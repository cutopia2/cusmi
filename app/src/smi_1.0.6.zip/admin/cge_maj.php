<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_fici.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_geol.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
include_once '../classes/geoplugin/geoplugin.class.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$cge_dep = valget('dep');
// Récupération des informations centre de gestion
if (existe_cdg() == TRUE) {
    $row = lit_enr_cdg();
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);
    }
    $creation = 0;
    $titre = _('MISE A JOUR CENTRE DE GESTION');
} else // Si pas encore créé
{
    $creation = 1;
    $cge_codepays = pays_connect_code($_SERVER['REMOTE_ADDR']);
    $titre = _('CREATION CENTRE DE GESTION');
}
$cge_datemod = $datea;
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche Centre de Gestion'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        var tab1_champ = [
            <?php
            if ($creation == 1)
            {
                echo '"nom:code ; format:alphanum ; req:Y ; txt:'._('Code').'; lmx:10 ; stok:frmok ; stbad:frmbad",';
                echo '"nom:pass ; format:pw ; pwq:6 ; req:Y ; txt:'._('Mot de Passe').' ; lmn:7 ; lmx:10; stok:frmok ; stbad:frmbad",';
            } ?>
            "nom:nom ; format:txt ; req:Y ; txt:<?php echo _('Nom'); ?> ; lmx:50 ; stok:frmok ; stbad:frmbad",
            "nom:rcs ; format:siret ; req:N ; txt:<?php echo _('Siret'); ?> ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:ape ; format:naf ; req:N ; txt:<?php echo _('APE'); ?> ; lmx:10; stok:frmok ; stbad:frmbad",
            "nom:tvai ; format:tva ; req:N ; txt:<?php echo _('TVA intra.'); ?> ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:tcom ; format:txt ; req:N ; txt:<?php echo _('Tribunal de commerce'); ?> ; lmx:70; stok:frmok ; stbad:frmbad",
            "nom:adr1 ; format:txt ; req:Y ; txt:<?php echo _('Adresse'); ?> ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:adr2 ; format:txt ; req:N ; txt:<?php echo _('Adresse (2)'); ?> ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:ville ; format:liste ; req:Y ; txt:<?php echo _('Ville'); ?> ; vmn:1; stok:frmok ; stbad:frmbad",
            "nom:dep ; format:liste ; req:Y ; txt:<?php echo _('Département'); ?> ; vmn:1; stok:frmok ; stbad:frmbad",
            "nom:pays ; format:liste ; req:Y ; txt:<?php echo _('Pays'); ?> ; vmn:1; stok:frmok ; stbad:frmbad",
            "nom:telf ; format:tel ; req:Y ; txt:<?php echo _('Téléphone Fixe'); ?>; stok:frmok ; stbad:frmbad",
            "nom:txttelf ; format:txt ; req:N ; txt:<?php echo _('Commentaire').' '._('Téléphone Fixe'); ?>; lmx:100 ; stok:frmok ; stbad:frmbad",
            "nom:fax ; format:tel ; req:Y ; txt:<?php echo _('Télécopieur'); ?>; stok:frmok ; stbad:frmbad",
            "nom:txtfax ; format:txt ; req:N ; txt:<?php echo _('Commentaire').' '._('Télécopieur'); ?>; lmx:100 ; stok:frmok ; stbad:frmbad",
            "nom:web ; format:url_npref ; req:Y ; txt:<?php echo _('Site Web'); ?>; lmx:200; stok:frmok ; stbad:frmbad",
            "nom:heures ; format:txt ; req:Y ; txt:<?php echo _('Horaires'); ?>; lmx:200; stok:frmok ; stbad:frmbad",
            "nom:email ; format:mail ; req:Y ; txt:<?php echo _('Email').' '._('Général'); ?> ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:emaild ; format:mail ; req:Y ; txt:<?php echo _('Email').' '._('Direction'); ?> ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:emailc ; format:mail ; req:Y ; txt:<?php echo _('Email').' '._('Comptabilité / Finances'); ?> ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:emailt ; format:mail ; req:Y ; txt:<?php echo _('Email').' '._('Technique'); ?> ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:emailf ; format:mail ; req:Y ; txt:<?php echo _('Email').' '._('Franchise / Partenariat'); ?> ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:emaili ; format:mail ; req:Y ; txt:<?php echo _('Email').' '._('Investisseurs'); ?> ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:emailrh ; format:mail ; req:Y ; txt:<?php echo _('Email').' '._('Ressources Humaines'); ?> ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:nota ; format:txt ; req:N ; txt:<?php echo _('Notes'); ?>; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <script type="text/javascript">
        <!--
        $(function () {
            $('.nyroModal').nyroModal();
        });
        //-->
    </script>

    <script type="text/javascript">
        <!--
        $(function () {
            $("#code").Setcase({caseValue: 'upper', changeonFocusout: true});
            $("#nom").Setcase({caseValue: 'upper', changeonFocusout: true});
            $("#rcs").Setcase({caseValue: 'upper', changeonFocusout: true});
            $("#ape").Setcase({caseValue: 'upper', changeonFocusout: true});
            $("#tvai").Setcase({caseValue: 'upper', changeonFocusout: true});
            $("#tcom").Setcase({caseValue: 'upper', changeonFocusout: true});
            $("#adr1").Setcase({caseValue: 'upper', changeonFocusout: true});
            $("#adr2").Setcase({caseValue: 'upper', changeonFocusout: true});
            $("#rnom").Setcase({caseValue: 'upper', changeonFocusout: true});
            $("#email").Setcase({caseValue: 'lower', changeonFocusout: true});
            $("#emaild").Setcase({caseValue: 'lower', changeonFocusout: true});
            $("#emailc").Setcase({caseValue: 'lower', changeonFocusout: true});
            $("#emailt").Setcase({caseValue: 'lower', changeonFocusout: true});
            $("#emailf").Setcase({caseValue: 'lower', changeonFocusout: true});
            $("#emaili").Setcase({caseValue: 'lower', changeonFocusout: true});
            $("#emailrh").Setcase({caseValue: 'lower', changeonFocusout: true});
            $("#rprenom").Setcase({caseValue: 'pascal', changeonFocusout: true});
        });

        function init_all() {
            init_Body();
            img_checkpw('pass', 'nivpass');
            init_checkpw('pass', 'nivpass', true);
            init_ajax_ville();
            init_ajax_dep();
            init_valid_form('enr', 'cge_maj', '<?php echo valsession('date_fmtshort'); ?>', tab1_champ, 'pays', '');
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>

<body>

<?php
include_once '../inc/entete.inc.php';

cre_ent_form($titre);
?>
<form name="cge_maj" id="cge_maj" method="post" action="cge_enr.php">
    <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
    <input name="creation" type="hidden" id="creation" value="<?php echo $creation ?>">
    <?php
    if ($creation == 0) {
        ?>
        <input name="code" type="hidden" id="code" value="<?php echo $cge_code ?>">
        <input name="pass" type="hidden" id="pass" value="<?php echo $cge_pass ?>">
        <?php
    }
    ?>
    <input name="nbutton" type="hidden" id="nbutton" value="">
    <table width="100%" border="0">
        <?php if ($creation == 0) { ?>
            <tr>
                <td height="21" class="rubfrm" id="f_logo" width="160" align="right"><?php echo _('Logo'); ?></td>
                <td>
                    <?php
                    $url_img_logo = $chemin_logos . '/logcge.png';
                    if (exist_logo('cge')) {
                        echo ' <a href="' . $url_img_logo . '" class="nyroModal" title="' . _('Logo Centre de gestion') . '">';
                        echo ' <img src="../img/vlogo.png" border="0" align="absmiddle"> ' . _('Voir le logo');
                        echo '</a>';
                    } else {
                        echo '<div class="annot_petit_it">';
                        echo _('Pas de logo centre de gestion');
                        echo '<br />(<a href="logo_maj.php?td=cge">' . _('Configurer') . '</a>)';
                        echo '</div>';
                    }
                    ?>
                </td>
            </tr>
        <?php } else { ?>
            <tr>
                <td class="rubfrm" id="f_code" align="right"><?php echo _('Code Connexion'); ?></td>
                <td>
                    <input name="code" type="text" id="code" value="<?php echo $cge_code ?>" size="15">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_pass" align="right"><?php echo _('Mot de Passe'); ?></td>
                <td>
                    <input name="pass" type="text" id="pass" value="<?php echo $cge_pass ?>" size="10" maxlength="20">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    <span id="nivpass"></span>
                    <br/>
                    <span class="annot_petit_it"><?php echo _('7 caractères minimum / Puissance minimum : 6'); ?></span>
                </td>
            </tr>
        <?php } ?>
        <tr>
            <td class="rubfrm" id="f_nom" align="right"><?php echo _('Nom'); ?></td>
            <td>
                <input name="nom" type="text" id="nom" value="<?php echo $cge_nom ?>" size="50">
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_rcs" align="right"><?php echo _('Siret'); ?></td>
            <td>
                <input name="rcs" type="text" id="rcs" value="<?php echo $cge_rcs ?>" size="50">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_ape" align="right"><?php echo _('APE'); ?></td>
            <td>
                <input name="ape" type="text" id="ape" value="<?php echo $cge_ape ?>" size="10">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_tvai" align="right"><?php echo _('TVA intra.'); ?></td>
            <td>
                <input name="tvai" type="text" id="tvai" value="<?php echo $cge_tvai ?>" size="50">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_tcom" align="right"><?php echo _('Tribunal com.'); ?></td>
            <td>
                <input name="tcom" type="text" id="tcom" value="<?php echo $cge_tcom ?>" size="70">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_adr1" align="right"><?php echo _('Adresse'); ?></td>
            <td>
                <input name="adr1" type="text" id="adr1" value="<?php echo $cge_adr1 ?>" size="50">
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_adr2" align="right"><?php echo _('Adresse (2)'); ?></td>
            <td>
                <input name="adr2" type="text" id="adr2" value="<?php echo $cge_adr2 ?>" size="50">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_pays" align="right"><?php echo _('Pays'); ?></td>
            <td>
                <?php
                // Création de la liste des pays
                $rows = give_rows_pays();
                cre_select_tab('pays', 'pays', $rows, 'pays_code', 'pays_nom', '', $cge_codepays, '', _('-- Faites votre choix --'));
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_dep" align="right"><?php echo _('Département'); ?></td>
            <td>
                <?php
                // Création de la liste des départements
                $rows = give_rows_dep($cge_codepays);
                cre_select_tab('dep', 'dep', $rows, 'dep_code', 'dep_code', 'dep_nom', $cge_dep, '', _('-- Faites votre choix --'), 1, FALSE, '-1', _('-- Inconnu --'));
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_ville" align="right"><?php echo _('Ville'); ?></td>
            <td>
                <?php
                // Création de la liste des villes
                $rows = give_rows_villes($cge_dep, $cge_codepays);
                cre_select_tab('ville', 'ville', $rows, 'villes_id', 'villes_nom', 'villes_cp', $cge_ville, '', _('-- Faites votre choix --'), 1, FALSE, '-1', _('-- Inconnu --'));
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_telf" align="right"><?php echo _('Téléphone Fixe'); ?><br/>
                (<?php echo _('Commentaire'); ?>)
            </td>
            <td>
                <input name="telf" type="text" id="telf" value="<?php echo $cge_telf ?>" size="20">
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"><br/>
                <input name="txttelf" type="text" id="txttelf" value="<?php echo $cge_txttelf ?>" size="50">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_fax" align="right"><?php echo _('Télécopieur'); ?><br/>
                (<?php echo _('Commentaire'); ?>)
            </td>
            <td>
                <input name="fax" type="text" id="fax" value="<?php echo $cge_fax ?>" size="20">
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"><br/>
                <input name="txtfax" type="text" id="txtfax" value="<?php echo $cge_txtfax ?>" size="50">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_web" align="right"><?php echo _('Site Web'); ?><span
                    class="annot_petit_it">(<?php echo _('Sans préfixe'); ?>)</span></td>
            <td>
                <input name="web" type="text" id="web" value="<?php echo $cge_web ?>" size="80" maxlength="200">
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_heures" align="right"><?php echo _('Horaires'); ?></td>
            <td>
                <input name="heures" type="text" id="heures" value="<?php echo $cge_heures ?>" size="80">
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
            </td>
        </tr>
        <tr>
            <td colspan="2" class="rubfrm" align="center"><?php echo _('Emails'); ?></td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_email" align="right"><?php echo _('Général'); ?></td>
            <td>
                <input name="email" type="text" id="email" value="<?php echo $cge_email ?>" size="50" maxlength="50">
                <?php if ($creation == 0) { ?>
                    <a href="mailto:<?php echo $cge_email ?>"><img src="../img/mail.png"
                                                                   title="<?php echo _('Envoyer e-mail'); ?>" border="0"
                                                                   align="absmiddle"></a>
                <?php } ?>
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"> <span
                    class="annot_std_it">(<?php echo _('Pour contacts clients'); ?>)</span>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_emaild" align="right"><?php echo _('Direction'); ?></td>
            <td>
                <input name="emaild" type="text" id="emaild" value="<?php echo $cge_emaild ?>" size="50" maxlength="50">
                <?php if ($creation == 0) { ?>
                    <a href="mailto:<?php echo $cge_emaild ?>"><img src="../img/mail.png"
                                                                    title="<?php echo _('Envoyer e-mail'); ?>"
                                                                    border="0"
                                                                    align="absmiddle"></a>
                <?php } ?>
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_emailc" align="right"><?php echo _('Comptabilité / Finances'); ?></td>
            <td>
                <input name="emailc" type="text" id="emailc" value="<?php echo $cge_emailc ?>" size="50" maxlength="50">
                <?php if ($creation == 0) { ?>
                    <a href="mailto:<?php echo $cge_emailc ?>"><img src="../img/mail.png"
                                                                    title="<?php echo _('Envoyer e-mail'); ?>"
                                                                    border="0"
                                                                    align="absmiddle"></a>
                <?php } ?>
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_emailt" align="right"><?php echo _('Technique'); ?></td>
            <td>
                <input name="emailt" type="text" id="emailt" value="<?php echo $cge_emailt ?>" size="50" maxlength="50">
                <?php if ($creation == 0) { ?>
                    <a href="mailto:<?php echo $cge_emailt ?>"><img src="../img/mail.png"
                                                                    title="<?php echo _('Envoyer e-mail'); ?>"
                                                                    border="0"
                                                                    align="absmiddle"></a>
                <?php } ?>
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_emailf" align="right"><?php echo _('Franchise / Partenariat'); ?></td>
            <td>
                <input name="emailf" type="text" id="emailf" value="<?php echo $cge_emailf ?>" size="50" maxlength="50">
                <?php if ($creation == 0) { ?>
                    <a href="mailto:<?php echo $cge_emailt ?>"><img src="../img/mail.png"
                                                                    title="<?php echo _('Envoyer e-mail'); ?>"
                                                                    border="0"
                                                                    align="absmiddle"></a>
                <?php } ?>
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_emaili" align="right"><?php echo _('Investisseurs'); ?></td>
            <td>
                <input name="emaili" type="text" id="emaili" value="<?php echo $cge_emaili ?>" size="50" maxlength="50">
                <?php if ($creation == 0) { ?>
                    <a href="mailto:<?php echo $cge_emailt ?>"><img src="../img/mail.png"
                                                                    title="<?php echo _('Envoyer e-mail'); ?>"
                                                                    border="0"
                                                                    align="absmiddle"></a>
                <?php } ?>
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_emailrh" align="right"><?php echo _('Ressources Humaines'); ?></td>
            <td>
                <input name="emailrh" type="text" id="emailrh" value="<?php echo $cge_emailrh ?>" size="50"
                       maxlength="50">
                <?php if ($creation == 0) { ?>
                    <a href="mailto:<?php echo $cge_emailrh ?>"><img src="../img/mail.png"
                                                                     title="<?php echo _('Envoyer e-mail'); ?>"
                                                                     border="0"
                                                                     align="absmiddle"></a>
                <?php } ?>
                <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
            </td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_nota" align="right"><?php echo _('Notes'); ?></td>
            <td><textarea name="nota" id="nota" rows="5"><?php echo $cge_nota; ?></textarea></td>
        </tr>
    </table>
    <p align="center">
        <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="<?php echo _('Réinitialiser'); ?>">
        <input name="enr" type="button" class="bton_std" id="enr" value="<?php echo _('Enregistrer'); ?>">
    </p>
</form>
<?php
include_once 'pied.php';
?>
</body>
</html>