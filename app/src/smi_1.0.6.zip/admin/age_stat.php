<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_age.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$txt_stat_age = [
    1 => _('Nombre de créations de clients sur une période donnée'),
    2 => _("Répartition des catégories d'agences actives"),
    3 => _("Nombre de créations d'interventions sur une période donnée"),
    4 => _("Nombre de traitements d'interventions sur une période donnée")];

$pbm_stat = FALSE;
$aff_stat = FALSE;
$ts = 0;
$date1 = '';
$date2 = '';

// On a validé
if (valpost('nbutton') == 'calc') {
    $aff_stat = TRUE;

    $ts = (int)$_POST['ts'];

    $age_select_tab = [];
    foreach ($_POST['age'] as $iValue) {
        $age_select_tab[] = $iValue;
    }

    $cat_select_tab = [];
    foreach ($_POST['cat'] as $iValue) {
        $cat_select_tab[] = $iValue;
    }

    $date1 = datetomysql($_POST['date1f']);
    $date2 = datetomysql($_POST['date2f']);

    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
    switch ($ts) {
        /* Nombre de créations de clients sur une période donnée */
        case 1 :
            // Analyse des données et traitements statistiques

            /* Initialisation des totaux généraux */

            $nb_cli_crees_total = 0;
            $nb_cli_prospects_crees_total = 0;
            $nb_cli_ddeint_crees_total = 0;
            $nb_cli_inter_crees_total = 0;

            /* Calcul des totaux généraux */

            $rech = 'SELECT age_code FROM `' . TBAGE . '`';
            $rech .= ' ORDER BY age_code';

            $rows = $db->get_results($rech, ARRAY_A);

            if ($rows) {
                foreach ($rows as $row) {
                    $row = encode_str($row);
                    extract($row);

                    // Détermination du nombre de clients créés par les agences sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $age_code . "'";
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";
                    $nb_cli_crees_total += $db->get_var($rech2);

                    // Détermination du nombre de clients encore prospects et créés par les agences sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $age_code . "'";
                    $rech2 .= ' AND cli_type=0';
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";
                    $nb_cli_prospects_crees_total += $db->get_var($rech2);

                    // Détermination du nombre de client ayant demandé une intervention (non effectuée) et créés par les agences sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $age_code . "'";
                    $rech2 .= ' AND cli_type=1';
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";
                    $nb_cli_ddeint_crees_total += $db->get_var($rech2);

                    // Détermination du nombre total de clients ayant demandé une intervention (effectuée) et créés par les agences sur la période
                    $nb_cli_inter_crees_total = $nb_cli_crees_total - $nb_cli_prospects_crees_total - $nb_cli_ddeint_crees_total;
                }
            }

            /* Traitement par agence */
            $rech = 'SELECT * FROM `' . TBAGE . '`';

            // Traitement de multiples
            if (!in_array('*', $age_select_tab)) {
                $rech .= ' WHERE (';
                foreach ($age_select_tab as $iValue) {
                    $rech .= " age_code='" . $iValue . "' OR";
                }
                // Suppression du dernier 'OR'
                $rech = substr($rech, 0, -3);
                $rech .= ')';
            }

            if (!in_array('*', $cat_select_tab)) {
                if (stripos($rech,'WHERE ') == FALSE) {
                    $rech .= ' WHERE (';
                } else {
                    $rech .= ' AND (';
                }
                foreach ($cat_select_tab as $iValue) {
                    $rech .= " age_cat='" . $iValue . "' OR";
                }
                // Suppression du dernier 'OR'
                $rech = substr($rech, 0, -3);
                $rech .= ')';
            }

            $rech .= ' ORDER BY age_nom';

            $rows = $db->get_results($rech, ARRAY_A);

            if ($rows) {
                $i = 0;

                foreach ($rows as $row) {
                    $row = encode_str($row);
                    extract($row);

                    // Récupération du code agence
                    $code_agence[$i] = $age_code;

                    // Détermination du nombre de clients créés par l'agence sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $age_code . "'";
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";

                    $nb_cli_crees_age[$i] = $db->get_var($rech2);

                    // Détermination du nombre de clients encore prospects et créés par l'agence sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $age_code . "'";
                    $rech2 .= ' AND cli_type=0';
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";

                    $nb_cli_prospects_crees_age[$i] = $db->get_var($rech2);

                    // Détermination du nombre de client ayant demandé une intervention (non effectuée) et créés par les agences sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $age_code . "'";
                    $rech2 .= ' AND cli_type=1';
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";

                    $nb_cli_ddeint_crees_age[$i] = $db->get_var($rech2);

                    // Détermination du nombre total de clients ayant demandé une intervention (effectuée) et créés par les agences sur la période
                    $nb_cli_inter_crees_age[$i] = $nb_cli_crees_age[$i] - $nb_cli_prospects_crees_age[$i] - $nb_cli_ddeint_crees_age[$i];

                    $i++;
                }
            }
            break;

        /* Répartition des catégories d'agences actives */
        case 2 :
            // Analyse des données et traitements statistiques
            $nb_total_agences = nb_age(FALSE);

            /* Traitement par agence */

            $rech = 'SELECT * FROM `' . TBACAT . '`';
            $rech .= ' ORDER BY acat_desc';

            $rows = $db->get_results($rech, ARRAY_A);

            if ($rows) {
                $i = 0;
                foreach ($rows as $row) {
                    $row = encode_str($row);
                    extract($row);

                    // Récupération du code agence
                    $code_acat[$i] = $acat_code;

                    // Détermination du nombre d'agences actives pour la catégorie examinée
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBAGE . '`';
                    $rech2 .= " WHERE age_cat='" . $acat_code . "'";
                    $rech2 .= " AND age_ouvert='1'";

                    $nb_acat_age[$i] = $db->get_var($rech2);

                    $nb_age_select += $nb_acat_age[$i];

                    $i++;
                }
            }
            break;

        /* Nombre de créations d'interventions sur une période donnée */
        case 3 :
            // Analyse des données et traitements statistiques

            /* Initialisation des totaux généraux */

            $nb_int_crees_total = 0;
            $nb_int_ouv_crees_total = 0;
            $nb_int_prev_crees_total = 0;
            $nb_int_clos_crees_total = 0;

            /* Calcul des totaux généraux */

            $rech = 'SELECT age_code FROM `' . TBAGE . '`';
            $rech .= ' ORDER BY age_code';

            $rows = $db->get_results($rech, ARRAY_A);

            if ($rows) {
                $i = 0;
                foreach ($rows as $row) {
                    $row = encode_str($row);
                    extract($row);

                    // Détermination du nombre d'interventions créées par les agences sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codecrea='" . $age_code . "'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_crees_total += $db->get_var($rech2);

                    // Détermination du nombre d'interventions encore ouvertes et créées par les agences sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codecrea='" . $age_code . "'";
                    $rech2 .= " AND int_dateprev='0000-00-00'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_ouv_crees_total += $db->get_var($rech2);

                    // Détermination du nombre d'interventions, où le client a été prévenu, et créées par les agences sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codecrea='" . $age_code . "'";
                    $rech2 .= " AND int_dateprev<>'0000-00-00'";
                    $rech2 .= " AND int_datefin='0000-00-00'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_prev_crees_total += $db->get_var($rech2);

                    // Détermination du nombre total d'interventions closes et créés par les agences sur la période
                    $nb_int_clos_crees_total = $nb_int_crees_total - $nb_int_ouv_crees_total - $nb_int_prev_crees_total;
                }
            }

            /* Traitement par agence */
            $rech = 'SELECT * FROM `' . TBAGE . '`';

            // Traitement de multiples
            if (!in_array('*', $age_select_tab)) {
                $rech .= ' WHERE (';
                foreach ($age_select_tab as $iValue) {
                    $rech .= " age_code='" . $iValue . "' OR";
                }
                // Suppression du dernier 'OR'
                $rech = substr($rech, 0, -3);
                $rech .= ')';
            }

            if (!in_array('*', $cat_select_tab)) {
                if (stripos($rech,'WHERE ') == FALSE) {
                    $rech .= ' WHERE (';
                } else {
                    $rech .= ' AND (';
                }
                foreach ($cat_select_tab as $iValue) {
                    $rech .= " age_cat='" . $iValue . "' OR";
                }
                // Suppression du dernier 'OR'
                $rech = substr($rech, 0, -3);
                $rech .= ')';
            }
            $rech .= ' ORDER BY age_nom';

            $rows = $db->get_results($rech, ARRAY_A);

            if ($rows) {
                $i = 0;
                foreach ($rows as $row) {
                    $row = encode_str($row);
                    extract($row);

                    // Récupération du code agence
                    $code_agence[$i] = $age_code;

                    // Détermination du nombre d'interventions créées par l'agence sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codecrea='" . $age_code . "'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_crees_age[$i] = $db->get_var($rech2);

                    // Détermination du nombre d'interventions encore ouvertes et créées par l'agence sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codecrea='" . $age_code . "'";
                    $rech2 .= " AND int_dateprev='0000-00-00'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_ouv_crees_age[$i] = $db->get_var($rech2);

                    // Détermination du nombre d'interventions, o�le client a été prévenu, et créées par les agences sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codecrea='" . $age_code . "'";
                    $rech2 .= " AND int_dateprev<>'0000-00-00'";
                    $rech2 .= " AND int_datefin='0000-00-00'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_prev_crees_age[$i] = $db->get_var($rech2);

                    // Détermination du nombre total d'interventions closes et créées par les agences sur la période
                    $nb_int_clos_crees_age[$i] = $nb_int_crees_age[$i] - $nb_int_ouv_crees_age[$i] - $nb_int_prev_crees_age[$i];

                    $i++;
                }
            }
            break;

        /* Nombre de traitements d'interventions sur une période donnée */
        case 4 :
            // Analyse des données et traitements statistiques

            /* Initialisation des totaux généraux */

            $nb_int_trait_total = 0;
            $nb_int_ouv_trait_total = 0;
            $nb_int_prev_trait_total = 0;
            $nb_int_clos_trait_total = 0;

            /* Calcul des totaux généraux */

            $rech = 'SELECT age_code FROM `' . TBAGE . '`';
            $rech .= ' ORDER BY age_code';

            $rows = $db->get_results($rech, ARRAY_A);

            if ($rows) {
                foreach ($rows as $row) {
                    $row = encode_str($row);
                    extract($row);

                    // Détermination du nombre d'interventions créées par les agences sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codeage='" . $age_code . "'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_trait_total += $db->get_var($rech2);

                    // Détermination du nombre d'interventions encore ouvertes et créées par les agences sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codeage='" . $age_code . "'";
                    $rech2 .= " AND int_dateprev='0000-00-00'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_ouv_trait_total += $db->get_var($rech2);

                    // Détermination du nombre d'interventions, où le client a été prévenu, et créées par les agences sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codeage='" . $age_code . "'";
                    $rech2 .= " AND int_dateprev<>'0000-00-00'";
                    $rech2 .= " AND int_datefin='0000-00-00'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_prev_trait_total += $db->get_var($rech2);

                    // Détermination du nombre total d'interventions closes et créés par les agences sur la période
                    $nb_int_clos_trait_total = $nb_int_trait_total - $nb_int_ouv_trait_total - $nb_int_prev_trait_total;
                }
            }

            /* Traitement par agence */
            $rech = 'SELECT * FROM `' . TBAGE . '`';

            // Traitement de multiples
            if (!in_array('*', $age_select_tab)) {
                $rech .= ' WHERE (';
                foreach ($age_select_tab as $iValue) {
                    $rech .= " age_code='" . $iValue . "' OR";
                }
                // Suppression du dernier 'OR'
                $rech = substr($rech, 0, -3);
                $rech .= ')';
            }

            if (!in_array('*', $cat_select_tab)) {
                if (stripos($rech,'WHERE ') == FALSE) {
                    $rech .= ' WHERE (';
                } else {
                    $rech .= ' AND (';
                }
                foreach ($cat_select_tab as $iValue) {
                    $rech .= " age_cat='" . $iValue . "' OR";
                }
                // Suppression du dernier 'OR'
                $rech = substr($rech, 0, -3);
                $rech .= ')';
            }
            $rech .= ' ORDER BY age_nom';

            $rows = $db->get_results($rech, ARRAY_A);

            if ($rows) {
                $i = 0;

                foreach ($rows as $row) {
                    extract($row);

                    // Récupération du code agence
                    $code_agence[$i] = $age_code;

                    // Détermination du nombre d'interventions créées par l'agence sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codeage='" . $age_code . "'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_trait_age[$i] = $db->get_var($rech2);

                    // Détermination du nombre d'interventions encore ouvertes et créées par l'agence sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codeage='" . $age_code . "'";
                    $rech2 .= " AND int_dateprev='0000-00-00'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_ouv_trait_age[$i] = $db->get_var($rech2);

                    // Détermination du nombre d'interventions, o�le client a été prévenu, et créées par les agences sur la période
                    $rech2 = 'SELECT * FROM `' . TBINT . '`';
                    $rech2 .= " WHERE int_codeage='" . $age_code . "'";
                    $rech2 .= " AND int_dateprev<>'0000-00-00'";
                    $rech2 .= " AND int_datefin='0000-00-00'";
                    $rech2 .= " AND int_datecrea>='" . $date1 . "' AND int_datecrea<='" . $date2 . "'";

                    $nb_int_prev_trait_age[$i] = $db->get_var($rech2);

                    // Détermination du nombre total d'interventions closes et créées par les agences sur la période
                    $nb_int_clos_trait_age[$i] = $nb_int_trait_age[$i] - $nb_int_ouv_trait_age[$i] - $nb_int_clos_trait_age[$i];

                    $i++;
                }
            }

            break;
        default :
            $pbm_stat = TRUE;
            break;
    }
    close_database();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Statistiques Agences'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        var tab_champ = [];
        //-->
    </script>

    <script type="text/javascript">
        <!--
        <?php
        if ($aff_stat == FALSE)
        {
        ?>
        function init_datepicker() {
            <?php include_once '../jscript/datepicker_prm.js.php'; ?>
            $("#date1f").datepicker({
                onSelect: function (datesel) {
                    $("#date1f").blur();
                    chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, '', '', 'date2f', false);
                }
            });
            $("#date2f").datepicker({
                onSelect: function (datesel) {
                    $("#date2f").blur();
                    chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, 'date1f', '', 'today', false);
                }
            });
        }
        <?php } ?>

        function init_all() {
            init_Body();
            <?php
            if ($aff_stat == TRUE)
            {
                echo "init_autohref('newstat', 'click', '', true);";
                echo "readonly_all_id('prm_stat');";
            }
            else
            {
                echo 'init_datepicker();';
                echo "init_stats_age('calc','prm_stat','".valsession('date_fmtshort')."',tab_champ,'','');";
                echo "init_autoraz('razdate1f','date1f','click');";
                echo "init_autoraz('razdate2f','date2f','click');";
            }
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>
</head>
<body>

<?php
include_once '../inc/entete.inc.php';
cre_ent_form(_('STASTISTIQUES AGENCES'), '', '', '', FALSE);
if ($pbm_stat == FALSE) {
    if (nb_age() > 0) {
        if ($aff_stat == TRUE) {
            cre_falselnk('', 'newstat', 'div', '', _('Autre statistique'), 'age_stat.php', '../img/stat.png', _('Autre statistique'));
        }
        ?>
        <div align="center" style="margin-top: 5px; margin-bottom: 5px;">
            <form name="prm_stat" id="prm_stat" class="bord_pointilles" method="post" action="age_stat.php">
                <input name="today" type="hidden" id="today" value="<?php echo $datef; ?>">
                <input name="nbutton" type="hidden" id="nbutton" value="">
                <?php
                cre_select('ts', 'ts', $txt_stat_age, $ts, '', _('-- Faites votre choix --'));
                if ($aff_stat == FALSE) {
                    ?>
                    <table width="80%" border="0">
                        <tr>
                            <td width="50%" align="center" colspan="2">
                                <?php echo _('Choisissez une agence (sélections multiples possibles)'); ?>.
                                <div
                                    class="annot_petit_it"><?php echo _("(Si 'Toutes', les agences fermées seront aussi analysées)"); ?></div>
                            </td>
                            <td align="center" colspan="2">
                                <?php echo _("Choisissez une catégorie d'agence"); ?>.
                                <br/>
                            </td>
                        </tr>
                        <tr>
                            <td width="50%" align="center" colspan="2">
                                <?php
                                // Création de la liste des agences actives
                                $tab_age = give_tab_age_cli('');
                                cre_select('age[]', 'age', $tab_age, '*', '*', _('---------- Toutes ----------'), 5, TRUE);
                                ?>
                            </td>
                            <td align="center" colspan="2">
                                <?php
                                // Création de la liste des catégories
                                $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                                $sql = 'SELECT * FROM `' . TBACAT . '` ORDER BY acat_desc';
                                $rows = $db->get_results($sql, ARRAY_A);
                                close_database();

                                cre_select_tab('cat[]', 'cat', $rows, 'acat_code', 'acat_desc', '', '*', '*', _('---------- Toutes ----------'), 5, TRUE);
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td width="50%" align="center" colspan="4">
                                &nbsp;
                            </td>
                        </tr>
                    </table>
                    <?php
                } else {
                    echo '<br /><br />';
                }
                ?>
                <div id="dates">
                    <span class="rubfrm" id="f_date1"
                          style="margin-right: 5px;"><?php echo ' ' . _('Du') . '... '; ?></span>
                    <input name="date1f" type="text" id="date1f" size="10" value="<?php echo datetolocal($date1); ?>"
                           maxlength="10" readonly>
                    <?php
                    if ($aff_stat == FALSE) {
                        echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                        echo ' <img src="../img/raz.png" id ="razdate1f" border="0" align="absmiddle">';
                    }
                    ?>
                    <span class="rubfrm" id="f_date2f"
                          style="margin-right: 5px;"><?php echo ' ' . _('Au') . '... '; ?></span>
                    <input name="date2f" type="text" id="date2f" size="10" value="<?php echo datetolocal($date1); ?>"
                           maxlength="10" readonly>
                    <?php
                    if ($aff_stat == FALSE) {
                        echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                        echo ' <img src="../img/raz.png" id ="razdate2f" border="0" align="absmiddle">';
                    }
                    ?>
                </div>
                <?php
                if ($aff_stat == FALSE) {
                    echo '<p align="center">';
                    echo '<input name="calc" type="button" class="bton_std" id="calc" value="' . _('Calculer') . '">';
                    echo ' <input name="init" type="reset" class="bton_std" id="init" value="' . _('Réinitialiser') . '">';
                    echo '</p>';
                }
                ?>
            </form>
        </div>
        <?php
        if ($aff_stat == TRUE) {
            switch ($ts) {
                /* Nombre de créations de clients sur une période donnée */
                case 1 :
                    // Définition et entête de la table
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    echo '<th>';
                    echo _('Agence');
                    echo '</th>';
                    echo '<th>';
                    echo _('Total créés');
                    echo '</th>';
                    echo '<th>';
                    echo _('Encore prospects');
                    echo '</th>';
                    echo '<th>';
                    echo _('Attente intervention');
                    echo '</th>';
                    echo '<th>';
                    echo _('Intervention');
                    echo '</th>';

                    $i = 0;

                    /* données pour toutes les agences */

                    // création de l'entête de ligne (TR)
                    echo '<tr>';

                    echo '<td>';
                    echo '<span class="annot_std_it">';
                    echo _('Toutes les agences');
                    echo '</span>';
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_cli_crees_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_cli_crees_total;
                        echo '</span>';
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_cli_prospects_crees_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_cli_prospects_crees_total;
                        echo '</span>';
                        if ($nb_cli_crees_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo ' (' . round(($nb_cli_prospects_crees_total / $nb_cli_crees_total) * 100, 2) . '%)';
                            echo '</span>';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_cli_ddeint_crees_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_cli_ddeint_crees_total;
                        echo '</span>';
                        if ($nb_cli_crees_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo ' (' . round(($nb_cli_ddeint_crees_total / $nb_cli_crees_total) * 100, 2) . '%)';
                            echo '</span>';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_cli_inter_crees_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_cli_inter_crees_total;
                        echo '</span>';
                        if ($nb_cli_crees_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo ' (' . round(($nb_cli_inter_crees_total / $nb_cli_crees_total) * 100, 2) . '%)';
                            echo '</span>';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';

                    echo '</tr>';

                    $i++;

                    /* Saut de ligne pour lisibilité */

                    // création de l'entête de ligne (TR)
                    echo '<tr>';

                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';

                    echo '</tr>';

                    $i++;

                    if ($nb_age_select > 0) {
                        for ($j = 0; $j < $nb_age_select; $j++) {
                            // création de l'entête de ligne (TR)
                            echo '<tr>';

                            echo '<td>';
                            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                            $sql = 'SELECT * FROM `' . TBAGE . "` WHERE `age_code` = '" . $code_agence[$j] . "'";
                            $row = $db->get_row($sql, ARRAY_A);
                            if ($row) {
                                extract($row);
                                $txt_age = $age_nom;
                            }
                            close_database();
                            echo '<span class="annot_std_gras">';
                            echo $txt_age . ' (' . $code_agence[$j] . ')';
                            echo '</span>';
                            if ($age_ouvert == 0) {
                                echo '<span class="annot_petit_it">';
                                echo ' ' . _('Fermée');
                                echo '</span>';
                            }
                            echo '<br />';
                            if ($nb_cli_crees_age[$j] <> 0) {
                                echo '<span class="annot_petit_it">';
                                echo '<div align="right">';
                                echo _('Par rapport agence') . ' : ';
                                echo '<br />' . _('Par rapport total') . ' : ';
                                echo '</div>';
                                echo '</span>';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_cli_crees_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_cli_crees_age[$j];
                                echo '</span>';
                                if ($nb_cli_crees_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '<br />-<br />(' . round(($nb_cli_crees_age[$j] / $nb_cli_crees_total) * 100, 2) . '%)';
                                    echo '</span>';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_cli_prospects_crees_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_cli_prospects_crees_age[$j];
                                echo '</span>';
                                echo '<br />';
                                if ($nb_cli_crees_age[$j] <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_cli_prospects_crees_age[$j] / $nb_cli_crees_age[$j]) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                                echo '<br />';
                                if ($nb_cli_prospects_crees_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_cli_prospects_crees_age[$j] / $nb_cli_prospects_crees_total) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_cli_ddeint_crees_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_cli_ddeint_crees_age[$j];
                                echo '</span>';
                                echo '<br />';
                                if ($nb_cli_crees_age[$j] <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo ' (' . round(($nb_cli_ddeint_crees_age[$j] / $nb_cli_crees_age[$j]) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                                echo '<br />';
                                if ($nb_cli_ddeint_crees_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_cli_ddeint_crees_age[$j] / $nb_cli_ddeint_crees_total) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_cli_inter_crees_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_cli_inter_crees_age[$j];
                                echo '</span>';
                                echo '<br />';
                                if ($nb_cli_crees_age[$j] <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo ' (' . round(($nb_cli_inter_crees_age[$j] / $nb_cli_crees_age[$j]) * 100, 2) . '%)';
                                    echo '</span>';
                                }
                                echo '<br />';
                                if ($nb_cli_inter_crees_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_cli_inter_crees_age[$j] / $nb_cli_inter_crees_total) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';

                            echo '</tr>';

                            $i++;
                        }
                    } else {
                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        echo '<td>';
                        echo '<span class="annot_petit_it">';
                        echo _('Aucun résultat à cette demande') . '.';
                        echo '</span>';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';

                        echo '</tr>';
                    }

                    echo '</table>';
                    // *** Fin affichage de la table
                    break;

                /* Répartition des catégories d'agences actives */
                case 2 :
                    // Définition et entête de la table
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    echo '<th>';
                    echo _('Catégories');
                    echo '</th>';
                    echo '<th>';
                    echo _('Quantité');
                    echo '</th>';
                    echo '<th>';
                    echo _('Pourcentage');
                    echo '</th>';

                    if ($nb_acat_select > 0) {
                        for ($j = 0; $j < $nb_acat_select; $j++) {
                            // création de l'entête de ligne (TR)
                            echo '<tr>';

                            echo '<td>';
                            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                            $sql = 'SELECT * FROM `' . TBACAT . "` WHERE `acat_code` = '" . $code_acat[$j] . "'";
                            $row = $db->get_row($sql, ARRAY_A);
                            if ($row) {
                                $row = encode_str($row);
                                extract($row);
                            }
                            close_database();
                            echo '<span class="annot_std_gras">';
                            echo $acat_desc;
                            echo '</span>';
                            echo '<br />';
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_acat_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_acat_age[$j];
                                echo '</span>';
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_acat_age[$j] <> 0) {
                                if ($nb_total_agences <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo round(($nb_acat_age[$j] / $nb_total_agences) * 100, 2) . '%';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';

                            echo '</tr>';
                        }

                        echo '<tr>';
                        echo '<td align="right">';
                        echo '<span class="annot_std_it">';
                        echo _('TOTAL') . ' : ';
                        echo '</span>';
                        echo '</td>';
                        echo '<td align="center">';
                        echo '<span class="annot_std_it">';
                        echo $nb_age_select;
                        echo '</span>';
                        echo '</td>';
                        echo '<td align="center">';
                        echo '<span class="annot_std_it">';
                        echo '100%';
                        echo '</span>';
                        echo '</td>';
                        echo '</tr>';

                    }

                    echo '</table>';
                    // *** Fin affichage de la table
                    break;

                /* Nombre de créations d'interventions sur une période donnée */
                case 3 :
                    // Définition et entête de la table
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    echo '<th>';
                    echo _('Agence');
                    echo '</th>';
                    echo '<th>';
                    echo _('Total créées');
                    echo '</th>';
                    echo '<th>';
                    echo _('Ouvertes');
                    echo '</th>';
                    echo '<th>';
                    echo _('Clients prévenus');
                    echo '</th>';
                    echo '<th>';
                    echo _('Closes');
                    echo '</th>';

                    $i = 0;

                    /* données pour toutes les agences */

                    // création de l'entête de ligne (TR)
                    echo '<tr>';

                    echo '<td>';
                    echo '<span class="annot_std_it">';
                    echo _('Toutes les agences');
                    echo '</span>';
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_int_crees_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_int_crees_total;
                        echo '</span>';
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_int_ouv_crees_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_int_ouv_crees_total;
                        echo '</span>';
                        if ($nb_int_crees_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo ' (' . round(($nb_int_ouv_crees_total / $nb_int_crees_total) * 100, 2) . '%)';
                            echo '</span>';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_int_prev_crees_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_int_prev_crees_total;
                        echo '</span>';
                        if ($nb_int_crees_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo ' (' . round(($nb_int_prev_crees_total / $nb_int_crees_total) * 100, 2) . '%)';
                            echo '</span>';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_int_clos_crees_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_int_clos_crees_total;
                        echo '</span>';
                        if ($nb_int_crees_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo ' (' . round(($nb_int_clos_crees_total / $nb_int_crees_total) * 100, 2) . '%)';
                            echo '</span>';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';

                    echo '</tr>';

                    $i++;

                    /* Saut de ligne pour lisibilité */

                    // création de l'entête de ligne (TR)
                    echo '<tr>';

                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';

                    echo '</tr>';

                    $i++;

                    if ($nb_age_select > 0) {
                        for ($j = 0; $j < $nb_age_select; $j++) {
                            // création de l'entête de ligne (TR)
                            echo '<tr>';

                            echo '<td>';
                            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                            $sql = 'SELECT age_nom FROM `' . TBAGE . "` WHERE `age_code` = '" . $code_agence[$j] . "'";
                            $rows = $db->get_results($sql, ARRAY_A);
                            if ($rows) {
                                foreach ($rows as $row) {
                                    $row = encode_str($row);
                                    extract($row);
                                    $txt_age = $age_nom;
                                }
                            }
                            close_database();
                            echo '<span class="annot_std_gras">';
                            echo $txt_age . ' (' . $code_agence[$j] . ')';
                            echo '</span>';
                            if ($age_ouvert == 0) {
                                echo '<span class="annot_petit_it">';
                                echo ' ' . _('Fermée');
                                echo '</span>';
                            }
                            echo '<br />';
                            if ($nb_int_crees_age[$j] <> 0) {
                                echo '<span class="annot_petit_it">';
                                echo '<div align="right">';
                                echo _('Par rapport agence') . ' : ';
                                echo '<br />' . _('Par rapport total') . ' : ';
                                echo '</div>';
                                echo '</span>';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_int_crees_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_int_crees_age[$j];
                                echo '</span>';
                                if ($nb_int_crees_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '<br />-<br />(' . round(($nb_int_crees_age[$j] / $nb_int_crees_total) * 100, 2) . '%)';
                                    echo '</span>';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_int_ouv_crees_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_int_ouv_crees_age[$j];
                                echo '</span>';
                                echo '<br />';
                                if ($nb_int_crees_age[$j] <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_int_ouv_crees_age[$j] / $nb_int_crees_age[$j]) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                                echo '<br />';
                                if ($nb_int_ouv_crees_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_int_ouv_crees_age[$j] / $nb_int_ouv_crees_total) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_int_prev_crees_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_int_prev_crees_age[$j];
                                echo '</span>';
                                echo '<br />';
                                if ($nb_int_crees_age[$j] <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo ' (' . round(($nb_int_prev_crees_age[$j] / $nb_int_crees_age[$j]) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                                echo '<br />';
                                if ($nb_int_prev_crees_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_int_prev_crees_age[$j] / $nb_int_prev_crees_total) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_int_clos_crees_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_int_clos_crees_age[$j];
                                echo '</span>';
                                echo '<br />';
                                if ($nb_int_crees_age[$j] <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo ' (' . round(($nb_int_clos_crees_age[$j] / $nb_int_crees_age[$j]) * 100, 2) . '%)';
                                    echo '</span>';
                                }
                                echo '<br />';
                                if ($nb_int_clos_crees_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_int_clos_crees_age[$j] / $nb_int_clos_crees_total) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';

                            echo '</tr>';

                            $i++;
                        }
                    } else {
                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        echo '<td>';
                        echo '<span class="annot_petit_it">';
                        echo _('Aucun résultat à cette demande') . '.';
                        echo '</span>';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';

                        echo '</tr>';
                    }

                    echo '</table>';
                    // *** Fin affichage de la table
                    break;

                /* Nombre de traitements d'interventions sur une période donnée */
                case 4 :
                    // Définition et entête de la table
                    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

                    echo '<th>';
                    echo _('Agence');
                    echo '</th>';
                    echo '<th>';
                    echo _('Total traitées');
                    echo '</th>';
                    echo '<th>';
                    echo _('Ouvertes');
                    echo '</th>';
                    echo '<th>';
                    echo _('Clients prévenus');
                    echo '</th>';
                    echo '<th>';
                    echo _('Closes');
                    echo '</th>';

                    $i = 0;

                    /* données pour toutes les agences */

                    // création de l'entête de ligne (TR)
                    echo '<tr>';

                    echo '<td>';
                    echo '<span class="annot_std_it">';
                    echo _('Toutes les agences');
                    echo '</span>';
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_int_trait_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_int_trait_total;
                        echo '</span>';
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_int_ouv_trait_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_int_ouv_trait_total;
                        echo '</span>';
                        if ($nb_int_trait_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo ' (' . round(($nb_int_ouv_trait_total / $nb_int_trait_total) * 100, 2) . '%)';
                            echo '</span>';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_int_prev_trait_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_int_prev_trait_total;
                        echo '</span>';
                        if ($nb_int_trait_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo ' (' . round(($nb_int_prev_trait_total / $nb_int_trait_total) * 100, 2) . '%)';
                            echo '</span>';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_int_clos_trait_total <> 0) {
                        echo '<span class="annot_std_it">';
                        echo $nb_int_clos_trait_total;
                        echo '</span>';
                        if ($nb_int_trait_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo ' (' . round(($nb_int_clos_trait_total / $nb_int_trait_total) * 100, 2) . '%)';
                            echo '</span>';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';

                    echo '</tr>';

                    $i++;

                    /* Saut de ligne pour lisibilité */

                    // création de l'entête de ligne (TR)
                    echo '<tr>';

                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';
                    echo '<td>';
                    echo '&nbsp;';
                    echo '</td>';

                    echo '</tr>';

                    $i++;

                    if ($nb_age_select > 0) {
                        for ($j = 0; $j < $nb_age_select; $j++) {
                            // création de l'entête de ligne (TR)
                            echo '<tr>';

                            echo '<td>';
                            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                            $sql = 'SELECT age_nom FROM `' . TBAGE . "` WHERE `age_code` = '" . $code_agence[$j] . "'";
                            $rows = $db->get_results($sql, ARRAY_A);
                            if ($rows) {
                                foreach ($rows as $row) {
                                    $row = encode_str($row);
                                    extract($row);
                                    $txt_age = $age_nom;
                                }
                            }
                            close_database();
                            echo '<span class="annot_std_gras">';
                            echo $txt_age . ' (' . $code_agence[$j] . ')';
                            echo '</span>';
                            if ($age_ouvert == 0) {
                                echo '<span class="annot_petit_it">';
                                echo ' ' . _('Fermée');
                                echo '</span>';
                            }
                            echo '<br />';
                            if ($nb_int_trait_age[$j] <> 0) {
                                echo '<span class="annot_petit_it">';
                                echo '<div align="right">';
                                echo _('Par rapport agence') . ' : ';
                                echo '<br />' . _('Par rapport total') . ' : ';
                                echo '</div>';
                                echo '</span>';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_int_trait_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_int_trait_age[$j];
                                echo '</span>';
                                if ($nb_int_trait_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '<br />-<br />(' . round(($nb_int_trait_age[$j] / $nb_int_trait_total) * 100, 2) . '%)';
                                    echo '</span>';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_int_ouv_trait_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_int_ouv_trait_age[$j];
                                echo '</span>';
                                echo '<br />';
                                if ($nb_int_trait_age[$j] <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_int_ouv_trait_age[$j] / $nb_int_trait_age[$j]) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                                echo '<br />';
                                if ($nb_int_ouv_trait_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_int_ouv_trait_age[$j] / $nb_int_ouv_trait_total) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_int_prev_trait_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_int_prev_trait_age[$j];
                                echo '</span>';
                                echo '<br />';
                                if ($nb_int_trait_age[$j] <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo ' (' . round(($nb_int_prev_trait_age[$j] / $nb_int_trait_age[$j]) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                                echo '<br />';
                                if ($nb_int_prev_trait_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_int_prev_trait_age[$j] / $nb_int_prev_trait_total) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';
                            echo '<td align="center">';
                            if ($nb_int_clos_trait_age[$j] <> 0) {
                                echo '<span class="annot_std_gras">';
                                echo $nb_int_clos_trait_age[$j];
                                echo '</span>';
                                echo '<br />';
                                if ($nb_int_trait_age[$j] <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo ' (' . round(($nb_int_clos_trait_age[$j] / $nb_int_trait_age[$j]) * 100, 2) . '%)';
                                    echo '</span>';
                                }
                                echo '<br />';
                                if ($nb_int_clos_trait_total <> 0) {
                                    echo '<span class="annot_petit_it">';
                                    echo '(' . round(($nb_int_clos_trait_age[$j] / $nb_int_clos_trait_total) * 100, 2) . '%)';
                                    echo '</span>';
                                } else {
                                    echo '-';
                                }
                            } else {
                                echo '-';
                            }
                            echo '</td>';

                            echo '</tr>';

                            $i++;
                        }
                    } else {
                        // création de l'entête de ligne (TR)
                        echo '<tr>';

                        echo '<td>';
                        echo '<span class="annot_petit_it">';
                        echo _('Aucun résultat à cette demande') . '.';
                        echo '</span>';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';
                        echo '<td>';
                        echo '&nbsp;';
                        echo '</td>';

                        echo '</tr>';
                    }

                    echo '</table>';
                    // *** Fin affichage de la table
                    break;

                default :
                    break;
            }
        }
    } else {
        pop_ret_auto(_('Aucune agence créée'), 'warn', 'index.php');
    }
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'index.php');
}
include_once 'pied.php';
?>
