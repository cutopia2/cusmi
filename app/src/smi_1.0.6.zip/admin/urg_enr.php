<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$niveau = (int)valpost('niveau');
$desc = str_majuscules(valpost('desc'));
$couleur = valpost('couleur');
$nduree = valpost('nduree');
$tduree = valpost('tduree');
$actif = (int)valpost('actif');

$retourliste = TRUE;
$msg = '';

$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
switch ($td) {
    // Ajout de la fiche Niveau urgence
    case 'add' :
        $rech = 'SELECT COUNT(*) FROM `' . TBURG . "` WHERE `urg_niveau` = '$niveau'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $rech = 'INSERT INTO `' . TBURG . '` (urg_niveau,urg_des,urg_couleur,urg_nduree,urg_tduree,urg_actif) VALUES ';
            $rech .= "('$niveau','" . $db->escape($desc) . "','$couleur','$nduree','$tduree','$actif')";
            $db->query($rech);
            $msg = _('Fiche ajoutée');
        } else {
            $msg = _('Ce code existe déjà');
            $retourliste = FALSE;
        }
        break;

    // Modification de la fiche Niveau urgence
    case 'edit' :
        $rech = 'UPDATE `' . TBURG . "` SET `urg_des`='" . $db->escape($desc) . "',`urg_couleur`='" . $couleur . "',`urg_nduree`='" . $nduree . "',";
        $rech .= "`urg_tduree`='" . $tduree . "',`urg_actif`='" . $actif . "' WHERE `urg_niveau` = '" . $niveau . "'";
        $db->query($rech);
        $msg = _('Fiche modifiée');
        break;

    // Suppression de la fiche Niveau urgence
    case 'del' :
        $pbm_del = FALSE;

        // Vérifie si supprimable
        $rech = 'SELECT COUNT(*) FROM `' . TBURG . "` WHERE `urg_niveau` = '$niveau' AND `urg_del` = 1";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $msg = _('Suppression impossible');
            $pbm_del = TRUE;
            $retourliste = FALSE;
        }

        // Vérifie si utilisé dans une fiche intervention
        $rech = 'SELECT COUNT(*) FROM `' . TBINT . "` WHERE `int_urg` = '$niveau'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs > 0) {
            $msg = _('Utilisé dans une fiche intervention');
            $pbm_del = TRUE;
            $retourliste = FALSE;
        }

        if ($pbm_del == FALSE) {
            // Non -> suppression de la fiche Niveau urgence
            $rech = 'DELETE FROM `' . TBURG . "` WHERE `urg_niveau` = '$niveau'";
            $db->query($rech);
            $msg = _('Fiche supprimée');
        }
        break;
    default :
        $msg = _('Problème de paramètres');
        $retourliste = FALSE;
        break;
}
close_database();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _("Fiche niveau d'urgence"); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    exec_func_js("warn_txt('" . str_escape($msg) . "')");
    aff_ret_idx_man($td, 'urg_lst.php', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'urg_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>