<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_pdt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$code = str_majuscules(valpost('code'));
$codeb = valpost('codeb');
$fam = str_majuscules(valpost('fam'));
$des = str_majuscules(valpost('des'));
$det = valpost('det');
$tva = valpost('tva');
$pu = (float)valpost('pu');
$uv = valpost('uv');
$venteok = (int)valpost('vendu');

$retourliste = TRUE;
$msg = '';
$codeuser = valsession('code_log');

switch ($td) {
    // Ajout de la fiche Produit
    case 'add' :
        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
        $rech = 'SELECT COUNT(*) FROM `' . TBPDT . "` WHERE pdt_code = '" . $db->escape($code) . "'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $rech2 = 'INSERT INTO `' . TBPDT . '`';
            $rech2 .= ' (pdt_datecrea,pdt_codecrea,pdt_datemod,pdt_codemod,pdt_code,pdt_codeb,pdt_fam,pdt_des,pdt_detail,pdt_puttc,pdt_vendu,pdt_codetva,pdt_codepdtu) VALUES';
            $rech2 .= " ('$datea','$codeuser','$datea','$codeuser','" . $db->escape($code) . "','" . $db->escape($codeb) . "','" . $db->escape($fam) . "','" . $db->escape($des) . "','" . $db->escape($det) . "','$pu','$venteok','$tva','$uv')";
            $db->query($rech2);

            $msg = _('Fiche ajoutée');
        } else {
            $msg = _('Ce code existe déjà');
            $retourliste = FALSE;
        }
        close_database();
        break;

    // MAJ de la fiche Produit
    case 'edit' :
        $existeint = FALSE;
        $majok = TRUE;

        // Vérifie si utilisé dans une fiche intervention non close
        if (exist_pdt_in_int_ouv($code) == TRUE) {
            $existeint = TRUE;
            if ($venteok == FALSE) {
                $majok = FALSE;
                $msg = _('Ce produit est utilisé dans une intervention non close') . '<br />' . _('Il faut le supprimer de cette intervention');
                $retourliste = FALSE;
            }
        }

        if ($majok == TRUE) {
            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

            // MAJ de la fiche Produit
            $rech = 'UPDATE `' . TBPDT . "` SET `pdt_datemod`='" . $datea . "', `pdt_codemod`='" . $codeuser . "', `pdt_codeb`='" . $db->escape($codeb) . "',";
            $rech .= " `pdt_fam`='" . $db->escape($fam) . "', `pdt_des`='" . $db->escape($des) . "', `pdt_detail`='" . $db->escape($det) . "', `pdt_puttc`='" . $pu . "',";
            $rech .= " `pdt_vendu`='" . $venteok . "', `pdt_codetva`='" . $tva . "', `pdt_codepdtu`='" . $uv . "'   WHERE `pdt_code` = '" . $db->escape($code) . "'";
            $db->query($rech);

            // Ce produit est présent dans une intervention ouverte
            // Il faut effectuer une mise à jour s'il y a des taxes rattachées
            if ($existeint == TRUE) {
                // On récupère la liste des interventions non terminées
                $rech = 'SELECT int_code FROM `' . TBINT . "` WHERE int_datefin = '0000-00-00'";
                $rows = $db->get_results($rech, ARRAY_A);

                if ($rows && (count($rows) > 0)) {
                    foreach ($rows as $row) {
                        extract($row);

                        // On récupère les infos du produit dans cette intervention
                        $rech0 = 'SELECT * FROM `' . TBPDTI . "` WHERE pdti_codeint = '$int_code' AND `pdti_codepdt` = '" . $db->escape($code) . "'";
                        $rows0 = $db->get_results($rech0, ARRAY_A);

                        if ($rows0 && (count($rows0) > 0)) {
                            foreach ($rows0 as $row0) {
                                extract($row0);

                                $codepdt = $pdti_codepdt;
                                $tvapdt = $pdti_codetva;
                                $qtepdt = $pdti_qte;
                                $pupdt = $pdti_puttc;

                                // SUPPRESSION des taxes rattachées à ce produit dans cette intervention
                                $rech1 = 'DELETE FROM `' . TBPDTI . "` WHERE pdti_codeint = '$int_code' AND `pdti_frompdt` = '" . $db->escape($codepdt) . "'";
                                $db->query($rech1);

                                // On récupère la liste des taxes utilisées par ce produit
                                $rech1 = 'SELECT * FROM `' . TBTPFA . "` WHERE tpfa_codepdt = '$codepdt' ORDER BY tpfa_id";
                                $rows1 = $db->get_results($rech1, ARRAY_A);

                                if ($rows1 && (count($rows1) > 0)) {
                                    foreach ($rows1 as $row1) {
                                        extract($row1);

                                        $txtcompl = '';

                                        // On récupère les infos pour cette taxe
                                        $rech2 = 'SELECT * FROM `' . TBTPF . "` WHERE tpf_code = '$tpfa_codetpf'";
                                        $rows2 = $db->get_results($rech2, ARRAY_A);

                                        if ($rows2 && (count($rows2) > 0)) {
                                            foreach ($rows2 as $row2) {
                                                extract($row2);

                                                // Calcul du code TVA
                                                $codetva_tpf = '';
                                                switch ($tpf_codetva) {
                                                    // -2 : Pas de TVA
                                                    case '-2' :
                                                        $codetva_tpf = 'TVA0';
                                                        break;
                                                    // -1 : TVA du produit
                                                    case '-1' :
                                                        $codetva_tpf = $tvapdt;
                                                        break;
                                                    // Autre : TVA définie
                                                    default :
                                                        $codetva_tpf = $tpf_codetva;
                                                        break;
                                                }

                                                // Calcul du taux de TVA
                                                $txtva_tpf = 0;
                                                $rech3 = 'SELECT * FROM `' . TBTVA . "` WHERE tva_code = '$codetva_tpf'";
                                                $row3 = $db->get_row($rech3, ARRAY_A);

                                                if ($row3) {
                                                    extract($row3);
                                                    $txtva_tpf = $tva_tx;
                                                }

                                                // Calcul du nombre de taxes
                                                $qte_tpf = 0;
                                                switch ($tpf_typmt) {
                                                    // 0 : Proportionnel au nombre de produits
                                                    case '0' :
                                                        $qte_tpf = $qtepdt;
                                                        $txtcompl .= ' ' . _('Taxe unitaire') . '.';
                                                        break;
                                                    // 1 : Fixe quel que soit le nombre de produits
                                                    case '1' :
                                                        $qte_tpf = 1;
                                                        $txtcompl .= ' ' . _('Taxe forfaitaire') . '.';
                                                        break;
                                                }

                                                // Calcul du montant TTC unitaire de la taxe
                                                $putttc_tpf = 0;
                                                switch ($tpf_pour) {
                                                    // 0 : Valeur
                                                    case '0' :
                                                        $puttc_tpf = $tpfa_mt;
                                                        break;
                                                    // 1 : Pourcentage
                                                    case '1' :
                                                        $puttc_tpf = $pupdt * round($tpfa_mt / 100, 2);
                                                        $txtcompl .= ' ' . full_num_format($tpfa_mt) . _('% sur prix unitaire');
                                                        if ($codetva_tpf == 'TVA0') {
                                                            $txtcompl .= ' TTC';
                                                        }
                                                        $txtcompl .= '.';
                                                        break;
                                                }

                                                // Réinjection de la taxe mise à jour pour ce produit dans cette intervention
                                                $rech4 = 'INSERT INTO `' . TBPDTI . '`';
                                                $rech4 .= ' (pdti_codeint,pdti_codepdt,pdti_frompdt,pdti_puttc,pdti_codetva,pdti_qte,pdti_ns,pdti_texte) VALUES';
                                                $rech4 .= " ('$int_code','$tpf_code','" . $db->escape($codepdt) . "','$puttc_tpf','$codetva_tpf','$qte_tpf','','" . $db->escape($txtcompl) . "')";
                                                $db->query($rech4);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            close_database();

            $msg = _('Fiche modifiée');
        }
        break;

    // Suppression de la fiche Produit
    case 'del' :
        $existint = FALSE;

        // Vérifie si utilisée dans une fiche intervention
        if (exist_pdt_in_int($code) == TRUE) {
            $existint = TRUE;
            $msg = _('Ce produit est utilisé dans une fiche intervention') . '<br />' . _("Passez-le en mode 'non commercialisé'");
            $retourliste = FALSE;
        }

        if ($existint == FALSE) {
            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

            // SUPPRESSION des taxes rattachées
            $rech = 'DELETE FROM `' . TBTPFA . "` WHERE `tpfa_codepdt` = '" . $db->escape($code) . "'";
            $db->query($rech);

            // SUPPRESSION de la fiche Produit
            $rech = 'DELETE FROM `' . TBPDT . "` WHERE `pdt_code` = '" . $db->escape($code) . "'";
            $db->query($rech);

            close_database();

            $msg = _('Fiche supprimée');
        }
        break;

    default :
        $msg = _('Problème de paramètres');
        $retourliste = FALSE;
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche Produit'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>
<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    exec_func_js("warn_txt('" . str_escape($msg) . "')");
    aff_ret_idx_man($td, 'pdt_lst.php?ta=m', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'pdt_lst.php?ta=m');
}
include_once 'pied.php';
?>
</body>
</html>