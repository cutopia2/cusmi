<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/fic_ope.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$txt_stat_ope = [
    1 => _('Nombre de créations de clients sur une période donnée')];

$pbm_stat = FALSE;
$aff_stat = FALSE;
$ts = 0;
$date1 = '';
$date2 = '';

// On a validé
if (valpost('nbutton') == 'calc') {

    $aff_stat = TRUE;

    $ts = (int)$_POST['ts'];

    $ope_select_tab = [];
    foreach ($_POST['ope'] as $iValue) {
        $ope_select_tab[] = $iValue;
    }

    $date1 = datetomysql($_POST['date1f']);
    $date2 = datetomysql($_POST['date2f']);

    switch ($ts) {
        /* Nombre de créations de clients sur une période donnée */
        case 1 :
            // Analyse des données et traitements statistiques
            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

            /* Initialisation des totaux généraux */
            $nb_cli_crees_total = 0;
            $nb_cli_prospects_crees_total = 0;
            $nb_cli_ddeint_crees_total = 0;
            $nb_cli_inter_crees_total = 0;

            /* Calcul des totaux généraux */
            $rech = 'SELECT ope_code FROM `' . TBOPE . '`';
            $rech .= ' ORDER BY ope_code';

            $rows = $db->get_results($rech, ARRAY_A);

            if ($rows && (count($rows) > 0)) {
                foreach ($rows as $row) {
                    extract($row);

                    // Détermination du nombre de clients créés par les opérateurs sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $ope_code . "'";
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";

                    $nb_cli_crees_total += $db->get_var($rech2);

                    // Détermination du nombre de clients encore prospects et créés par les opérateurs sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $ope_code . "'";
                    $rech2 .= ' AND cli_type=0';
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";

                    $nb_cli_prospects_crees_total += $db->get_var($rech2);

                    // Détermination du nombre de client ayant demandé une intervention (non effectuée) et créés par les opérateurs sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $ope_code . "'";
                    $rech2 .= ' AND cli_type=1';
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";

                    $nb_cli_ddeint_crees_total += $db->get_var($rech2);

                    // Détermination du nombre total de clients ayant demandé une intervention (effectuée) et créés par les opérateurs sur la période
                    $nb_cli_inter_crees_total = $nb_cli_crees_total - $nb_cli_prospects_crees_total - $nb_cli_ddeint_crees_total;
                }
            }

            /* Traitement par Opérateur */
            $rech = 'SELECT ope_code FROM `' . TBOPE . '`';

            // Traitement de multiples
            if (!in_array('*', $ope_select_tab,true)) {
                $rech .= ' WHERE (';
                foreach ($ope_select_tab as $iValue) {
                    $rech .= " ope_code='" . $iValue . "' OR";
                }
                // Suppression du dernier 'OR'
                $rech = substr($rech, 0, -3);
                $rech .= ')';
            }

            $rech .= ' ORDER BY ope_nom';

            $rows = $db->get_results($rech, ARRAY_A);

            $nb_ope_select = 0;
            if ($rows) {
                $nb_ope_select = count($rows);
            }

            $i = 0;

            if ($nb_ope_select > 0) {
                foreach ($rows as $row) {
                    extract($row);

                    // Récupération du code Opérateur
                    $code_ope[$i] = $ope_code;

                    // Détermination du nombre de clients créés par l'Opérateur sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $ope_code . "'";
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";

                    $nb_cli_crees_ope[$i] = $db->get_var($rech2);

                    // Détermination du nombre de clients encore prospects et créés par l'Opérateur sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $ope_code . "'";
                    $rech2 .= ' AND cli_type=0';
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";

                    $nb_cli_prospects_crees_ope[$i] = $db->get_var($rech2);

                    // Détermination du nombre de client ayant demandé une intervention (non effectuée) et créés par l'Opérateur sur la période
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBCLI . '`';
                    $rech2 .= " WHERE cli_codecrea='" . $ope_code . "'";
                    $rech2 .= ' AND cli_type=1';
                    $rech2 .= " AND cli_datecrea>='" . $date1 . "' AND cli_datecrea<='" . $date2 . "'";

                    $nb_cli_ddeint_crees_ope[$i] = $db->get_var($rech2);

                    // Détermination du nombre total de clients ayant demandé une intervention (effectuée) et créés par l'Opérateur sur la période
                    $nb_cli_inter_crees_ope[$i] = $nb_cli_crees_ope[$i] - $nb_cli_prospects_crees_ope[$i] - $nb_cli_ddeint_crees_ope[$i];

                    $i++;
                }
            }
            close_database();

            $aff_stat = TRUE;
            break;

        default :
            $pbm_stat = TRUE;
            break;
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Statistiques opérateurs'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab_champ = [];
        //-->
    </script>

    <script type="text/javascript">
        <!--
        <?php
        if ($aff_stat == FALSE)
        {
        ?>
        function init_datepicker() {
            <?php include_once '../jscript/datepicker_prm.js.php'; ?>
            $("#date1f").datepicker({
                onSelect: function (datesel) {
                    $("#date1f").blur();
                    chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, '', '', 'date2f', false);
                }
            });
            $("#date2f").datepicker({
                onSelect: function (datesel) {
                    $("#date2f").blur();
                    chk_datedif(datesel, this.id, '<?php echo valsession('date_fmtshort'); ?>', true, 'date1f', '', 'today', false);
                }
            });
        }
        <?php } ?>

        function init_all() {
            init_Body();
            <?php
            if ($aff_stat == TRUE)
            {
                echo "init_autohref('newstat', 'click', '', true);";
                echo "readonly_all_id('prm_stat');";
            }
            else
            {
                echo 'init_datepicker();';
                echo "init_stats_ope('calc','prm_stat','".valsession('date_fmtshort')."',tab_champ,'','');";
                echo "init_autoraz('razdate1f','date1f','click');";
                echo "init_autoraz('razdate2f','date2f','click');";
            }
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>

<body>

<?php
include_once '../inc/entete.inc.php';
cre_ent_form(_('STATISTIQUES OPERATEURS'), '', '', '', FALSE);
if ($pbm_stat == FALSE) {
if (nb_ope() > 0) {
if ($aff_stat == TRUE) {
    cre_falselnk('', 'newstat', 'div', '', _('Autre statistique'), 'ope_stat.php', '../img/stat.png', _('Autre statistique'));
}
?>
<div align="center" style="margin-top: 5px; margin-bottom: 5px;">
    <form name="prm_stat" id="prm_stat" class="bord_pointilles" method="post" action="ope_stat.php">
        <input name="today" type="hidden" id="today" value="<?php echo $datef; ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <?php
        cre_select('ts', 'ts', $txt_stat_ope, $ts, '', _('-- Faites votre choix --'));
        if ($aff_stat == FALSE) {
            ?>
            <table width="100%" border="0">
                <tr>
                    <td width="50%" align="center">
                        <?php echo _('Choisissez un opérateur tééphonique (sélections multiples possibles)'); ?>
                        <div
                            class="annot_petit_it"><?php echo '(' . _("Si 'Tous', les opérateurs licenciés seront aussi analysés") . ')'; ?></div>
                    </td>
                </tr>
                <tr>
                    <td width="50%" align="center">
                        <?php
                        // Création de la liste des opérateurs actifs
                        $tab_ope = give_tab_ope();
                        cre_select('ope[]', 'ope', $tab_ope, '*', '*', _('---------- Tous ----------'), 5, TRUE);
                        ?>
                    </td>
                </tr>
            </table>
            <?php
        } else {
            echo '<br /><br />';
        }
        ?>
        <div id="dates">
            <span class="rubfrm" id="f_date1" style="margin-right: 5px;"><?php echo ' ' . _('Du') . '... '; ?></span>
            <input name="date1f" type="text" id="date1f" size="10" value="<?php echo datetolocal($date1); ?>"
                   maxlength="10" readonly>
            <?php
            if ($aff_stat == FALSE) {
                echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                echo ' <img src="../img/raz.png" id ="razdate2f" border="0" align="absmiddle">';
            }
            ?>
            <span class="rubfrm" id="f_date2f" style="margin-right: 5px;"><?php echo ' ' . _('Au') . '... '; ?></span>
            <input name="date2f" type="text" id="date2f" size="10" value="<?php echo datetolocal($date1); ?>"
                   maxlength="10" readonly>
            <?php
            if ($aff_stat == FALSE) {
                echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                echo ' <img src="../img/raz.png" id ="razdate2f" border="0" align="absmiddle">';
            }
            ?>
        </div>
        <?php
        if ($aff_stat == FALSE) {
            echo '<p align="center">';
            echo '<input name="calc" type="button" class="bton_std" id="calc" value="' . _('Calculer') . '">';
            echo ' <input name="init" type="reset" class="bton_std" id="init" value="' . _('Réinitialiser') . '">';
            echo '</p>';
        }
        ?>
    </form>

    <?php
    switch ($ts) {
        case 1 :
            // Définition et entête de la table
            echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

            echo '<th>';
            echo _('Opérateur');
            echo '</th>';
            echo '<th>';
            echo _('Total créés');
            echo '</th>';
            echo '<th>';
            echo _('Encore prospects');
            echo '</th>';
            echo '<th>';
            echo _('Attente intervention');
            echo '</th>';
            echo '<th>';
            echo _('Intervention');
            echo '</th>';

            $i = 0;

            /* données pour tous les opérateurs */

            // création de l'entête de ligne (TR)
            echo '<tr>';

            echo '<td>';
            echo '<span class="annot_std_it">';
            echo _('Tous les opérateurs');
            echo '</span>';
            echo '</td>';
            echo '<td align="center">';
            if ($nb_cli_crees_total <> 0) {
                echo '<span class="annot_std_it">';
                echo $nb_cli_crees_total;
                echo '</span>';
            } else {
                echo '-';
            }
            echo '</td>';
            echo '<td align="center">';
            if ($nb_cli_prospects_crees_total <> 0) {
                echo '<span class="annot_std_it">';
                echo $nb_cli_prospects_crees_total;
                echo '</span>';
                if ($nb_cli_crees_total <> 0) {
                    echo '<span class="annot_petit_it">';
                    echo ' (' . round(($nb_cli_prospects_crees_total / $nb_cli_crees_total) * 100, 2) . '%)';
                    echo '</span>';
                }
            } else {
                echo '-';
            }
            echo '</td>';
            echo '<td align="center">';
            if ($nb_cli_ddeint_crees_total <> 0) {
                echo '<span class="annot_std_it">';
                echo $nb_cli_ddeint_crees_total;
                echo '</span>';
                if ($nb_cli_crees_total <> 0) {
                    echo '<span class="annot_petit_it">';
                    echo ' (' . round(($nb_cli_ddeint_crees_total / $nb_cli_crees_total) * 100, 2) . '%)';
                    echo '</span>';
                }
            } else {
                echo '-';
            }
            echo '</td>';
            echo '<td align="center">';
            if ($nb_cli_inter_crees_total <> 0) {
                echo '<span class="annot_std_it">';
                echo $nb_cli_inter_crees_total;
                echo '</span>';
                if ($nb_cli_crees_total <> 0) {
                    echo '<span class="annot_petit_it">';
                    echo ' (' . round(($nb_cli_inter_crees_total / $nb_cli_crees_total) * 100, 2) . '%)';
                    echo '</span>';
                }
            } else {
                echo '-';
            }
            echo '</td>';

            echo '</tr>';

            $i++;

            /* Saut de ligne pour lisibilité */

            // création de l'entête de ligne (TR)
            echo '<tr>';

            echo '<td>';
            echo '&nbsp;';
            echo '</td>';
            echo '<td>';
            echo '&nbsp;';
            echo '</td>';
            echo '<td>';
            echo '&nbsp;';
            echo '</td>';
            echo '<td>';
            echo '&nbsp;';
            echo '</td>';
            echo '<td>';
            echo '&nbsp;';
            echo '</td>';

            echo '</tr>';

            $i++;

            if ($nb_ope_select > 0) {
                for ($j = 0; $j < $nb_ope_select; $j++) {
                    // création de l'entête de ligne (TR)
                    echo '<tr>';

                    echo '<td>';
                    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

                    $rech = 'SELECT * FROM `' . TBOPE . "` WHERE `ope_code` = '" . $code_ope[$j] . "'";
                    $row = $db->get_row($rech, ARRAY_A);

                    if ($row) {
                        $row = encode_str($row);
                        extract($row);
                        $txt_ope = $ope_nom . ' ' . $ope_prenom;
                    }
                    close_database();
                    echo '<span class="annot_std_gras">';
                    echo $txt_ope . ' (' . $code_ope[$j] . ')';
                    echo '</span>';
                    if ($ope_out == 1) {
                        echo '<span class="annot_petit_it">';
                        echo ' ' . _('Plus présent');
                        echo '</span>';
                    }
                    echo '<br />';
                    echo '</span>';
                    if ($nb_cli_crees_ope[$j] <> 0) {
                        echo '<span class="annot_petit_it">';
                        echo '<div align="right">';
                        echo _('Par rapport Opérateur') . ' : ';
                        echo '<br />' . _('Par rapport total') . ' : ';
                        echo '</div>';
                        echo '</span>';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_cli_crees_ope[$j] <> 0) {
                        echo '<span class="annot_std_gras">';
                        echo $nb_cli_crees_ope[$j];
                        echo '</span>';
                        if ($nb_cli_crees_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo '<br />-<br />(' . round(($nb_cli_crees_ope[$j] / $nb_cli_crees_total) * 100, 2) . '%)';
                            echo '</span>';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_cli_prospects_crees_ope[$j] <> 0) {
                        echo '<span class="annot_std_gras">';
                        echo $nb_cli_prospects_crees_ope[$j];
                        echo '</span>';
                        echo '<br />';
                        if ($nb_cli_crees_ope[$j] <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo '(' . round(($nb_cli_prospects_crees_ope[$j] / $nb_cli_crees_ope[$j]) * 100, 2) . '%)';
                            echo '</span>';
                        } else {
                            echo '-';
                        }
                        echo '<br />';
                        if ($nb_cli_prospects_crees_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo '(' . round(($nb_cli_prospects_crees_ope[$j] / $nb_cli_prospects_crees_total) * 100, 2) . '%)';
                            echo '</span>';
                        } else {
                            echo '-';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_cli_ddeint_crees_ope[$j] <> 0) {
                        echo '<span class="annot_std_gras">';
                        echo $nb_cli_ddeint_crees_ope[$j];
                        echo '</span>';
                        echo '<br />';
                        if ($nb_cli_crees_ope[$j] <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo ' (' . round(($nb_cli_ddeint_crees_ope[$j] / $nb_cli_crees_ope[$j]) * 100, 2) . '%)';
                            echo '</span>';
                        } else {
                            echo '-';
                        }
                        echo '<br />';
                        if ($nb_cli_ddeint_crees_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo '(' . round(($nb_cli_ddeint_crees_ope[$j] / $nb_cli_ddeint_crees_total) * 100, 2) . '%)';
                            echo '</span>';
                        } else {
                            echo '-';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';
                    echo '<td align="center">';
                    if ($nb_cli_inter_crees_ope[$j] <> 0) {
                        echo '<span class="annot_std_gras">';
                        echo $nb_cli_inter_crees_ope[$j];
                        echo '</span>';
                        echo '<br />';
                        if ($nb_cli_crees_ope[$j] <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo ' (' . round(($nb_cli_inter_crees_ope[$j] / $nb_cli_crees_ope[$j]) * 100, 2) . '%)';
                            echo '</span>';
                        }
                        echo '<br />';
                        if ($nb_cli_inter_crees_total <> 0) {
                            echo '<span class="annot_petit_it">';
                            echo '(' . round(($nb_cli_inter_crees_ope[$j] / $nb_cli_inter_crees_total) * 100, 2) . '%)';
                            echo '</span>';
                        } else {
                            echo '-';
                        }
                    } else {
                        echo '-';
                    }
                    echo '</td>';

                    echo '</tr>';

                    $i++;
                }
            } else {
                // création de l'entête de ligne (TR)
                echo '<tr>';

                echo '<td>';
                echo '<span class="annot_petit_it">';
                echo _('Aucun résultat à cette demande') . '.';
                echo '</span>';
                echo '</td>';
                echo '<td>';
                echo '&nbsp;';
                echo '</td>';
                echo '<td>';
                echo '&nbsp;';
                echo '</td>';
                echo '<td>';
                echo '&nbsp;';
                echo '</td>';
                echo '<td>';
                echo '&nbsp;';
                echo '</td>';

                echo '</tr>';
            }

            echo '</table>';
            // *** Fin affichage de la table

            break;
    }
    } else {
        pop_ret_auto(_('Aucun Opérateur créé'), 'warn', 'index.php');
    }
    } else {
        pop_ret_auto(_('Problème de paramètres'), 'warn', 'index.php');
    }
    include_once 'pied.php';
    ?>
</body>
</html>