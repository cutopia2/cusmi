<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_mque.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$td = $_GET['td'];
$coderech = $_GET['code'];

$pbm_mquet = FALSE;

if ($coderech <> '') {
    $row = lit_enr_tmque($coderech);
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);
        if (($mquet_delok == FALSE) && ($td == 'del')) {
            $pbm_mquet = TRUE;
        }
    } else {
        $pbm_mquet = TRUE;
    }
} else {
    if ($td <> 'add') {
        $pbm_mquet = TRUE;
    }
}

$titre ='';
if ($pbm_mquet == FALSE) {
    switch ($td) {
        case 'add' :
            $titre = _('CREATION CATEGORIE MARQUE');
            break;
        case 'edit' :
            $titre = _('MISE A JOUR CATEGORIE MARQUE');
            break;
        case 'del' :
            $titre = _('SUPPRESSION CATEGORIE MARQUE');
            break;
        default :
            $pbm_mquet = TRUE;
            break;
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-type=" content="text/html; charset=utf-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche Catégorie Marque'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>
    <script language="javascript">
        <!--
        const tab_champ = ["nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?> ; lmn:1 ; lmx:5; stok:frmok ; stbad:frmbad",
            "nom:desc ; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?>; lmn:1 ; lmx:50; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_mquet == FALSE) { ?>
        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                <?php
                switch ($td)
                {
                    case 'add' :
                        echo "init_valid_form('enr','mquet_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                        break;
                    case 'edit' :
                        echo "init_valid_form('enr','mquet_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                        break;
                    case 'view' :
                        echo 'readonly_all();';
                        break;
                    case 'del' :
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                }
                ?>
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';
if ($pbm_mquet == FALSE) {
    cre_ent_form($titre, 'mquet_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="mquet_maj" id="mquet_maj" method="post" action="mquet_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="10%" class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                <td width="47%">
                    <input name="code" type="text" id="code" value="<?php echo $mquet_code ?>" size="5">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_desc" align="right"><?php echo _('Libellé'); ?></td>
                <td><input name="desc" type="text" id="desc" value="<?php echo $mquet_desc; ?>" size="50">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_rpdt" align="right"><?php echo _('Relevés Produits'); ?> ?</td>
                <td>
                    <?php
                    cre_select('rpdt', 'rpdt', $non_oui, (int)$mquet_rpdt);
                    echo '<div class="annot_petit_it">' . _('Si Oui, est utilisable dans les relevés matériels') . '</div>';
                    ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_rlic" align="right"><?php echo _('Relevés Licences'); ?> ?</td>
                <td>
                    <?php
                    cre_select('rlic', 'rlic', $non_oui, (int)$mquet_rlic);
                    echo '<div class="annot_petit_it">' . _('Si Oui, est utilisable dans les relevés licences') . '</div>';
                    ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_assu" align="right"><?php echo _('Assurance'); ?> ?</td>
                <td>
                    <?php
                    cre_select('assu', 'assu', $non_oui, (int)$mquet_assu);
                    echo '<div class="annot_petit_it">' . _('Si Oui est utilisable dans les assurances de matériels') . '</div>';
                    ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_dist" align="right"><?php echo _('Distributeur'); ?> ?</td>
                <td>
                    <?php
                    cre_select('dist', 'dist', $non_oui, (int)$mquet_dist);
                    echo '<div class="annot_petit_it">' . _('Si Oui est utilisable pour les retours ou pour information.') . '</div>';
                    ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_oc" align="right"><?php echo _('Organisme collecteur'); ?> ?</td>
                <td>
                    <?php
                    cre_select('oc', 'oc', $non_oui, (int)$mquet_oc);
                    echo '<div class="annot_petit_it">' . _('Si Oui est utilisable pour les taxes de recylclage') . '</div>';
                    ?>
                </td>
            </tr>
        </table>
        <p align="center">
            <?php
            switch ($td) {
                case 'add' :
                case 'edit' :
                    echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Enregistrer') . '">';
                    echo ' <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="' . _('Réinitialiser') . '">';
                    break;
                case 'del' :
                    echo '<input name="del" type="submit" class="bton_std" id="del" value="' . _('Supprimer') . '">';
                    break;
            }
            ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'mquet_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>