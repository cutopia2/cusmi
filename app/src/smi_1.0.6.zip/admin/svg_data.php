<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';
if (CheckURLLog(FALSE) == FALSE) {
    header('Location: ../index.php');
}
if (CheckNivLog('9') == FALSE) {
    header('Location: ../index.php');
}
include_once '../inc/fic_droits.inc.php';
include_once '../inc/fic_prm.inc.php';
include_once '../inc/fic_prmmail.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../classes/mysqlbckup/mysql_db_backup.class.php';

include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$pbm_svg = FALSE;
$stock = 0;
$typsvg = 0;
$msg = '';

if (isset($_GET['td'])) {
    $typsvg = (int)$_GET['td'];
} else {
    $pbm_svg = TRUE;
}
if (isset($_GET['s'])) {
    $stock = (int)$_GET['s'];
} else {
    $pbm_svg = TRUE;
}
if (isset($_GET['m'])) {
    $mail = $_GET['m'];
} else {
    $pbm_svg = TRUE;
}

$titre = _('SAUVEGARDE DES DONNEES');

if ($pbm_svg == FALSE) {
    $backup_obj = new MySQL_DB_Backup();

    $backup_obj->server = DBHOST;
    $backup_obj->port = 3306;
    $backup_obj->username = DBUSER;
    $backup_obj->password = DBPASS;
    $backup_obj->database = DBNAME;

    // Verrouillage de la table avant la sauvegarde (verrou levé après)
    $backup_obj->locks = true;

    // On autorise le DROP TABLES IF EXISTS avant CREATE TABLE
    $backup_obj->drop_tables = true;

    // On autorise les commentaires
    $backup_obj->comments = true;

    // Répertoire où l'on sauve le fichier (également pour stockage temporaire en cas de compression)
    $backup_obj->backup_dir = trim($url_svg);

    // Format par défaut du fichier
    $backup_obj->fname_format = 'd_m_Y';

    // On sauve toutes les tables
    $backup_obj->tables = [];

    // On dit que l'on veut envoyer en mode download
    $task = MSX_DOWNLOAD;
    if ($stock == 1) {
        if (trim($url_svg) <> '') {
            $task = MSX_SAVE;
        }
    }

    // On compresse
    $use_gzip = true;

    $nom = 'smi';
    $row = lit_enr_cdg();
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);
        $nom .= '_' . strtolower(str_replace(' ', '_', $cge_nom));
    }

    switch ($typsvg) {
        case 1 :
            // Nom du fichier de sauvegarde
            $filename = 'svg_' . $nom . '_struct_' . date('d_m_Y') . '-' . date('H_i_s') . '.sql.gz';

            // On prend que la structure
            $backup_obj->struct_only = TRUE;
            break;

        case 2 :
            // Nom du fichier de sauvegarde
            $filename = 'svg_' . $nom . '_all_' . date('d_m_Y') . '-' . date('H_i_s') . '.sql.gz';

            // On prend la structure et les données
            $backup_obj->struct_only = FALSE;
            break;

        default :
            break;
    }

    if (!$backup_obj->Execute($task, $filename, $use_gzip)) {
        $msg = $backup_obj->error;
        $retourliste = FALSE;
    } else {
        $msg = _('Sauvegarde') . ' ';
        if ($mail == 1) {
            $msg .= _('envoyée');
        } else {
            if ($stock == 1) {
                $msg .= _('effectuée');
            }
        }
        $msg .= ' ' . _('le') . ' <b>' . datetolocal($datea) . '</b>';
        $retourliste = TRUE;
    }

} else {
    header('Location: ../index.php');
}

if ($task != MSX_DOWNLOAD)
{
include_once '../inc/func.inc.php';
include_once '../inc/func_fic.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';

if ($mail == 1) {
    include_once '../inc/func_txtcm.inc.php';
    include_once '../classes/phpmailer/class.phpmailer.php';
    include_once '../classes/phpmailer/class.smtp.php';
    include_once '../inc/mail.inc.php';

    $mail = new PHPMailer();
    $mail->CharSet = 'UTF-8';
    $mail->Host = $smtp_nom;
    $mail->Port = $smtp_port;
    if (trim($smtp_login) <> '') {
        $mail->Username = $smtp_login;
        $mail->Password = $smtp_mdp;
        $mail->SMTPAuth = true;
    } else {
        $mail->Username = '';
        $mail->Password = '';
        $mail->SMTPAuth = false;
    }
    $mail->isHTML(TRUE);
    $mail->Mailer = 'smtp';

    // entête de l'email
    $mail->Priority = 1;

    //Expédié par
    $mail->From = $admin_mail;
    $mail->FromName = $admin_name;
    $mail->Sender = $admin_mail;

    //Réponse automatique à...
    $mail->addReplyTo($admin_mail, $admin_name);

    // Le destinataire est le webmaster
    $mail->addAddress($admin_mail, $admin_name);

    // Corps de l'email
    $txtcorps = _('Dernière sauvegarde en pièce attachée');
    $sujet = _('Sauvegarde SMI du') . ' ' . datetolocal($datea);

    $mail->Subject = $sujet;
    $mail->Body = $txtcorps;
    $mail->addAttachment($url_svg . $filename);

    $sent = $mail->send();

    $mail->smtpClose();
    $mail->clearAllRecipients();
    unset($mail);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Sauvegarde données'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>
<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    exec_func_js("warn_txt('" . str_escape($msg) . "')");
} else {
    exec_func_js("pop_txt('" . str_escape($msg) . "')");
}
aff_ret_idx_man($td, '', '', FALSE);

include_once 'pied.php';
}
?>
