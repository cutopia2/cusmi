<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_cocl.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$code = str_majuscules(valpost('code'));
$desc = str_majuscules(valpost('desc'));
$default = (int)valpost('default');
$actif = (int)valpost('actif');
$typarr = (int)valpost('typarr');
$codeper = str_majuscules(valpost('codeper'));
$pourm = (float)valpost('pourm');
$pour1 = (float)valpost('pour1');
$pour2 = (float)valpost('pour2');
$pour3 = (float)valpost('pour3');

$retourliste = TRUE;
$msg = '';

if (($actif == 0) && ($default == 1)) {
    $msg = _('Impossible de désactiver une catégorie et de la choisir par défaut');
    $retourliste = FALSE;
}

if ($msg == '') {
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
    switch ($td) {
        // Ajout de la fiche Catégorie
        case 'add' :
            $rech = 'SELECT COUNT(*) FROM `' . TBCOCLCAT . "` WHERE `coclcat_code` = '" . $db->escape($code) . "'";
            $nb_rs = $db->get_var($rech);
            if (($nb_rs == 0) && ($code <> '-1')) {
                $sql2 = 'INSERT INTO `' . TBCOCLCAT . '`(coclcat_code,coclcat_desc,coclcat_default,coclcat_actif,coclcat_typarr,coclcat_codeper,coclcat_pourm,coclcat_pour1,coclcat_pour2,coclcat_pour3)';
                $sql2 .= " VALUES ('" . $db->escape($code) . "','" . $db->escape($desc) . "','$default','$actif','$typarr','" . $db->escape($codeper) . "','$pourm','$pour1','$pour2','$pour3')";
                $db->query($sql2);

                // Cette catégorie a été définie "par défaut"
                if ($default == 1) {
                    // On passe toutes les cagétories à "pas par défaut" sauf la catégorie qui vient d'être créée
                    $rech = 'UPDATE `' . TBCOCLCAT . "` SET `coclcat_default`=0 WHERE `coclcat_code` <> '" . $db->escape($code) . "'";
                    $db->query($rech);
                }

                $msg = _('Fiche ajoutée');
            } else {
                $msg = _('Ce code existe déjà');
                $retourliste = FALSE;
            }
            break;

        // Modification de la fiche Catégorie
        case 'edit' :
            $editok = TRUE;

            if ($actif == 0) {
                if (exist_coclcat_in_cocl($code, FALSE) == TRUE) {
                    $msg = _('Cette catégorie est utilisée dans un contrat');
                    $editok = FALSE;
                }
            }

            if ($editok == FALSE) {
                $retourliste = FALSE;
            } else {
                $sql2 = 'UPDATE `' . TBCOCLCAT . "` SET `coclcat_desc`='" . $db->escape($desc) . "',  `coclcat_default`=' $default',";
                $sql2 .= "  `coclcat_actif`='$actif', `coclcat_typarr`='$typarr', `coclcat_codeper`='" . $db->escape($codeper) . "',";
                $sql2 .= " `coclcat_pourm`='$pourm', `coclcat_pour1`='$pour1', `coclcat_pour2`='$pour2', `coclcat_pour3`='$pour3'";
                $sql2 .= " WHERE `coclcat_code` = '" . $db->escape($code) . "'";
                $db->query($sql2);

                // Cette catégorie a été définie "par défaut"
                if ($default == 1) {
                    // On passe toutes les catégories à "pas par défaut" sauf la catégorie qui vient d'être créée
                    $rech = 'UPDATE `' . TBCOCLCAT . "` SET `coclcat_default`=0 WHERE `coclcat_code` <> '" . $db->escape($code) . "'";
                    $db->query($rech);
                }

                $msg = _('Fiche modifiée');
            }

            break;

        // Suppression de la fiche Catégorie
        case 'del' :
            $delok = TRUE;
            // Vérifie si utilisée dans un contrat
            if (exist_coclcat_in_cocl($code, FALSE) == TRUE) {
                $msg = _('Cette catégorie est utilisée dans un contrat');
                $delok = FALSE;
            }

            if ($delok == FALSE) {
                $retourliste = FALSE;
            } else {
                // Non -> suppression de la fiche Catégorie
                $rech = 'DELETE FROM `' . TBCOCLCAT . "` WHERE `coclcat_code` = '" . $db->escape($code) . "'";
                $db->query($rech);
                $msg = _('Fiche supprimée');
            }
            break;
        default :
            $msg = _('Problème de paramètres');
            $retourliste = FALSE;
            break;
    }
    close_database();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche catégorie contrat'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            <?php
            if ($retourliste == FALSE)
                {echo "warn_txt('" . str_escape($msg) . "');";}
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    aff_ret_idx_man($td, 'coclcat_lst.php', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'coclcat_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>