<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if (CheckURLLog(TRUE) == FALSE) {
    header('Location: ../index.php');
}
if (CheckNivLog('9') == FALSE) {
    header('Location: ../index.php');
}
include_once '../inc/fic_age.inc.php';
include_once '../inc/fic_hum.inc.php';
include_once '../inc/fic_cli.inc.php';
include_once '../inc/fic_do.inc.php';
include_once '../inc/fic_ope.inc.php';
include_once '../inc/fic_st.inc.php';
include_once '../inc/fic_tec.inc.php';
include_once '../inc/fic_txt.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_fic.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/func_txtcm.inc.php';
include_once '../inc/func_mail.inc.php';
include_once '../classes/phpmailer/class.phpmailer.php';
include_once '../classes/phpmailer/class.smtp.php';
include_once '../inc/mail.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$categorie = strtolower($_GET['cat']);

$titre = valpost('titre');
$code = valpost('code');

$log_ip = $_SERVER['REMOTE_ADDR']; // Récupération adresse IP

$retourliste = FALSE;
$msg = '';

if (valpost('nbutton') == 'reinit') {
    $nouvmdp = cremdp(FALSE); // création d'un nouveau de passe (envoyé)
    $nouvmdpcrypte = md5($nouvmdp); // Cryptage du nouveau mot de passe (stocké)

    $upd = '';

    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
    switch ($categorie) {
        // MAJ de la fiche centre de gestion
        case 'siege' :
            $rech = 'SELECT cge_id,cge_code FROM `' . TBCG . '`';
            $row = $db->get_row($rech, ARRAY_A);

            if ($row) // Uniquement UN SEUL enregistrement !
            {
                extract($row);
                $code = $cge_code;
                $upd = 'UPDATE `' . TBCG . "` SET `cge_pass`='" . $nouvmdpcrypte . "'  WHERE `cge_id` = '" . $cge_id . "'";
            }
            break;

        // MAJ de la fiche Agence
        case 'age' :
            $rech = 'SELECT age_id FROM `' . TBAGE . "` WHERE `age_code` = '" . $db->escape($code) . "'";
            $row = $db->get_row($rech, ARRAY_A);

            if ($row) // Uniquement UN SEUL enregistrement !
            {
                extract($row);
                $upd = 'UPDATE `' . TBAGE . "` SET `age_pass`='" . $nouvmdpcrypte . "'  WHERE `age_id` = '" . $age_id . "'";
            }
            break;

        // MAJ de la fiche Technicien
        case 'tec' :
            $rech = 'SELECT tec_id FROM `' . TBTEC . "` WHERE `tec_code` = '" . $db->escape($code) . "'";
            $row = $db->get_row($rech, ARRAY_A);

            if ($row) // Uniquement UN SEUL enregistrement !
            {
                extract($row);
                $upd = 'UPDATE `' . TBTEC . "` SET `tec_pass`='" . $nouvmdpcrypte . "'  WHERE `tec_id` = '" . $tec_id . "'";
            }
            break;

        // MAJ de la fiche contact Client
        case 'ccli' :
            $rech = 'SELECT ccli_id FROM `' . TBCCLI . "` WHERE `ccli_code` = '" . $db->escape($code) . "'";
            $row = $db->get_row($rech, ARRAY_A);

            if ($row) // Uniquement UN SEUL enregistrement !
            {
                extract($row);
                $upd = 'UPDATE `' . TBCCLI . "` SET `ccli_pass`='" . $nouvmdpcrypte . "'  WHERE `ccli_id` = '" . $ccli_id . "'";
            }

            break;

        // MAJ de la fiche Client
        case 'cli' :
            $rech = 'SELECT cli_id FROM `' . TBCLI . "` WHERE `cli_code` = '" . $db->escape($code) . "'";
            $row = $db->get_row($rech, ARRAY_A);
            if ($row) // Uniquement UN SEUL enregistrement !
            {
                extract($row);
                $upd = 'UPDATE `' . TBCLI . "` SET `cli_pass`='" . $nouvmdpcrypte . "'  WHERE `cli_id` = '" . $cli_id . "'";
            }

            break;

        // MAJ de la fiche Opérateur
        case 'ope' :
            $rech = 'SELECT ope_id FROM `' . TBOPE . "` WHERE `ope_code` = '" . $db->escape($code) . "'";
            $row = $db->get_row($rech, ARRAY_A);

            if ($row) // Uniquement UN SEUL enregistrement !
            {
                extract($row);
                $upd = 'UPDATE `' . TBOPE . "` SET `ope_pass`='" . $nouvmdpcrypte . "'  WHERE `ope_id` = '" . $ope_id . "'";
            }
            break;

        // MAJ de la fiche Donneur d'ordres
        case 'do' :
            $rech = 'SELECT do_id FROM `' . TBDO . "` WHERE `do_code` = '" . $db->escape($code) . "'";
            $row = $db->get_row($rech, ARRAY_A);

            if ($row) // Uniquement UN SEUL enregistrement !
            {
                extract($row);
                $upd = 'UPDATE `' . TBDO . "` SET `do_pass`='" . $nouvmdpcrypte . "'  WHERE `do_id` = '" . $do_id . "'";
            }
            break;

        // MAJ de la fiche Sous-traitant
        case 'st' :
            $rech = 'SELECT st_id FROM `' . TBST . "` WHERE `st_code` = '" . $db->escape($code) . "'";
            $row = $db->get_row($rech, ARRAY_A);

            if ($row) // Uniquement UN SEUL enregistrement !
            {
                extract($row);
                $upd = 'UPDATE `' . TBST . "` SET `st_pass`='" . $nouvmdpcrypte . "'  WHERE `st_id` = '" . $st_id . "'";
            }
            break;
    }
    if ($upd <> '') {
        $db->query($upd);
        $msg = _('Mot de passe réinitialisé');
        $retourliste = TRUE;
        // Modification du compte de connexion
        $rech = 'UPDATE `' . TBPW . "` SET `pw_pass`='" . $nouvmdpcrypte . "',`pw_lastip`='" . $log_ip . "'  WHERE `pw_code` = '" . $db->escape($code) . "'";
        $db->query($rech);
    }
    close_database();
    if ($retourliste == TRUE) {
        switch ($categorie) {
            // Envoi de l'email vers le siège
            case 'siege' :
                envoi_mail('', _('Mise à jour mot de passe'), 'cdg', 'mdp', 'xxx', 'cdg', $code, $nouvmdp, '', TRUE);
                break;
            // Envoi de l'email vers l'agence
            case 'age' :
                envoi_mail('', _('Mise à jour mot de passe'), 'age', 'mdp', 'xxx', 'age', $code, $nouvmdp, '', TRUE);
                break;
            // Envoi de l'email vers le technicien
            case 'tec' :
                envoi_mail('', _('Mise à jour mot de passe'), 'tec', 'mdp', 'xxx', 'tec', $code, $nouvmdp, '', TRUE);
                break;
            // Envoi de l'email vers le contact client
            case 'ccli' :
                envoi_mail('', _('Mise à jour mot de passe'), 'ccli', 'mdp', 'xxx', 'ccli', $code, $nouvmdp, '', TRUE);
                break;
            // Envoi de l'email vers le client
            case 'cli' :
                envoi_mail('', _('Mise à jour mot de passe'), 'cli', 'mdp', 'xxx', 'cli', $code, $nouvmdp, '', TRUE);
                break;
            // Envoi de l'email vers l'Opérateur
            case 'ope' :
                envoi_mail('', _('Mise à jour mot de passe'), 'ope', 'mdp', 'xxx', 'ope', $code, $nouvmdp, '', TRUE);
                break;
            // Envoi de l'email vers le donneur d'ordres
            case 'do' :
                envoi_mail('', _('Mise à jour mot de passe'), 'do', 'mdp', 'xxx', 'do', $code, $nouvmdp, '', TRUE);
                break;
            // Envoi de l'email vers le sous-traitant
            case 'st' :
                envoi_mail('', _('Mise à jour mot de passe'), 'st', 'mdp', 'xxx', 'st', $code, $nouvmdp, '', TRUE);
                break;
        }
    }
}


if ((valpost('nbutton') == 'desact') || (valpost('nbutton') == 'react')) {
    $actif = 1;
    if (valpost('nbutton') == 'desact') {
        $actif = 0;
    }
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
    if (($categorie == 'age') || ($categorie == 'tec') || ($categorie == 'ccli') || ($categorie == 'cli') || ($categorie == 'ope') || ($categorie == 'do') || ($categorie == 'st')) {
        // MAJ du compte de connexion
        $rech = 'UPDATE `' . TBPW . "` SET `pw_actif`='" . $actif . "',`pw_lastip`='" . $log_ip . "'  WHERE `pw_code` = '" . $db->escape($code) . "'";
        $db->query($rech);
        if ($actif == 0) {
            $msg = _('Mot de passe désactivé');
        } else {
            $msg = _('Mot de passe réactivé');
        }
        $retourliste = TRUE;
    }
    close_database();
}
?>

<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Mot de passe'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>
<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    pop_ret_auto($msg, 'warn', 'index.php');
} else {
    pop_ret_auto($msg, 'ok', 'index.php');
}

include_once 'pied.php';
?>
</body>
</html>