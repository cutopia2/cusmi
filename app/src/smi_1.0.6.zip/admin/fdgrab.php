<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
$retourliste = FALSE;
if (isset($_GET['name'])) {
    $nom_ficdir = strtolower(trim($_GET['name']));
    if (($nom_ficdir[0] <> '.') && (0 <>= strpos($nom_ficdir, '..'))) // Contrôle de hack
    {
        $td = valget('td');

        $chemin_complet = $url_gfc . '/' . $nom_ficdir;

        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

        switch ($td) {
            case 0 :
                if (is_dir($chemin_complet)) {
                    $rech = 'UPDATE `' . TBFIC . "` SET `fic_codecrea`='" . $admin_code . "'  WHERE `fic_nom` = '" . $chemin_complet . "'";
                    $db->query($rech);
                    $msg = _('Vous êtes le nouveau propriétaire de ce répertoire');
                    $retourliste = TRUE;
                } else {
                    $msg = _("Ce n'est pas un répertoire");
                }
                break;

            case 1 :
                if (is_file($chemin_complet)) {
                    $rech = 'UPDATE `' . TBFIC . "` SET `fic_codecrea`='" . $admin_code . "'  WHERE `fic_nom` = '" . $chemin_complet . "'";
                    $db->query($rech);
                    $msg = _('Vous êtes le nouveau propriétaire de ce fichier');
                    $retourliste = TRUE;
                } else {
                    $msg = _("Ce fichier n'existe pas");
                }
                break;
            default :
                $msg = _('Problème de paramètres');
                break;
        }
        close_database();
    } else {
        $msg = _('Problème de paramètres');
    }
} else {
    $msg = _('Problème de paramètres');
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Appropriation Fichier ou Répertoire'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>


</head>
<body>
<?php
cre_ent_form(_('APPROPRIATION DE REPERTOIRE/FICHIER'), '', '', '', FALSE);
if ($retourliste == TRUE) {
    close_fen_auto('', 'fscomp', 'window.opener');
} else {
    close_fen_auto($msg, 'fscomp', 'window.opener', 5000);
}
?>
</body>
</html>
