<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');

if (count($_POST['codefam']) <> 0) {
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
    for ($i = 0, $iMax = count($_POST['codefam']); $i < $iMax; $i++) {
        $code = str_majuscules($_POST['codefam'][$i]);
        $desc = str_majuscules($_POST['desfam'][$i]);
        $sql2 = 'UPDATE  `' . TBFAM . '` SET';
        $sql2 .= " `fam_code`='" . $db->escape($code) . "',";
        $sql2 .= " `fam_desc`='" . $db->escape($desc) . "'";
        $sql2 .= " WHERE `fam_code`='" . $db->escape($_POST['codefam'][$i]) . "'";
        $db->query($sql2);
    }
    close_database();
}

$msg = _('Importation terminée');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Famille'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <?php if ($pbm_acat == FALSE) { ?>
        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                <?php if (($td=='view') || ($td=='del')) {echo 'readonly_all();';} ?>
                <?php if ($td=='del') {echo "warn_del('');";} ?>
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>
<body>

<?php
include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    pop_ret_auto($msg, 'warn', 'index.php');
} else {
    pop_ret_auto($msg, 'ok', 'index.php');
}
include_once 'pied.php';
?>
</body>
</html>