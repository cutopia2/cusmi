<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_int.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$titre = '';

$td = $_GET['td'];
$coderech = $_GET['code'];
$ic = $_GET['ic'];

$pbm_intc = FALSE;

if ($coderech <> '') {
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
    $rech = 'SELECT * FROM `' . TBINTC . "` WHERE intc_code = '" . $db->escape($coderech) . "'";
    $row = $db->get_row($rech, ARRAY_A);
    if ($row) {
        $row = encode_str($row);
        extract($row);
    } else {
        $pbm_intc = TRUE;
    }
    close_database();
} else {
    if ($td == 'add') {
        $intc_img = $ic;
        $intc_code = '';
        $intc_desc = '';
    } else {
        $pbm_intc = TRUE;
    }
}

switch ($td) {
    case 'add' :
        $titre = _('CREATION CATEGORIE');
        break;
    case 'edit' :
        $titre = _('MISE A JOUR CATEGORIE');
        break;
    case 'del' :
        $titre = _('SUPPRESSION CATEGORIE');
        break;
    default :
        $pbm_intc = TRUE;
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche Catégorie Intervention'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab1_champ = ["nom:image ; format:txt ; req:Y ; txt:<?php echo _('Icône'); ?> ; lmx:200 ; stok:frmok ; stbad:frmbad",
            "nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?> ; lmx:5 ; stok:frmok ; stbad:frmbad",
            <?php
            if (CheckNivLog('5-9')) {
            ?>
            "nom:ccpta ; format:txt ; req:N ; txt:<?php echo _('Code compta'); ?>; lmx:15 ; stok:frmok ; stbad:frmbad",
            <?php
            }
            ?>
            "nom:desc; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?> ; lmx:50 ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_intc == FALSE) { ?>
        <script type="text/javascript">
            <!--
            $(function () {
                $("#code").Setcase({caseValue: 'upper', changeonFocusout: true});
                $("#desc").Setcase({caseValue: 'upper', changeonFocusout: true});
            });

            function init_all() {
                init_Body();
                init_move_sel('addclcg', 'clcg', 'clcgintc');
                init_move_sel('delclcg', 'clcgintc', 'clcg');
                init_select_all('enr', 'clcgintc');
                <?php
                switch ($td)
                {
                    case 'add' :
                        echo "init_valid_form('enr','intc_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'edit' :
                        echo "init_valid_form('enr','intc_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'view' :
                        echo 'readonly_all();';
                        break;
                    case 'del' :
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                }
                ?>
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';

if ($pbm_intc == FALSE) {
    cre_ent_form($titre, 'intc_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="intc_maj" id="intc_maj" method="post" action="intc_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="10%" class="rubfrm" id="f_img" align="right"><?php echo _('Icône'); ?></td>
                <td>
                    <input name="image" type="hidden" id="image" value="<?php echo $intc_img ?>">
                    <?php
                    if (($td == 'add') || ($td == 'edit')) {
                        if ($intc_img <> '') {
                            echo ' <img src="' . $intc_img . '" border="0" align="absmiddle">';
                        } else {
                            echo ' <img src="../img/vide.png" align="absmiddle">';
                            echo ' <a href="icointc_lst.php">' . _('Choisir Icône') . '</a> <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                            echo '<span class="annot_std_it">' . _('(impératif en 1er !)') . '</span>';
                        }
                    } else {
                        echo ' <img src="' . $intc_img . '" border="0" align="absmiddle">';
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td width="10%" class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                <td width="47%">
                    <?php
                    if ($td == 'add') {
                        echo '<input name="code" type="text" id="code" value="' . $intc_code . '" size="5" maxlength="5">';
                        echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                    } else {
                        echo '<input name="code" type="text" id="code" value="' . $intc_code . '" size="5" maxlength="5" readonly="1">';
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td width="10%" class="rubfrm" id="f_desc" align="right"><?php echo _('Libellé'); ?></td>
                <td><input name="desc" type="text" id="desc" value="<?php echo $intc_desc ?>" size="50">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_ccpta" align="right"><?php echo _('Code compta'); ?></td>
                <td>
                    <input name="ccpta" type="text" id="ccpta" value="<?php echo $intc_ccpta; ?>">
                </td>
            </tr>
        </table>

        <?php if ($td == 'edit') { ?>
            <table width="100%" border="0">
                <tr>
                    <td class="rubfrm" colspan="3" align="center">
                        <?php echo _('Choix des groupements de champs pour cette catégorie'); ?>
                        <div class="annot_petit_it">
                            (<?php echo('Si vous ne voulez pas définir de groupement, ne saisissez rien'); ?>)
                        </div>

                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <?php
                        // On crée le tableau des groupement champs check list utilisés
                        $tab_clcg = give_tab_clcg_intc($intc_code);

                        echo '<div class="annot_gras_it">';
                        echo _('Champs à choisir');
                        echo '</div>';
                        echo '<br />';

                        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                        $rech = 'SELECT * FROM `' . TBCLCG . '`';
                        if (count($tab_clcg) > 0) {
                            $rech .= ' WHERE (';
                            foreach ($tab_clcg as $key => $clcg) {
                                if (trim($clcg) <> '') {
                                    $rech .= " clcg_code <> '" . $db->escape($clcg) . "' AND";
                                }
                            }
                            // Suppression du dernier 'AND'
                            $rech = substr($rech, 0, -4);
                            $rech .= ')';
                        }
                        $rech .= ' ORDER BY clcg_desc';
                        $rows = $db->get_results($rech, ARRAY_A);
                        close_database();
                        cre_select_tab('clcg', 'clcg', $rows, 'clcg_code', 'clcg_desc', '', '', '', _('-- Faites votre choix --'), 10, TRUE);

                        ?>
                    </td>
                    <td align="center">
                        <input type="button" id="addclcg" value="<?php echo _('Ajouter'); ?> >>>">
                        <br/>
                        <br/>
                        <input type="button" id="delclcg" value="&lt;&lt;&lt; <?php echo _('Supprimer'); ?>">
                    </td>
                    <td align="center">
                        <?php
                        echo '<div class="annot_gras_it">';
                        echo _('Champs sélectionnés');
                        echo '</div>';
                        echo '<br />';

                        if (count($tab_clcg) > 0) {
                            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                            $rech = 'SELECT * FROM `' . TBCLCG . '`';
                            $rech .= ' WHERE (';
                            foreach ($tab_clcg as $key => $clcg) {
                                if (trim($clcg) <> '') {
                                    $rech .= " clcg_code = '" . $db->escape($clcg) . "' OR";
                                }
                            }
                            // Suppression du dernier 'OR'
                            $rech = substr($rech, 0, -3);
                            $rech .= ')';
                            $rech .= ' ORDER BY clcg_desc';
                            $rows = $db->get_results($rech, ARRAY_A);
                            close_database();
                        } else {
                            $rows = [];
                        }

                        cre_select_tab('clcgintc[]', 'clcgintc', $rows, 'clcg_code', 'clcg_desc', '', '', '', _('-- Faites votre choix --'), 10, TRUE);
                        ?>
                    </td>
                </tr>
            </table>
        <?php } ?>
        <p align="center">
            <?php
            switch ($td) {
                case 'add' :
                case 'edit' :
                    echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Enregistrer') . '">';
                    echo '<input name="RAZ" type="reset" class="bton_std" id="RAZ" value="' . _('Réinitialiser') . '">';
                    break;
                case 'del' :
                    echo '<input name="del" type="submit" class="bton_std" id="del" value="' . _('Supprimer') . '">';
                    break;
            }
            ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'intc_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>