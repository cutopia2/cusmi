<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if (CheckURLLog(FALSE) == FALSE) {
    header('Location: ../index.php');
}
if (CheckNivLog('9') == FALSE) {
    header('Location: ../index.php');
}
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
$pbm_droits = FALSE;
$nu = -1;

if (isset($_GET['nu'])) {
    $nu = (int)trim($_GET['nu']);
    if (trim($tab_niv[$nu]) == '') {
        $pbm_droits = TRUE;
    }
}

$titre = _('AFFECTATION MODELES DE DROIT');

$lst_id_readonly = '';
if ($nu <> -1) {
    $lst_id_readonly = 'nu';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-type=" content="text/html; charset=utf-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Affectation modèles de droits'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab_champ = new Array(
            "nom:nu ; format:liste ; req:Y ; txt:<?php echo _('Niveau utilisateur'); ?> ; vmn:0 ; stok:frmok ; stbad:frmbad");
        //-->
    </script>

    <?php if ($pbm_droits == FALSE) { ?>
        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                <?php
                echo "init_valid_form('enr','droitsa_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                ?>
                readonly_id('<?php echo $lst_id_readonly; ?>', false);
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';
if ($pbm_droits == FALSE) {
    cre_ent_form($titre);
    ?>
    <form name="droitsa_maj" id="droitsa_maj" method="<?php if ($nu == -1) {
        echo 'get';
    } else {
        echo 'post';
    } ?>" action="<?php if ($nu <> -1) {
        echo 'droitsa_enr.php';
    } ?>">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="10%" class="rubfrm" id="f_nu"><?php echo _('Niveau utilisateur'); ?></td>
                <td width="47%">
                    <?php
                    echo '<select name="nu" id="nu">';
                    foreach ($tab_niv_full as $key => $value) {
                        if ((trim($value) <> '') && ((int)$key <> 5) && ((int)$key <> 9)) {
                            echo '<option value="' . $key . '"';
                            if ($nu == (int)$key) {
                                echo ' selected';
                            }
                            echo '>';
                            echo $value . '</option>';
                        }
                    }
                    echo '</select>';
                    echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                    ?>
                </td>
            </tr>
        </table>
        <?php
        // Tableau des utilisateurs
        if ($nu <> -1) {
            $erreur = FALSE;

            echo '<br />';
            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

            // *** Affichage de la table
            echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';
            echo '<th>';
            echo _('Code');
            echo '</th>';
            echo '<th>';
            echo _('Nom');
            echo '</th>';
            echo '<th>';
            echo _('Modèle');
            echo '</th>';


            switch ($nu) {
                // Clients
                case 1 :
                    $rech = 'SELECT cli_code, cli_ste, cli_civilite, cli_prenom, cli_nom, cli_adr1, cli_adr2, cli_ville';
                    $rech .= ' FROM `' . TBCLI . '`';
                    $rech .= ' ORDER BY cli_ste, cli_nom, cli_prenom';
                    break;
                // Opérateurs téléphoniques
                case 2 :
                    $rech = 'SELECT ope_code, ope_civilite, ope_prenom, ope_nom, ope_adr1, ope_adr2, ope_ville';
                    $rech .= ' FROM `' . TBOPE . '`';
                    $rech .= ' ORDER BY ope_nom, ope_prenom';
                    break;
                // Techniciens agences
                case 3 :
                    $rech = 'SELECT tec_code, tec_civilite, tec_prenom, tec_nom, tec_adr1, tec_adr2, tec_ville';
                    $rech .= ' FROM `' . TBTEC . '`';
                    $rech .= " WHERE tec_codeage<>''";
                    $rech .= ' ORDER BY tec_nom, tec_prenom';
                    break;
                // Agences
                case 4 :
                    $rech = 'SELECT age_code, age_nom, age_adr1, age_adr2, age_ville';
                    $rech .= ' FROM `' . TBAGE . '`';
                    $rech .= ' ORDER BY age_nom';
                    break;
                // Donneurs d'ordres
                case 6 :
                    $rech = 'SELECT do_code, do_nom, do_adr1, do_adr2, do_ville';
                    $rech .= ' FROM `' . TBDO . '`';
                    $rech .= ' ORDER BY do_nom';
                    break;
                // Techniciens donneur d'ordres
                case 7 :
                    $rech = 'SELECT tec_code, tec_civilite, tec_prenom, tec_nom, tec_adr1, tec_adr2, tec_ville';
                    $rech .= ' FROM `' . TBTEC . '`';
                    $rech .= " WHERE tec_codedo<>''";
                    $rech .= ' ORDER BY tec_nom, tec_prenom';
                    break;
                // Sous-Traitants
                case 10:
                    $rech = 'SELECT st_code, st_nom, st_adr1, st_adr2, st_ville';
                    $rech .= ' FROM `' . TBST . '`';
                    $rech .= ' ORDER BY st_nom';
                    break;
                // Techniciens Sous-Traitants
                case 11:
                    $rech = 'SELECT tec_code, tec_civilite, tec_prenom, tec_nom, tec_adr1, tec_adr2, tec_ville';
                    $rech .= ' FROM `' . TBTEC . '`';
                    $rech .= " WHERE tec_codest<>''";
                    $rech .= ' ORDER BY tec_nom, tec_prenom';
                    break;
                default :
                    $erreur = TRUE;
                    break;
            }

            if ($erreur == FALSE) {
                $rows = $db->get_results($rech, ARRAY_A);

                if ($rows) {
                    $i = 0;

                    foreach ($rows as $row) {
                        $row = encode_str($row);
                        extract($row);
                        $coderech = '';

                        // Création de l'entête de ligne (TR)
                        echo '<tr>';

                        switch ($nu) {
                            // Clients
                            case 1 :
                                echo '<td align="center">' . $cli_code;
                                echo '<td style="padding-left:10px;">';
                                if ($cli_ste <> '') {
                                    echo $cli_ste . '<br />';
                                } else {
                                    echo $cli_civilite . ' ' . $cli_nom . ' ' . $cli_prenom . '<br />';
                                }
                                echo $cli_adr1 . '<br />';
                                if ($cli_adr2 <> '') {
                                    echo $cli_adr2 . '<br />';
                                }
                                echo Retournecp_Id($cli_ville, FALSE) . ' ' . Retourneville_Id($cli_ville, FALSE);
                                echo '</td>';
                                $coderech = $cli_code;
                                break;
                            // Opérateurs téléphoniques
                            case 2 :
                                echo '<td align="center">' . $ope_code;
                                echo '<td style="padding-left:10px;">';
                                echo $ope_civilite . ' ' . $ope_nom . ' ' . $ope_prenom . '<br />';
                                echo $ope_adr1 . '<br />';
                                if ($ope_adr2 <> '') {
                                    echo $ope_adr2 . '<br />';
                                }
                                echo Retournecp_Id($ope_ville, FALSE) . ' ' . Retourneville_Id($ope_ville, FALSE);
                                echo '</td>';
                                $coderech = $ope_code;
                                break;
                            // Techniciens agences
                            // Techniciens donneur d'ordres
                            // Techniciens Sous-Traitants
                            case 3 :
                            case 7 :
                            case 11:
                                echo '<td align="center">' . $tec_code;
                                echo '<td style="padding-left:10px;">';
                                echo $tec_civilite . ' ' . $tec_nom . ' ' . $tec_prenom . '<br />';
                                echo $tec_adr1 . '<br />';
                                if ($tec_adr2 <> '') {
                                    echo $tec_adr2 . '<br />';
                                }
                                echo Retournecp_Id($tec_ville, FALSE) . ' ' . Retourneville_Id($tec_ville, FALSE);
                                echo '</td>';
                                $coderech = $tec_code;
                                break;
                            // Agences
                            case 4 :
                                echo '<td align="center">' . $age_code;
                                echo '<td style="padding-left:10px;">';
                                echo $age_nom . '<br />';
                                echo $age_adr1 . '<br />';
                                if ($age_adr2 <> '') {
                                    echo $age_adr2 . '<br />';
                                }
                                echo Retournecp_Id($age_ville, FALSE) . ' ' . Retourneville_Id($age_ville, FALSE);
                                echo '</td>';
                                $coderech = $age_code;
                                break;
                            // Donneurs d'ordres
                            case 6 :
                                echo '<td align="center">' . $do_code;
                                echo '<td style="padding-left:10px;">';
                                echo $do_nom . '<br />';
                                echo $do_adr1 . '<br />';
                                if ($do_adr2 <> '') {
                                    echo $do_adr2 . '<br />';
                                }
                                echo Retournecp_Id($do_ville, FALSE) . ' ' . Retourneville_Id($do_ville, FALSE);
                                echo '</td>';
                                $coderech = $do_code;
                                break;
                            // Sous-Traitants
                            case 10:
                                echo '<td align="center">' . $st_code;
                                echo '<td style="padding-left:10px;">';
                                echo $st_nom . '<br />';
                                echo $st_adr1 . '<br />';
                                if ($st_adr2 <> '') {
                                    echo $st_adr2 . '<br />';
                                }
                                echo Retournecp_Id($st_ville, FALSE) . ' ' . Retourneville_Id($st_ville, FALSE);
                                echo '</td>';
                                $coderech = $st_code;
                                break;
                        }
                        echo '<td align="center">';
                        // On récupère le profil de l'utilisateur
                        $rech2 = 'SELECT pw_modele';
                        $rech2 .= ' FROM `' . TBPW . '`';
                        $rech2 .= " WHERE pw_code = '" . $coderech . "'";
                        $pw_modele = $db->get_var($rech2);

                        // On affiche la liste des Modèles
                        $rech3 = 'SELECT droitsm_code, droitsm_des';
                        $rech3 .= ' FROM `' . TBDROITSM . '`';
                        $rech3 .= " WHERE droitsm_nivutil = '" . $nu . "'";
                        $rech3 .= ' ORDER BY droitsm_des';
                        $rows3 = $db->get_results($rech3, ARRAY_A);
                        echo '<input name="modele[]" type="hidden" id="modele[]" value="' . $coderech . '" readonly="readonly">';
                        echo '<select name="codemod_' . $coderech . '" id="codemod_' . $coderech . '">';
                        echo '<option value=""';
                        if (trim($pw_modele) == '') {
                            echo ' selected';
                        }
                        echo '>';
                        echo _('--- Modèle Type ---') . '</option>';
                        foreach ($rows3 as $row3) {
                            $row3 = encode_str($row3);
                            extract($row3);
                            echo '<option value="' . $droitsm_code . '"';
                            if ($droitsm_code == $pw_modele) {
                                echo ' selected';
                            }
                            echo '>';
                            echo $droitsm_des . '</option>';
                        }
                        echo '</td>';

                        echo '</tr>';

                        $i++;
                    }
                }
            }

            echo '</table>';
            // *** Fin affichage de la table

            close_database();
        }
        ?>
        <p align="center">
            <?php
            if ($nu <> -1) {
                echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Enregistrer') . '">';
            } else {
                echo '<input name="valid" type="submit" class="bton_std" id="valid" value="' . _('Valider') . '">';
            }
            ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'index.php');
}
include_once 'pied.php';
?>
</body>
</html>