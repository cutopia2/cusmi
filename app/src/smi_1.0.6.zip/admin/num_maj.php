<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_age.inc.php';
include_once '../inc/fic_cli.inc.php';
include_once '../inc/fic_cocl.inc.php';
include_once '../inc/fic_dde.inc.php';
include_once '../inc/fic_dos.inc.php';
include_once '../inc/fic_loc.inc.php';
include_once '../inc/fic_ope.inc.php';
include_once '../inc/fic_ot.inc.php';
include_once '../inc/fic_rel.inc.php';
include_once '../inc/fic_ret.inc.php';
include_once '../inc/fic_tac.inc.php';
include_once '../inc/fic_tec.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));

// Lecture des paramètres
$row = lit_enr_cons();
if ($row) {
    $row = encode_str($row);
    extract($row);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Préavis & numérotations'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab1_champ = ["nom:relmin ; format:unsigned ; req:Y ; txt:<?php echo _('Minimum pour les préavis'); ?> ; lmx:3 ; stok:frmok ; stbad:frmbad",
            "nom:relmax ; format:unsigned ; req:Y ; txt:<?php echo _('Maximum pour les préavis'); ?> ; lmx:3 ; stok:frmok ; stbad:frmbad",
            "nom:rtec ; format:alphanum ; req:Y ; txt:<?php echo _('Techniciens'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ntec ; format:unsigned ; req:Y ; txt:<?php echo _('Techniciens'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rcli ; format:alphanum ; req:Y ; txt:<?php echo _('Clients'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ncli ; format:unsigned ; req:Y ; txt:<?php echo _('Clients'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rint ; format:alphanum ; req:Y ; txt:<?php echo _('Interventions'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nint ; format:unsigned ; req:Y ; txt:<?php echo _('Interventions'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rope ; format:alphanum ; req:Y ; txt:<?php echo _('Opérateurs téléphoniques'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nope ; format:unsigned ; req:Y ; txt:<?php echo _('Opérateurs téléphoniques'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rcon ; format:alphanum ; req:Y ; txt:<?php echo _('Contrats'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ncon ; format:unsigned ; req:Y ; txt:<?php echo _('Contrats'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rdde ; format:alphanum ; req:Y ; txt:<?php echo _('Demandes'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ndde ; format:unsigned ; req:Y ; txt:<?php echo _('Demandes'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rrel ; format:alphanum ; req:Y ; txt:<?php echo _('Dossiers de Relevés'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nrel ; format:unsigned ; req:Y ; txt:<?php echo _('Dossiers de Relevés'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rrlic ; format:alphanum ; req:Y ; txt:<?php echo _('Relevés de licences'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nrlic ; format:unsigned ; req:Y ; txt:<?php echo _('Relevés de licences'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rrpdt ; format:alphanum ; req:Y ; txt:<?php echo _('Relevés de matériels'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nrpdt ; format:unsigned ; req:Y ; txt:<?php echo _('Relevés de matériels'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rord ; format:alphanum ; req:Y ; txt:<?php echo _('Ordres de travail'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nord ; format:unsigned ; req:Y ; txt:<?php echo _('Ordres de travail'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rretp ; format:alphanum ; req:Y ; txt:<?php echo _('Produit à retourner'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nretp ; format:unsigned ; req:Y ; txt:<?php echo _('Produit à retourner'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rrete ; format:alphanum ; req:Y ; txt:<?php echo _('Envois de retours produits'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nrete ; format:unsigned ; req:Y ; txt:<?php echo _('Envois de retours produits'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rloc ; format:alphanum ; req:Y ; txt:<?php echo _('Contrats de locations'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:nloc ; format:unsigned ; req:Y ; txt:<?php echo _('Contrats de locations'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rdos ; format:alphanum ; req:Y ; txt:<?php echo _('Dossiers de suivi'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ndos ; format:unsigned ; req:Y ; txt:<?php echo _('Dossiers de suivi'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:rtac ; format:alphanum ; req:Y ; txt:<?php echo _('Tâches'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:ntac ; format:unsigned ; req:Y ; txt:<?php echo _('Tâches'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            <?php
            echo "init_valid_form('enr','num_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php
include_once '../inc/entete.inc.php';
cre_ent_form(_('PREAVIS & NUMEROTATIONS'), '', '', '', FALSE);
?>
<form name="num_maj" id="num_maj" method="post" action="num_enr.php">
    <input name="nbutton" type="hidden" id="nbutton" value=''>
    <table width="40%" border="0" cellspacing="0" align="center">
        <tr>
            <td colspan="3">
                <br/>
                <span
                    class="annot_gras_it"><?php echo _('Minimum et le maximum pour les préavis de relance sur les contrats'); ?></span><br/>
                <span
                    class="annot_petit_it"><?php echo _('Minimum = nombre de jours à partir desquels on peut commencer à relancer'); ?>
                    <br/></span>
                <span
                    class="annot_petit_it"><?php echo _('Maximum = nombre de jours à partir desquels on ne peut plus relancer'); ?></span>
                <br/><br/>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_relmin" align="right"><?php echo _('Minimum pour les préavis'); ?></td>
            <td colspan="2">
                <input name="relmin" type="text" id="relmin" value="<?php echo $cons_relmin ?>" size="10">
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_relmax" align="right"><?php echo _('Maximum pour les préavis'); ?></td>
            <td colspan="2">
                <input name="relmax" type="text" id="relmax" value="<?php echo $cons_relmax ?>" size="10">
            </td>
        </tr>
        <tr>
            <td colspan="3">
                <br/><br/>
                <span
                    class="annot_gras_it"><?php echo _('Radical et le numéro pour chaque type de numérotation'); ?></span><br/>
                <span
                    class="annot_petit_it"><?php echo _("(Modification de numéro impossible sur un type s'il y a déjà eu des saisies effectuées sur celui-ci)"); ?></span>
                <br/><br/>
            </td>
        </tr>
        <tr>
            <td align="center" class="annot_gras_it"><?php echo _('Type de numérotation'); ?></td>
            <td align="center" class="annot_gras_it" width="80"><?php echo _('Radical'); ?></td>
            <td align="center" class="annot_gras_it" width="80"><?php echo _('Numéro'); ?></td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_ntec" align="right"><?php echo _('Techniciens'); ?></td>
            <td>
                <input name="rtec" type="text" id="rtec" value="<?php echo $cons_rtec ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_tec('') == 0) {
                    ?>
                    <input name="ntec" type="text" id="ntec" value="<?php echo $cons_ntec ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="ntec" type="text" id="ntec" value="<?php echo $cons_ntec ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" id="f_ncli" align="right"><?php echo _('Clients'); ?></td>
            <td>
                <input name="rcli" type="text" id="rcli" value="<?php echo $cons_rcli ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_cli('') == 0) {
                    ?>
                    <input name="ncli" type="text" id="ncli" value="<?php echo $cons_ncli ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="ncli" type="text" id="ncli" value="<?php echo $cons_ncli ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_nint"><?php echo _('Interventions'); ?></td>
            <td>
                <input name="rint" type="text" id="rint" value="<?php echo $cons_rint ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_int('') == 0) {
                    ?>
                    <input name="nint" type="text" id="nint" value="<?php echo $cons_nint ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="nint" type="text" id="nint" value="<?php echo $cons_nint ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_nope"><?php echo _('Opérateurs téléphoniques'); ?></td>
            <td>
                <input name="rope" type="text" id="rope" value="<?php echo $cons_rope ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_ope() == 0) {
                    ?>
                    <input name="nope" type="text" id="nope" value="<?php echo $cons_nope ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="nope" type="text" id="nope" value="<?php echo $cons_nope ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_ncon"><?php echo _('Contrats'); ?></td>
            <td>
                <input name="rcon" type="text" id="rcon" value="<?php echo $cons_rcon ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_cocl('') == 0) {
                    ?>
                    <input name="ncon" type="text" id="ncon" value="<?php echo $cons_ncon ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="ncon" type="text" id="ncon" value="<?php echo $cons_ncon ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_ncon"><?php echo _('Certificats de destruction'); ?></td>
            <td>
                <input name="rcer" type="text" id="rcer" value="<?php echo $cons_rcer ?>" size="10">
            </td>
            <td><input name="ncer" type="text" id="ncer" value="<?php echo $cons_ncer ?>" size="10"></td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_ndde"><?php echo _('Demandes'); ?></td>
            <td>
                <input name="rdde" type="text" id="rdde" value="<?php echo $cons_rdde ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_dde() == 0) {
                    ?>
                    <input name="ndde" type="text" id="ndde" value="<?php echo $cons_ndde ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="ndde" type="text" id="ndde" value="<?php echo $cons_ndde ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_nrel"><?php echo _('Dossiers de Relevés'); ?></td>
            <td>
                <input name="rrel" type="text" id="rrel" value="<?php echo $cons_rrel ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_rela('') == 0) {
                    ?>
                    <input name="nrel" type="text" id="nrel" value="<?php echo $cons_nrel ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="nrel" type="text" id="nrel" value="<?php echo $cons_nrel ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_nrlic"><?php echo _('Relevés de licences'); ?></td>
            <td>
                <input name="rrlic" type="text" id="rrlic" value="<?php echo $cons_rrlic ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_rlica('') == 0) {
                    ?>
                    <input name="nrlic" type="text" id="nrlic" value="<?php echo $cons_nrlic ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="nrlic" type="text" id="nrlic" value="<?php echo $cons_nrlic ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_nrpdt"><?php echo _('Relevés de matériels'); ?></td>
            <td>
                <input name="rrpdt" type="text" id="rrpdt" value="<?php echo $cons_rrpdt ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_rpdta('') == 0) {
                    ?>
                    <input name="nrpdt" type="text" id="nrpdt" value="<?php echo $cons_nrpdt ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="nrpdt" type="text" id="nrpdt" value="<?php echo $cons_nrpdt ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_nrord"><?php echo _('Ordres de travail'); ?></td>
            <td>
                <input name="rord" type="text" id="rord" value="<?php echo $cons_rord ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_ot('') == 0) {
                    ?>
                    <input name="nord" type="text" id="nord" value="<?php echo $cons_nord ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="nord" type="text" id="nord" value="<?php echo $cons_nord ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_nretp"><?php echo _('Produit à retourner'); ?></td>
            <td>
                <input name="rretp" type="text" id="rretp" value="<?php echo $cons_rretp ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_retp() == 0) {
                    ?>
                    <input name="nretp" type="text" id="nretp" value="<?php echo $cons_nretp ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="nretp" type="text" id="nretp" value="<?php echo $cons_nretp ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_nrete"><?php echo _('Envois de retours produits'); ?></td>
            <td>
                <input name="rrete" type="text" id="rrete" value="<?php echo $cons_rrete ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_rete('') == 0) {
                    ?>
                    <input name="nrete" type="text" id="nrete" value="<?php echo $cons_nrete ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="nrete" type="text" id="nrete" value="<?php echo $cons_nrete ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_nrloc"><?php echo _('Contrats de locations'); ?></td>
            <td>
                <input name="rloc" type="text" id="rloc" value="<?php echo $cons_rloc ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_coloc() == 0) {
                    ?>
                    <input name="nloc" type="text" id="nloc" value="<?php echo $cons_nloc ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="nloc" type="text" id="nloc" value="<?php echo $cons_nloc ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_nrdos"><?php echo _('Dossiers de suivi'); ?></td>
            <td>
                <input name="rdos" type="text" id="rdos" value="<?php echo $cons_rdos ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_dos() == 0) {
                    ?>
                    <input name="ndos" type="text" id="ndos" value="<?php echo $cons_ndos ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="ndos" type="text" id="ndos" value="<?php echo $cons_ndos ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
        <tr>
            <td class="rubfrm" align="right" id="f_nrtac"><?php echo _('Tâches'); ?></td>
            <td>
                <input name="rtac" type="text" id="rtac" value="<?php echo $cons_rtac ?>" size="10">
            </td>
            <td>
                <?php
                if (nb_tac(0, '') == 0) {
                    ?>
                    <input name="ntac" type="text" id="ntac" value="<?php echo $cons_ntac ?>" size="10">
                    <?php
                } else {
                    ?>
                    <input name="ntac" type="text" id="ntac" value="<?php echo $cons_ntac ?>" size="10" readonly>
                    <?php
                }
                ?>
            </td>
        </tr>
    </table>
    <p align="center">
        <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="<?php echo _('Réinitialiser'); ?>">
        <input name="enr" type="button" class="bton_std" id="enr" value="<?php echo _('Enregistrer'); ?>">
    </p>
</form>
<?php
include_once 'pied.php';
?>
</body>
</html>