<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if (CheckURLLog(FALSE) == FALSE) {
    header('Location: ../index.php');
}
if (CheckNivLog('9') == FALSE) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$typmaint = $_GET['td'];

$titre = _('MAINTENANCE MYSQL');

$maintok = FALSE;

if (($typmaint >= 1) && ($typmaint <= 3)) {
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

    // création du tableau des noms de tables
    $tables = [];
    $rech = 'SHOW TABLES FROM `' . DBNAME . '`';
    $rows = $db->get_results($rech, ARRAY_N);
    if ($rows) {
        foreach ($rows as $row) {
            $row = encode_str($row);
            $tables[] = $row[0];
        }
    }

    // Lancement de l'opération
    switch ($typmaint) {
        case 1 :
            $rech = 'CHECK TABLE ';
            break;

        case 2 :
            $rech = 'OPTIMIZE TABLE ';
            break;

        case 3 :
            $rech = 'REPAIR TABLE ';
            break;

        default :
            break;
    }

    foreach ($tables as $value) {
        $rech .= " `$value`,";
    }
    $rech = substr($rech, 0, - 1);
    $rows = $db->get_results($rech, ARRAY_A);

    // création du tableau de résultats
    $tab_result = [];
    if ($rows) {
        foreach ($rows as $row) {
            $row = encode_str($row);
            $tab_result[$row['Table']] = $row['Msg_text'];
        }
    }

    // Validation de la maintenance
    switch ($typmaint) {
        case 1 :
            $msg = _('Vérification effectuée');
            $maintok = TRUE;
            break;

        case 2 :
            $msg = _('Optimisation effectuée');
            $maintok = TRUE;
            break;

        case 3 :
            $msg = _('Réparation effectuée');
            $maintok = TRUE;
            break;

        default :
            $msg = _('Problème de paramètres');
            $maintok = FALSE;
            break;
    }

    close_database();
} else {
    header('Location: ../index.php');
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Maintenance'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            init_autohref('nul', 'click', 'index.php', false);
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>

<body>

<?php
include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
?>
<p align="center">
    <?php if ($retourliste == FALSE) {
        echo '<span class="alerte1">';
    } else {
        echo '<span class="annot_std_gras">';
    }
    echo $msg;
    echo '</span>';
    ?>
</p>

<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">
    <th><?php echo _('Table'); ?></th>
    <th><?php echo _('Résultat'); ?></th>
    <?php
    $i = 0;
    foreach ($tab_result as $key => $value) {
        // Couleurs alternées
        echo '<tr>';
        echo '<td width="75%">' . $key . '</td>';
        echo '<td>' . $value . '</td>';
        echo '</tr>';
        $i++;
    }
    ?>
</table>
<p align="center">
    <input name="nul" type="button" class="bton_std" id="nul" value="<?php echo _('Retour accueil'); ?>">
</p>
<?php
include_once 'pied.php';
?>
</body>
</html>