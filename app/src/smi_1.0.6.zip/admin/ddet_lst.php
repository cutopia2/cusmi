<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
$_SESSION['typ_filtres'] = 'ddet';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Liste Types de demandes'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            init_autohref_classe('falselnkimg', '');
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>

<body>

<?php
include_once '../inc/entete.inc.php';
cre_ent_form(_('TYPE DE DEMANDES'), '', '', '', FALSE);
$fic_imp = '';
$url_add = 'ddet_maj.php?td=add&code=';

$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

$rech = cree_strrechlstddet();
$rech .= crestr_triord($ddet_titre_col, 'ddet_code', FALSE, $limit);

$rows = $db->get_results($rech, ARRAY_A);
close_database();

if ($rows) {
    include_once '../inc/formr.inc.php';

    $numrows = count($rows);
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

    $rech = modstr_triord($rech, $ddet_titre_col, 'ddet_code', TRUE, $limit);

    $rows = $db->get_results($rech, ARRAY_A);

    // *** Pagination de pied
    pagine_lst($numrows, $limit);

    // *** Affichage de la table

    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

    // création entête

    titlst($ddet_titre_col);
    echo '<th>' . _('Cliquer') . '</th>';

    $i = 0;

    foreach ($rows as $row) {
        $row = encode_str($row);
        // création de l'entête de ligne (TR)
        echo '<tr>';

        echo '<td>' . $row['ddet_code'] . '</td>';
        echo '<td>' . $row['ddet_desc'] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['ddet_pub']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['ddet_cli']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['ddet_age']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['ddet_tec']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['ddet_ope']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['ddet_cge']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['ddet_dot']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['ddet_do']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['ddet_stt']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['ddet_st']] . '</td>';

        // CREATION lien dynamique sur icône (édition, suppression, etc...)
        echo '<td align="center">';
        $lst_maj = TRUE;
        cre_falselnk_img('', 'ddet_edit_' . $row['ddet_id'], 'span', 'center', _('Edition'), 'lnk', 'ddet_maj.php?td=edit&code=' . $row['ddet_code'], '../img/edit.png');
        if ($row['ddet_delok'] == TRUE) {
            $lst_del = TRUE;
            cre_falselnk_img('', 'ddet_del_' . $row['ddet_id'], 'span', 'center', _('Suppression'), 'lnk', 'ddet_maj.php?td=del&code=' . $row['ddet_code'], '../img/del.png');
        }
        echo '</td>';

        echo '</tr>';

        $i++;
    }
    echo '</table>';
    // *** Fin affichage de la table

    close_database();

    // *** Pagination de pied
    pagine_lst($numrows, $limit);

    $taille_piedla = '';
    include_once '../inc/piedla.inc.php';
} else {
    retpp();
}

include_once 'pied.php';
?>
