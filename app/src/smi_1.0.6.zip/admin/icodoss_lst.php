<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_fic.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
$_SESSION['typ_filtres'] = 'icodoss';

// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$pbm_ico = FALSE;

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Liste icônes statuts dossiers'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            init_autosubmit('ico', 'change', 'frmico');
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>

<body>

<?php
include_once '../inc/entete.inc.php';

if ($pbm_ico == FALSE) {
    cre_ent_form(_('ICONES'), '', '', '', FALSE);
    ?>
    <p align="center"
       class="annot_gras_it"><?php echo _("Veuillez choisir votre série d'icônes pour la création du statut dossier"); ?></p>
    <form action="icodoss_lst.php" method="get" name="frmico" id="frmico">
        <span class="annot_gras_it"><?php echo _('Série') . ' : '; ?></span>
        <?php
        $tab_ico = [];
        // On scanne le dossier des icônes pour voir lesquelles sont disponibles
        $dir = opendir($chemin_icones);
        while (false !== ($f = readdir($dir))) {
            if (($f <> '.') && ($f <> '..') && ($f != '.htaccess')) {
                $nom = $chemin_icones . '/' . $f;
                if (is_dir($nom)) {
                    $tab_ico[$f] = $f;
                }
            }
        }
        closedir($dir);
        cre_select('ico', 'ico', $tab_ico, valget('ico'), '', _('-- Faites votre choix --'));
        ?>
    </form>
    <br/>
    <br/>
    <?php
}

if (isset($_GET['ico'])) {
    $chemin = $chemin_icones . '/' . $_GET['ico'];
    if (is_dir($chemin)) {
        $dossier = opendir($chemin);
        while (false !== ($Fichier = readdir($dossier))) {
            if ($Fichier != '.' && $Fichier != '..') {
                $ext_fic = strtolower(substr(strrchr($Fichier, '.'), 1));
                if (($ext_fic == 'gif') || ($ext_fic == 'jpg') || ($ext_fic == 'jpeg') || ($ext_fic == 'png')) {
                    $taille = file_imgsize($chemin . '/' . $Fichier);
                    if (is_array($taille)) {
                        $reduc = floor(($hl_vign * 100) / $taille[1]);
                        $l_vign = floor(($taille[0] * $reduc) / 100);
                    }

                    $url_img_mysql = $_GET['ico'] . '/' . $Fichier; // URL stockée dans la base MySQL
                    $url_img = $chemin . '/' . $Fichier; // URL complète vers l'image
                    $url_lien = 'doss_maj.php?td=add&code=&is=' . $url_img; // URL pour affecter au statut

                    // Affichage icônes non utilisées
                    lst_icon_not_used($url_img, $url_lien);
                }
            }
        }
        closedir($dossier);
    } else {
        $pbm_ico = TRUE;
    }
}

if ($pbm_ico == TRUE) {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'ico_lst.php');
}
include_once 'pied.php';
?>
