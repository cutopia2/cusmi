<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_pat.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$td = $_GET['td'];
$coderech = $_GET['code'];

$pbm_rpto = FALSE;

if ($coderech <> '') {
    $row = lit_enr_rto($coderech);
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);
    } else {
        $pbm_rpto = TRUE;
    }
} else {
    if ($td == 'add') {
        $rto_code = '';
        $rto_desc = '';
    } else {
        $pbm_rpto = TRUE;
    }
}

$titre ='';
switch ($td) {
    case 'add' :
        $titre = _('CREATION TYPE OBJET');
        break;
    case 'edit' :
        $titre = _('MODIFICATION TYPE OBJET');
        break;
    case 'del' :
        $titre = _('SUPPRESSION TYPE OBJET');
        break;
    default :
        $pbm_rpto = TRUE;
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Patrimoines - Fiche type objet'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab1_champ = ["nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?> ; lmx:20 ; stok:frmok ; stbad:frmbad",
            "nom:desc; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?> ; lmx:40 ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_rpto == FALSE) { ?>
        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                <?php
                switch ($td)
                {
                    case 'add' :
                        echo "init_valid_form('enr','rpto_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'edit' :
                        echo "init_valid_form('enr','rpto_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        echo "readonly_id('code',false);";
                        break;
                    case 'view' :
                        echo 'readonly_all();';
                        break;
                    case 'del' :
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                }
                ?>
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';

if ($pbm_rpto == FALSE) {
    cre_ent_form($titre, 'rpto_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="rpto_maj" id="rpto_maj" method="post" action="rpto_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td class="rubfrm" id="f_actif" align="right"><?php echo _('Actif'); ?></td>
                <td>
                    <?php
                    cre_select('actif', 'actif', $non_oui, (int)$rto_actif);
                    ?>
                    <br/><span
                        class="annot_petit_it"><?php echo _("Oui' : Ce type d'objet peut être choisi / 'Non' : Il ne le peut pas"); ?></span>
                </td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                <td>
                    <input name="code" type="text" id="code" value="<?php echo $rto_code ?>" size="20" maxlength="20">
                    <?php if ($td == 'add') {
                        echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_desc" align="right"><?php echo _('Libellé'); ?></td>
                <td><input name="desc" type="text" id="desc" value="<?php echo $rto_desc ?>" size="40">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_comp" align="right"><?php echo _('Conteneur'); ?></td>
                <td>
                    <?php
                    cre_select('cont', 'cont', $non_oui, (int)$rto_cont);
                    ?>
                    <br/><span
                        class="annot_petit_it"><?php echo _("Oui' : Ce type peut être conteneur / 'Non' : Il ne le peut pas"); ?></span>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_comp" align="right"><?php echo _('Composant'); ?></td>
                <td>
                    <?php
                    cre_select('comp', 'comp', $non_oui, (int)$rto_comp);
                    ?>
                    <br/><span
                        class="annot_petit_it"><?php echo _("Oui' : Ce type peut être composant / 'Non' : Il ne le peut pas"); ?></span>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_mque" align="right"><?php echo _('Marque'); ?></td>
                <td>
                    <?php
                    cre_select('mque', 'mque', $non_oui, (int)$rto_mque);
                    ?>
                    <br/><span
                        class="annot_petit_it"><?php echo _("Oui' : Il faudra choisir une marque / 'Non' : Il ne le faudra pas"); ?></span>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_ns" align="right"><?php echo _('N° série'); ?></td>
                <td>
                    <?php
                    cre_select('ns', 'ns', $non_oui, (int)$rto_ns);
                    ?>
                    <br/><span
                        class="annot_petit_it"><?php echo _("Oui' : Il faudra choisir un numéro de série / 'Non' : Il ne le faudra pas"); ?></span>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_mob" align="right"><?php echo _('Mobile'); ?></td>
                <td>
                    <?php
                    cre_select('mob', 'mob', $non_oui, (int)$rto_mob);
                    ?>
                    <br/><span
                        class="annot_petit_it"><?php echo _("Oui' : Les objets de ce type sont mobiles / 'Non' : Il ne le sont pas"); ?></span>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_assu" align="right"><?php echo _('Assurance'); ?></td>
                <td>
                    <?php
                    cre_select('assu', 'assu', $non_oui, (int)$rto_assu);
                    ?>
                    <br/><span
                        class="annot_petit_it"><?php echo _("Oui' : Les objets de ce type sont assurés / 'Non' : Il ne le sont pas"); ?></span>
                </td>
            </tr>
        </table>
        <p align="center">
            <?php
            switch ($td) {
                case 'add' :
                case 'edit' :
                    echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Valider') . '">';
                    break;
                case 'del' :
                    echo '<input name="del" type="submit" class="bton_std" id="del" value="' . _('Supprimer') . '">';
                    break;
            }
            echo ' <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="' . _('Réinitialiser') . '">';
            ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'rpto_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>