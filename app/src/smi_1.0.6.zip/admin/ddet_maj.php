<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/fic_dde.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$td = $_GET['td'];
$coderech = $_GET['code'];

$pbm_ddet = FALSE;

if ($coderech <> '') {
    // Récupération des informations type de demande
    $row = lit_enr_ddet($coderech);
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);
    } else {
        $pbm_ddet = TRUE;
    }
} else {
    if ($td <> 'add') {
        $pbm_ddet = TRUE;
    }
}

$titre ='';
switch ($td) {
    case 'add' :
        $titre = _('CREATION TYPE DE DEMANDE');
        break;
    case 'edit' :
        $titre = _('MISE A JOUR TYPE DE DEMANDE');
        break;
    case 'del' :
        $titre = _('SUPPRESSION TYPE DE DEMANDE');
        break;
    default :
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche Type de Demande'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab1_champ = ["nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?> ; lmx:10 ; stok:frmok ; stbad:frmbad",
            "nom:desc ; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?> ; lmx:40 ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_ddet == FALSE) { ?>
        <script type="text/javascript">
            <!--
            $(function () {
                $("#code").Setcase({caseValue: 'upper', changeonFocusout: true});
                $("#desc").Setcase({caseValue: 'upper', changeonFocusout: true});
            });

            function init_all() {
                init_Body();
                <?php
                 switch ($td)
                 {
                    case 'add' :
                        echo "init_valid_form('enr','ddet_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'edit' :
                        echo "init_valid_form('enr','ddet_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'view' :
                        echo 'readonly_all();';
                        break;
                    case 'del' :
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                 }
                 ?>
                init_autohref('annul', 'click', 'index.php', false);
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';

if ($pbm_ddet == FALSE) {
    cre_ent_form($titre, 'ddet_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="ddet_maj" id="ddet_maj" method="post" action="ddet_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="160" class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                <td>
                    <?php if ($td == 'add') { ?>
                        <input name="code" type="text" id="code" value="<?php echo $ddet_code ?>" size="10"
                               maxlength="10">
                        <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                    <?php } else { ?>
                        <input name="code" type="text" id="code" value="<?php echo $ddet_code ?>" size="10"
                               maxlength="10" readonly="1">
                    <?php } ?>
                </td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_desc" align="right"><?php echo _('Libellé'); ?></td>
                <td>
                    <input name="desc" type="text" id="desc" value="<?php echo $ddet_desc ?>" size="40">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                </td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_pub" align="right"><?php echo _('Accessible publiquement'); ?></td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('pub', 'pub', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('pub', 'pub', $non_oui, (int)$ddet_pub);
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_cli" align="right"><?php echo _('Accessible par les clients'); ?>
                    *
                </td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('client', 'client', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('client', 'client', $non_oui, (int)$ddet_cli);
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_age" align="right"><?php echo _('Accessible par les agences'); ?>
                    *
                </td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('age', 'age', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('age', 'age', $non_oui, (int)$ddet_age);
                    }
                    ?>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_tec"
                    align="right"><?php echo _('Accessible par les techniciens'); ?>*
                </td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('tec', 'tec', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('tec', 'tec', $non_oui, (int)$ddet_tec);
                    }
                    ?>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_ope"
                    align="right"><?php echo _('Accessible par les opérateurs'); ?>*
                </td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('ope', 'ope', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('ope', 'ope', $non_oui, (int)$ddet_ope);
                    }
                    ?>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_cge" align="right"><?php echo _('Accessible par le siège'); ?>*
                </td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('cge', 'cge', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('cge', 'cge', $non_oui, (int)$ddet_cge);
                    }
                    ?>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_stt"
                    align="right"><?php echo _('Accessible par les techniciens sous-traitants'); ?>*
                </td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('stt', 'stt', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('stt', 'stt', $non_oui, (int)$ddet_stt);
                    }
                    ?>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_st"
                    align="right"><?php echo _('Accessible par les sous-traitants'); ?>*
                </td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('st', 'st', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('st', 'st', $non_oui, (int)$ddet_st);
                    }
                    ?>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_dot"
                    align="right"><?php echo _("Accessible par les techniciens donneurs d'ordres"); ?>*
                </td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('dot', 'dot', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('dot', 'dot', $non_oui, (int)$ddet_dot);
                    }
                    ?>
            </tr>
            <tr>
                <td width="160" class="rubfrm" id="f_do"
                    align="right"><?php echo _("Accessible par les donneurs d'ordres"); ?>*
                </td>
                <td>
                    <?php
                    if ($td == 'add') {
                        cre_select('do', 'do', $non_oui, 0);
                    }

                    if (($td == 'edit') || ($td == 'del')) {
                        cre_select('do', 'do', $non_oui, (int)$ddet_do);
                    }
                    ?>
            </tr>
        </table>
        <span class="annot_petit_it">* <?php echo _("Par l'espace privé"); ?></span><br/>

        <p align="center">
            <?php if (($td == 'add') || ($td == 'edit')) { ?>
                <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="<?php echo _('Réinitialiser'); ?>">
                <input name="enr" type="button" class="bton_std" id="enr" value="<?php echo _('Enregistrer'); ?>">
            <?php } ?>
            <?php if ($td == 'del') { ?>
                <input name="del" type="submit" class="bton_std" id="del" value="<?php echo _('Supprimer'); ?>">
                <input name="annul" type="button" class="bton_std" id="annul" value="<?php echo _('Annuler'); ?>">
            <?php } ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'ddet_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>