<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_droits.inc.php';
include_once '../inc/fic_fici.inc.php';
include_once '../inc/fic_pw.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
$_SESSION['typ_filtres'] = 'do';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _("Liste Donneurs d'Ordres"); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            init_autohref_classe('falselnkimg', '');
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>

<body>

<?php
include_once '../inc/entete.inc.php';
cre_ent_form(_("DONNEURS D'ORDRES"), '', '', '', FALSE);
$fic_imp = 'do_lsti.php';
$url_add = 'do_maj.php?td=add&code=';

$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

$rech = cree_strrechlstdo();
$rech .= crestr_triord($do_titre_col, 'do_code', FALSE, $limit);

$rows = $db->get_results($rech, ARRAY_A);
close_database();

if ($rows) {
    include_once '../inc/formr.inc.php';

    $numrows = count($rows);
    $rech = modstr_triord($rech, $do_titre_col, 'do_code', TRUE, $limit);

    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

    $rows = $db->get_results($rech, ARRAY_A);

    // *** Pagination de pied
    pagine_lst($numrows, $limit);

    // *** Affichage de la table

    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

    // création entête
    titlst($do_titre_col);
    echo '<th>' . _('Cliquer') . '</th>';

    $i = 0;

    foreach ($rows as $row) {
        $row = encode_str($row);
        // création de l'entête de ligne (TR)
        echo '<tr>';

        echo '<td>' . $row['do_code'];

        // traçabilité
        if (CheckNivLog('5-9')) {
            $url_detdo = 'tra_lst.php?tx=r&tl=d&cr=' . $row['do_code'];
            if (url_ok($url_detdo, FALSE) == TRUE) {
                cre_falselnk_img('', 'do_tra_' . $row['do_id'], 'span', 'center', _('Traçabilité'), 'lnkpop', 'tra_lst.php?tx=r&tl=d&cr=' . $row['do_code'], '../img/trace.gif', 800, 500);
            }
        }

        // CREATION d'icône si manque logo
        $txtalert = '';
        if (exist_logo($row['do_code']) == FALSE) {
            $txtalert = _('Manque un logo');
        }
        if (trim($txtalert) <> '') {
            echo ' <a href="#" class="popw"><img src="../img/warn.png" alt="' . _('pbm') . '" border="0" align="absmiddle"><span>' . formatetxtbr($txtalert) . '</span></a>';
        }

        // CREATION d'icône si le donneur d'ordres est fermé
        if ($row['do_ouvert'] == FALSE) {
            $lst_ferm = TRUE;
            echo ' <img src="../img/out.png" title ="' . _('Est fermé depuis le') . ' ' . datetolocal($row['do_datec']) . '" border="0" align="absmiddle">';
        }

        // Verrouillé ?
        if (account_locked($row['do_code'], FALSE) == TRUE) {
            echo ' <img src="../img/locked.png" title="' . _('Compte désactivé') . '" alt="' . _('Compte désactivé') . '" border="0" align="absmiddle">';
            $locked = TRUE;
        }

        echo '</td>';
        echo '<td>';
        echo $row['do_nom'];
        echo '</td>';
        echo '<td>' . $row['do_telf'] . '</td>';
        echo '<td>' . Retournecp_Id($row['do_ville'], FALSE) . '</td>';
        echo '<td>' . Retournepays($row['do_codepays'], FALSE) . '</td>';

        // CREATION lien dynamique sur email
        echo '<td>';
        echo ' <a href="mailto:' . $row['do_email'] . '">' . $row['do_email'] . '</a>';
        echo '</td>';

        // CREATION lien dynamique sur icône (édition, suppression, etc...)

        echo '<td align="center">';
        if ($row['do_ouvert'] == TRUE) {
            $lst_maj = TRUE;
            cre_falselnk_img('', 'do_edit_' . $row['do_id'], 'span', 'center', _('Edition'), 'lnk', 'do_maj.php?td=edit&code=' . $row['do_code'] . '&dep=' . $row['do_dep'], '../img/edit.png');
            $lst_del = TRUE;
            cre_falselnk_img('', 'do_del_' . $row['do_id'], 'span', 'center', _('Suppression'), 'lnk', 'do_maj.php?td=del&code=' . $row['do_code'] . '&dep=' . $row['do_dep'], '../img/del.png');
        } else {
            $lst_del = TRUE;
            cre_falselnk_img('', 'do_view_' . $row['do_id'], 'span', 'center', _('Visualisation'), 'lnk', 'do_maj.php?td=view&code=' . $row['do_code'] . '&dep=' . $row['do_dep'], '../img/eye.png');
        }
        $lst_imp = TRUE;
        cre_falselnk_img('', 'do_prn_' . $row['do_id'], 'span', 'center', _('Impression'), 'lnkpop', 'do_maji.php?cd=' . $row['do_code'], '../img/print.png');
        echo '</td>';

        echo '</tr>';

        $i++;
    }
    echo '</table>';
    // *** Fin affichage de la table

    close_database();

    if ($locked == TRUE) {
        echo ' <img src="../img/locked.png" title="' . _('Compte désactivé') . '" alt="' . _('Compte désactivé') . '" border="0" align="absmiddle">';
        echo ' : ' . _('Compte désactivé');
    }

    // *** Pagination de pied
    pagine_lst($numrows, $limit);

    $taille_piedla = '';
    include_once '../inc/piedla.inc.php';
} else {
    retpp();
}

include_once 'pied.php';
?>
