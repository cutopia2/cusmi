<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_age.inc.php';
include_once '../inc/fic_hum.inc.php';
include_once '../inc/fic_cli.inc.php';
include_once '../inc/fic_do.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/fic_mque.inc.php';
include_once '../inc/fic_st.inc.php';
include_once '../inc/fic_rel.inc.php';
include_once '../inc/fic_tec.inc.php';
include_once '../inc/fic_txt.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_fic.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_mail.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/func_txtcm.inc.php';
include_once '../classes/phpmailer/class.phpmailer.php';
include_once '../classes/phpmailer/class.smtp.php';
include_once '../inc/mail.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$actif = (int)valpost('actif');
$code = str_majuscules(valpost('code'));
$desc = str_majuscules(valpost('desc'));
$coderto = str_majuscules(valpost('coderto'));
$coderpet = str_majuscules(valpost('coderpet'));
$codemque = str_majuscules(valpost('codemque'));
$ns = valpost('ns');
$numinv = valpost('numinv');
$datefab = datetomysql(valpost('datefabf'));
$dateach = datetomysql(valpost('dateachf'));
$coderta = str_majuscules(valpost('coderta'));

$datesortie = '0000-00-00';
$detailsortie = '';
if ($td <> 'add') {
    $datesortie = datetomysql(valpost('datesortief'));
    $detailsortie = valpost('detailsortie');
}

$pa = (float)valpost('pa');
$vr = (float)valpost('vr');

$codegest = '';
$codeprop = '';

$notes = valpost('notes');
$esc = '';
$et = '';
$bat = '';
$pays = '';
$adr1 = '';
$adr2 = '';
$dep = '';
$ville = '';
$surf = 0;
$cg = '';
$km= 0;
$immat = '';

// Si objet immobile
$tomob = (int)valpost('tomob');
if ($tomob == 0) {
    $adr1 = str_majuscules(valpost('adr1'));
    $adr2 = str_majuscules(valpost('adr2'));
    $pays = str_majuscules(valpost('pays'));
    $dep = str_majuscules(valpost('dep'));
    $ville = str_majuscules(valpost('ville'));
    $bat = valpost('bat');
    $ent = valpost('ent');
    $esc = valpost('esc');
    $et = valpost('et');
    $surf = (float)valpost('surf');
} else {
    // Si objet mobile
    $immat = valpost('immat');
    $cg = valpost('cg');
    $km = (float)valpost('km');
}

// Si objet assuré
$rassurcodemque = '';
$rassurnumco = '';
$rassurcotis = 0;
$rassurva = 0;
$rassurdateech = '0000-00-00';

$toassu = (int)valpost('toassu');
if ($toassu == 1) {
    $rassurcodemque = str_majuscules(valpost('rassurcodemque'));
    $rassurnumco = valpost('rassurnumco');
    $rassurcotis = (float)valpost('rassurcotis');
    $rassurva = (float)valpost('rassurva');
    $rassurdateech = datetomysql(valpost('rassurdateechf'));
}

$codeuser = valsession('code_log');

$msg = '';
$retourliste = TRUE;

switch ($td) {
    // Ajout de la fiche objet
    case 'add' :
        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
        $rech = 'SELECT COUNT(*) FROM `' . TBROBJ . "` WHERE `robj_code` = '" . $db->escape($code) . "'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $rech = 'INSERT INTO `' . TBROBJ . '`';
            $rech .= ' (robj_datecrea,robj_codecrea,robj_datemod,robj_codemod,robj_code,robj_desc,robj_codemque,robj_ns,';
            $rech .= 'robj_actif,robj_coderto,robj_coderpet,robj_numinv,robj_dateach,robj_coderta,robj_datefab,robj_codegest,robj_codeprop,robj_pa,robj_vr,robj_notes)';
            $rech .= ' VALUES';
            $rech .= " ('$datea','$codeuser','$datea','$codeuser','$code','" . $db->escape($desc) . "','$codemque','" . $db->escape($ns) . "','$actif','$coderto','$coderpet',";
            $rech .= "'" . $db->escape($numinv) . "','$dateach','$coderta','$datefab','$codegest','$codeprop','$pa','$vr','" . $db->escape($notes) . "')";
            $db->query($rech);
            $last_id = $db->insert_id;

            // Objet mobile ou Immobile
            if ($tomob == 0) {
                $rech = 'INSERT INTO `' . TBRIMMOB . '`';
                $rech .= ' (rimmob_idrobj,rimmob_adr1,rimmob_adr2,rimmob_dep,rimmob_ville,rimmob_codepays,rimmob_bat,rimmob_ent,rimmob_esc,rimmob_et,rimmob_surf)';
                $rech .= ' VALUES';
                $rech .= " ('$last_id','" . $db->escape($adr1) . "','" . $db->escape($adr2) . "','$dep','$ville','$pays','" . $db->escape($bat) . "','" . $db->escape($ent) . "','" . $db->escape($esc) . "',";
                $rech .= " '" . $db->escape($et) . "','$surf')";
                $db->query($rech);
            } else {
                $rech = 'INSERT INTO `' . TBRMOB . '`';
                $rech .= ' (rmob_idrobj,rmob_immat,rmob_cg,rmob_km)';
                $rech .= ' VALUES';
                $rech .= " ('$last_id','" . $db->escape($immat) . "','" . $db->escape($cg) . "','$km')";
                $db->query($rech);
            }

            // Objet assuré
            if ($toassu == 1) {
                $rech = 'INSERT INTO `' . TBRASSUR . '`';
                $rech .= ' (rassur_idrobj,rassur_codemque,rassur_numco,rassur_cotis,rassur_va,rassur_dateech)';
                $rech .= ' VALUES';
                $rech .= " ('$last_id','$rassurcodemque','" . $db->escape($rassurnumco) . "','$rassurcotis','$rassurva','$rassurdateech')";
                $db->query($rech);
            }

            $msg = _('Fiche ajoutée');
        } else {
            $msg = _('Ce code existe déjà');
            $retourliste = FALSE;
        }
        close_database();
        break;

    // MAJ de la fiche objet
    case 'edit' :
        $ok_maj = TRUE;

        /*************************** FAIRE CONTROLE SUR SORTIE OU DESACTIVATION DE L'OBJET **********************/


        if ($ok_maj == TRUE) {
            // MAJ de la fiche objet
            $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
            $rech = 'UPDATE `' . TBROBJ;
            $rech .= "` SET `robj_datemod`='" . $datea . "', `robj_codemod`='" . $codeuser . "', `robj_code`='" . $code . "', `robj_desc`='" . $db->escape($desc) . "',";
            $rech .= " `robj_codemque`='" . $codemque . "', `robj_ns`='" . $db->escape($ns) . "', `robj_actif`='" . $actif . "', `robj_coderto`='" . $coderto . "',";
            $rech .= " `robj_coderpet`='" . $coderpet . "',`robj_numinv`='" . $db->escape($numinv) . "', `robj_dateach`='" . $dateach . "', `robj_coderta`='" . $coderta . "',";
            $rech .= " `robj_datefab`='" . $datefab . "', `robj_codegest`='" . $codegest . "', `robj_codeprop`='" . $codeprop . "',`robj_pa`='" . $pa . "',";
            $rech .= " `robj_vr`='" . $vr . "', `robj_notes`='" . $db->escape($notes) . "'";
            $rech .= " WHERE `robj_code` = '" . $db->escape($code) . "'";
            $db->query($rech);


            // Récupération ID objet
            $robj_id = 0;
            $rech2 = 'SELECT robj_id FROM `' . TBROBJ . "` WHERE `robj_code` = '" . $db->escape($code) . "'";
            $row2 = $db->get_row($rech2, ARRAY_A);

            if ($row2) {
                extract($row2);
            }

            if ($robj_id <> 0) {
                // Objet mobile ou Immobile
                if ($tomob == 0) {
                    // Objet immobile : on supprime les éventuels enregistrements rattachés en tant qu'objet mobile
                    $rech2 = 'DELETE FROM `' . TBRMOB . "`  WHERE rmob_idrobj = '" . $robj_id . "'";
                    $db->query($rech2);

                    // On vérifie si enregistrement déjà créé pour objet immobile
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBRIMMOB . "` WHERE `rimmob_idrobj` = '" . $robj_id . "'";
                    $nb_rs = $db->get_var($rech2);
                    if ($nb_rs == 1) { // Existe
                        $rech = 'UPDATE `' . TBRIMMOB;
                        $rech .= "` SET `rimmob_adr1`='" . $db->escape($adr1) . "', `rimmob_adr2`='" . $db->escape($adr2) . "', `rimmob_dep`='" . $dep . "',";
                        $rech .= " `rimmob_ville`='" . $ville . "', `rimmob_codepays`='" . $pays . "',";
                        $rech .= " `rimmob_bat`='" . $db->escape($bat) . "',`rimmob_ent`='" . $db->escape($ent) . "', `rimmob_esc`='" . $db->escape($esc) . "',";
                        $rech .= " `rimmob_et`='" . $db->escape($et) . "', `rimmob_surf`='" . $surf . "'";
                        $rech .= " WHERE `rimmob_idrobj` = '" . $robj_id . "'";
                        $db->query($rech);
                    } else { // N'existe pas
                        $rech = 'INSERT INTO `' . TBRIMMOB . '`';
                        $rech .= ' (rimmob_idrobj,rimmob_adr1,rimmob_adr2,rimmob_dep,rimmob_ville,rimmob_codepays,rimmob_bat,rimmob_ent,rimmob_esc,rimmob_et,rimmob_surf)';
                        $rech .= ' VALUES';
                        $rech .= " ('$robj_id','" . $db->escape($adr1) . "','" . $db->escape($adr2) . "','$dep','$ville','$pays','" . $db->escape($bat) . "','" . $db->escape($ent) . "','" . $db->escape($esc) . "',";
                        $rech .= " '" . $db->escape($et) . "','$surf')";
                        $db->query($rech);
                    }
                } else {
                    // Objet mobile : on supprime les éventuels enregistrements rattachés en tant qu'objet immobile
                    $rech2 = 'DELETE FROM `' . TBRIMMOB . "`  WHERE rimmob_idrobj = '" . $robj_id . "'";
                    $db->query($rech2);

                    // On vérifie si enregistrement déjà créé pour objet immobile
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBRMOB . "` WHERE `rmob_idrobj` = '" . $robj_id . "'";
                    $nb_rs = $db->get_var($rech2);

                    if ($nb_rs == 1) { // Existe
                        $rech = 'UPDATE `' . TBRMOB;
                        $rech .= "` SET `rmob_immat`='" . $db->escape($immat) . "', `rmob_cg`='" . $db->escape($cg) . "', `rmob_km`='" . $km . "'";
                        $rech .= " WHERE `rmob_idrobj` = '" . $robj_id . "'";
                        $db->query($rech);
                    } else { // N'existe pas
                        $rech = 'INSERT INTO `' . TBRMOB . '`';
                        $rech .= ' (rmob_idrobj,rmob_immat,rmob_cg,rmob_km)';
                        $rech .= ' VALUES';
                        $rech .= " ('$robj_id','" . $db->escape($immat) . "','" . $db->escape($cg) . "','$km')";
                        $db->query($rech);
                    }
                }

                // Objet Assuré
                if ($toassu == 0) {
                    // Objet non assuré : on supprime les éventuels enregistrements rattachés en tant qu'objet assuré
                    $rech2 = 'DELETE FROM `' . TBRASSUR . "`  WHERE rassur_idrobj = '" . $robj_id . "'";
                    $db->query($rech2);
                } else {
                    // On vérifie si enregistrement déjà créé pour objet immobile
                    $rech2 = 'SELECT COUNT(*) FROM `' . TBRASSUR . "` WHERE `rassur_idrobj` = '" . $robj_id . "'";
                    $nb_rs = $db->get_var($rech2);

                    if ($nb_rs == 1) { // Existe
                        $rech = 'UPDATE `' . TBRASSUR;
                        $rech .= "` SET `rassur_codemque`='" . $rassurcodemque . "', `rassur_numco`='" . $db->escape($rassurnumco) . "', ";
                        $rech .= " `rassur_cotis`='" . $rassurcotis . "',";
                        $rech .= " `rassur_va`='" . $rassurva . "', `rassur_dateech`='" . $rassurdateech . "'";
                        $rech .= " WHERE `rassur_idrobj` = '" . $robj_id . "'";
                        $db->query($rech);
                    } else { // N'existe pas
                        $rech = 'INSERT INTO `' . TBRASSUR . '`';
                        $rech .= ' (rassur_idrobj,rassur_codemque,rassur_numco,rassur_cotis,rassur_va,rassur_dateech)';
                        $rech .= ' VALUES';
                        $rech .= " ('$robj_id','$rassurcodemque','" . $db->escape($rassurnumco) . "','$rassurcotis','$rassurva','$rassurdateech')";
                        $db->query($rech);
                    }
                }

                // Mise à jour de la nomenclature

                /*
                print_r($_SESSION['obj_idnomenc_enfants']);
                echo '<br />';
                */

                if (count($_SESSION['obj_idnomenc_enfants']) > 0) {
                    foreach ($_SESSION['obj_idnomenc_enfants'] as $value) {
                        // On ajoute uniquement si n'existe pas déjà
                        $rech = '';
                        $rech2 = 'SELECT COUNT(*) FROM `' . TBRNOMENC . "` WHERE `rnomenc_idrobj_enfant` = '" . (int)$value . "'";
                        $nb_res = $db->get_var($rech2);
                        if ($nb_res == 0) {
                            $rech = 'INSERT INTO `' . TBRNOMENC . '`';
                            $rech .= ' (rnomenc_idrobj_parent,rnomenc_idrobj_enfant) VALUES';
                            $rech .= " ('$robj_id','$value')";
                        }
                        if ($rech <> '') {
                            $db->query($rech);
                        }
                    }

                    reset($_SESSION['obj_idnomenc_enfants']);
                    $rech = '';

                    $rech = 'DELETE FROM `' . TBRNOMENC . '`';
                    $rech .= ' WHERE ';
                    // Suppression anciennes sélections
                    foreach ($_SESSION['obj_idnomenc_enfants'] as $value) {
                        $rech .= " rnomenc_idrobj_enfant <> '" . $value . "' AND";
                    }
                    // Suppression du dernier 'AND'
                    $rech = substr($rech, 0, -4);

                    $rech .= " AND rnomenc_idrobj_parent = '" . $robj_id . "'";

                    $db->query($rech);
                }
            }
            close_database();

            $msg = _('Fiche modifiée');
        }
        break;

    // Suppression de la fiche relevé matériel
    case 'del' :

        /*************************** FAIRE CONTROLE SUR SUPPRESSION DE L'OBJET **********************/

        $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

        // Récupération ID objet
        $robj_id = 0;
        $rech2 = 'SELECT robj_id FROM `' . TBROBJ . "` WHERE `robj_code` = '" . $db->escape($code) . "'";
        $row2 = $db->get_row($rech2, ARRAY_A);
        if ($row2) {
            extract($row2);
        }

        if ($robj_id <> 0) {
            // Objet immobile : on supprime les éventuels enregistrements rattachés en tant qu'objet mobile
            $rech2 = 'DELETE FROM `' . TBRMOB . "`  WHERE rmob_idrobj = '" . $robj_id . "'";
            $db->query($rech2);

            // Objet mobile : on supprime les éventuels enregistrements rattachés en tant qu'objet immobile
            $rech2 = 'DELETE FROM `' . TBRIMMOB . "`  WHERE rimmob_idrobj = '" . $robj_id . "'";
            $db->query($rech2);

            // On vérifie si enregistrement déjà créé pour objet immobile
            $rech2 = 'SELECT COUNT(*) FROM `' . TBRASSUR . "` WHERE `rassur_idrobj` = '" . $robj_id . "'";
            $nb_rs = $db->get_var($rech2);
        }

        // SUPPRESSION de la fiche objet
        $rech = 'DELETE FROM `' . TBROBJ . "` WHERE `robj_code` = '" . $db->escape($code) . "'";
        $db->query($rech);
        close_database();
        $msg = _('Fiche supprimée');

        break;

    default :
        break;
}
?>
    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
    <html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Patrimoines - Fiche objet'); ?></title>

        <?php include_once '../inc/header.inc.php'; ?>

        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    </head>
    <body>
<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    exec_func_js("warn_txt('" . str_escape($msg) . "')");
    aff_ret_idx_man($td, 'robj_maj.php?td=edit&code=' . $code, _('Retour à la saisie'), FALSE);
} else {
    pop_ret_auto($msg, 'ok', 'robj_lst.php');
}
include_once 'pied.php';
?>