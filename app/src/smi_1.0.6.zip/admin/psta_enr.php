<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$titre = valpost('titre');
$td = valpost('td');

$code = str_majuscules(valpost('code'));
$desc = str_majuscules(valpost('desc'));
$img = valpost('image');

$retourliste = TRUE;
$msg = '';

$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
switch ($td) {
    // Ajout de la fiche Statut
    case 'add' :
        $rech = 'SELECT COUNT(*) FROM `' . TBPSTA . "` WHERE psta_code = '" . $db->escape($code) . "'";
        $nb_rs = $db->get_var($rech);
        if ($nb_rs == 0) {
            $rech = 'INSERT INTO `' . TBPSTA . "`(psta_code,psta_desc,psta_img,psta_delok) VALUES ('" . $db->escape($code) . "','" . $db->escape($desc) . "','$img','1')";
            $db->query($rech);
            $msg = _('Fiche ajoutée');
        } else {
            $msg = _('Ce code existe déjà');
            $retourliste = FALSE;
        }
        break;

    // Modification de la fiche Statut
    case 'edit' :
        $rech = 'UPDATE `' . TBPSTA . "` SET `psta_desc`='" . $db->escape($desc) . "' WHERE `psta_code` = '" . $db->escape($code) . "'";
        $db->query($rech);
        $msg = _('Fiche modifiée');
        break;

    // Suppression de la fiche Statut
    case 'del' :
        $delok = TRUE;
        if ($delok == TRUE) {
            // Vérifie si on peut supprimer ce psta
            $rech = 'SELECT COUNT(*) FROM `' . TBPSTA . "` WHERE `psta_code` = '" . $db->escape($code) . "' AND `psta_delok` = '1'";
            $nb_rs = $db->get_var($rech);
            if ($nb_rs <> 0) {
                // SUPPRESSION de la fiche psta
                $rech = 'DELETE FROM `' . TBPSTA . "` WHERE `psta_code` = '" . $db->escape($code) . "'";
                $db->query($rech);
                $msg = _('Fiche supprimée');
            } else {
                $msg = _('Suppression impossible');
                $retourliste = FALSE;
            }
        }
        break;

    default :
        $msg = _('Problème de paramètres');
        $retourliste = FALSE;
        break;
}
close_database();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche statut évènements'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form($titre, '', '', '', FALSE);
if ($retourliste == FALSE) {
    exec_func_js("warn_txt('" . str_escape($msg) . "')");
    aff_ret_idx_man($td, 'psta_lst.php', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'psta_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>