<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_mque.inc.php';
include_once '../inc/fic_rel.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$td = $_GET['td'];
$coderech = $_GET['code'];

$pbm_rltl = FALSE;

if ($coderech <> '') {
    $row = lit_enr_rltl($coderech);
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);
    } else {
        $pbm_rltl = TRUE;
    }
} else {
    if ($td == 'add') {
        $rltl_code = '';
        $rltl_desc = '';
    } else {
        $pbm_rltl = TRUE;
    }
}
$titre ='';
switch ($td) {
    case 'add' :
        $titre = _('CREATION TYPE LICENCE');
        break;
    case 'edit' :
        $titre = _('MODIFICATION TYPE LICENCE');
        break;
    case 'del' :
        $titre = _('SUPPRESSION TYPE LICENCE');
        break;
    default :
        $pbm_rltl = TRUE;
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Relevés - Fiche type licence'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab1_champ = ["nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?> ; lmx:20 ; stok:frmok ; stbad:frmbad",
            "nom:desc; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?> ; lmx:40 ; stok:frmok ; stbad:frmbad",
            "nom:codema; format:liste ; req:Y ; txt:<?php echo _('Editeur'); ?> ; vmn:1 ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_rltl == FALSE) { ?>
        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                <?php
                 switch ($td)
                 {
                    case 'add':
                        echo "init_valid_form('enr','rltl_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'edit':
                        echo "readonly_id('code',false);";
                        echo "init_valid_form('enr','rltl_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'del':
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                    case 'view':
                        echo 'readonly_all();';
                        break;

                 }
                ?>
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';

if ($pbm_rltl == FALSE) {
    cre_ent_form($titre, 'rltl_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="rltl_maj" id="rltl_maj" method="post" action="rltl_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="10%" class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                <td width="47%">
                    <input name="code" type="text" id="code" value="<?php echo $rltl_code ?>" size="20" maxlength="20">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_desc" align="right"><?php echo _('Libellé'); ?></td>
                <td><input name="desc" type="text" id="desc" value="<?php echo $rltl_desc ?>" size="40">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_codema" align="right"><?php echo _('Editeur'); ?></span></td>
                <td>
                    <?php
                    $tab_first_options = [];
                    $tab_first_options ['*'] = _('Toutes les marques');
                    $tab_mque = give_tab_marques('rlic');
                    cre_select_tab('codema', 'codema', $tab_mque, 'mque_code', 'mque_ste', '', $rltl_codema, '', _('-- Faites votre choix --'), 1, FALSE, '', _('-- Inconnu --'), TRUE, TRUE, FALSE, $tab_first_options);
                    ?>
                </td>
            </tr>
        </table>
        <p align="center">
            <?php if (($td == 'add') || ($td == 'edit')) { ?>
                <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="<?php echo _('Réinitialiser'); ?>">
                <input name="enr" type="button" class="bton_std" id="enr" value="<?php echo _('Enregistrer'); ?>">
            <?php } ?>
            <?php if ($td == 'del') { ?>
                <input name="del" type="submit" class="bton_std" id="del" value="<?php echo _('Supprimer'); ?>">
            <?php } ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'rltl_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>