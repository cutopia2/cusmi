<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if (CheckURLLog(FALSE) == FALSE) {
    header('Location: ../index.php');
}
if (CheckNivLog('9') == FALSE) {
    header('Location: ../index.php');
}
include_once '../inc/fic_age.inc.php';
include_once '../inc/fic_cli.inc.php';
include_once '../inc/fic_do.inc.php';
include_once '../inc/fic_ope.inc.php';
include_once '../inc/fic_st.inc.php';
include_once '../inc/fic_tec.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
$categorie = $_GET['cat'];
$pbm_cat = FALSE;
$retouridx = FALSE;

$titre = '';
switch ($categorie) {
    case 'siege' :
        $titre = _('MOT DE PASSE DU SIEGE');
        break;
    case 'age' :
        $titre = _('MOTS DE PASSE AGENCES');
        break;
    case 'tec' :
        $titre = _('MOTS DE PASSE TECHNICIENS');
        break;
    case 'ccli' :
        $titre = _('MOTS DE PASSE CONTACTS CLIENTS');
        break;
    case 'cli' :
        $titre = _('MOTS DE PASSE CLIENTS');
        break;
    case 'ope' :
        $titre = _('MOT DE PASSE OPERATEURS');
        break;
    case 'do' :
        $titre = _("MOTS DE PASSE DONNEUR D'ORDRES");
        break;
    case 'st' :
        $titre = _('MOTS DE PASSE SOUS-TRAITANTS');
        break;
    default :
        $pbm_cat = TRUE;
        break;
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Mot de passe'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <?php
    if ($categorie <> 'siege') {
        ?>
        <script language="javascript">
            <!--
            const tab_champ = new Array(
                "nom:code ; format:liste ; req:Y ; txt:<?php echo _('Code'); ?> ; vmn:1; stok:frmok ; stbad:frmbad");
            //-->
        </script>
        <?php
    }
    ?>

    <?php if ($pbm_cat == FALSE) { ?>
        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                <?php
                echo "init_valid_form('reinit','mdp_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                if ($categorie <> 'siege') {
                    echo "init_valid_form('desact','mdp_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                    echo "init_valid_form('react','mdp_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                }
                ?>
                init_autohref("cancel", 'click', 'index.php', false);
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>
<body>

<?php
include_once '../inc/entete.inc.php';

if ($pbm_cat == FALSE) {
    cre_ent_form($titre, '', '', '', FALSE);
    ?>
    <p align="center"><span class="annot_gras_it"><?php echo _('Que souhaitez-vous faire ?'); ?></span></p>
    <form name="mdp_maj" id="mdp_maj" method="post" action="mdp_enr.php?cat=<?php echo $categorie; ?>">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <?php
        switch ($categorie) {
            case 'siege' :
                if (existe_cdg() == FALSE) {
                    $retouridx = TRUE;
                }
                break;

            case 'age' :
                if (nb_age_actives() > 0) {
                    echo '<div align="center">';
                    // Création de la liste des agences ouvertes
                    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                    $rech = 'SELECT * FROM `' . TBAGE . "` WHERE `age_ouvert` = '1' ORDER BY age_nom";
                    $rows = $db->get_results($rech, ARRAY_A);
                    close_database();
                    cre_select_tab('code', 'code', $rows, 'age_code', 'age_nom', 'age_code', '', '', _('-- Faites votre choix --'));
                    echo '</div>';
                } else {
                    $retouridx = TRUE;
                }
                break;

            case 'tec' :
                if (nb_tec('') > 0) {
                    echo '<div align="center">';
                    echo '<select name="code" id="code">';
                    echo '<option value="">' . _('-- Faites votre choix --') . '</option>';
                    // création de la liste des techniciens présents
                    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                    $rech = 'SELECT * FROM `' . TBTEC . "` WHERE `tec_out` = '0' ORDER BY tec_nom";
                    $rows = $db->get_results($rech, ARRAY_A);
                    if ($rows) {
                        foreach ($rows as $row) {
                            $row = encode_str($row);
                            extract($row);
                            $txt_tec = $tec_nom . ' ' . $tec_prenom . ' (' . $tec_code . '), ';
                            if (trim($tec_codeage) <> '') {
                                $txt_tec .= _('agence') . ' ' . $tec_codeage;
                            }
                            if (trim($tec_codedo) <> '') {
                                $txt_tec .= _("donneur d'ordres") . ' ' . $tec_codedo;
                            }
                            if (trim($tec_codest) <> '') {
                                $txt_tec .= _('sous-traitant') . ' ' . $tec_codest;
                            }
                            echo '<option value="' . $tec_code . '">' . $txt_tec . '</option>';
                        }
                    }
                    close_database();
                    echo '</select>';
                    echo '</div>';
                } else {
                    $retouridx = TRUE;
                }
                break;

            case 'ccli' :
                if (nb_ccli('') > 0) {
                    echo '<div align="center">';
                    echo '<select name="code" id="code">';
                    echo '<option value="">' . _('-- Faites votre choix --') . '</option>';
                    // création de la liste des contacts clients
                    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                    $rech = 'SELECT * FROM `' . TBCCLI . '` ORDER BY ccli_nom,ccli_prenom';
                    $rows = $db->get_results($rech, ARRAY_A);
                    if ($rows) {
                        foreach ($rows as $row) {
                            $row = encode_str($row);
                            extract($row);
                            $txt_ccli = $ccli_nom . ' ' . $ccli_prenom . ' (' . Retournecp_Id($ccli_ville, FALSE) . ', ' . Retourneville_Id($ccli_ville, FALSE) . ')';
                            $row2 = lit_enr_cli($ccli_codecli, FALSE);
                            if (is_array($row2)) {
                                $row2 = encode_str($row2);
                                extract($row2);
                                $txt_ccli .= ' - ' . $cli_ste;
                            }
                            echo '<option value="' . $ccli_code . '">' . $txt_ccli . '</option>';
                        }
                    }
                    close_database();
                    echo '</select>';
                    echo '</div>';
                } else {
                    $retouridx = TRUE;
                }
                break;

            case 'cli' :
                if (nb_cli('') > 0) {
                    echo '<div align="center">';
                    echo '<select name="code" id="code">';
                    echo '<option value="">' . _('-- Faites votre choix --') . '</option>';
                    // création de la liste des clients
                    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                    $rech = 'SELECT * FROM `' . TBCLI . '` ORDER BY cli_ste,cli_nom';
                    $rows = $db->get_results($rech, ARRAY_A);
                    if ($rows) {
                        foreach ($rows as $row) {
                            $row = encode_str($row);
                            extract($row);
                            if ($cli_ste <> '') {
                                $txt_cli = $cli_ste . ' (' . Retournecp_Id($cli_ville, FALSE) . ', ' . Retourneville_Id($cli_ville, FALSE) . ') - ' . $cli_code;
                            } else {
                                $txt_cli = $cli_nom . ' ' . $cli_prenom . ' (' . Retournecp_Id($cli_ville, FALSE) . ', ' . Retourneville_Id($cli_ville, FALSE) . ') - ' . $cli_code;
                            }
                            echo '<option value="' . $cli_code . '">' . $txt_cli . '</option>';
                        }
                    }
                    close_database();
                    echo '</select>';
                    echo '</div>';
                } else {
                    $retouridx = TRUE;
                }
                break;

            case 'ope' :
                if (nb_ope() > 0) {
                    echo '<div align="center">';
                    // Création de la liste des opérateurs présents
                    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                    $rech = 'SELECT * FROM `' . TBOPE . "` WHERE `ope_out` = '0' ORDER BY ope_nom";
                    $rows = $db->get_results($rech, ARRAY_A);
                    close_database();
                    cre_select_tab('code', 'code', $rows, 'ope_code', 'ope_nom', 'ope_prenom-ope_code', '', '', _('-- Faites votre choix --'));
                    echo '</div>';
                } else {
                    $retouridx = TRUE;
                }
                break;

            case 'do' :
                if (nb_do() > 0) {
                    echo '<div align="center">';
                    // Création de la liste des opérateurs présents
                    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                    $rech = 'SELECT * FROM `' . TBDO . "` WHERE `do_ouvert` = '1' ORDER BY do_nom";
                    $rows = $db->get_results($rech, ARRAY_A);
                    close_database();
                    cre_select_tab('code', 'code', $rows, 'do_code', 'do_nom', 'do_prenom-do_code', '', '', _('-- Faites votre choix --'));
                    echo '</div>';
                } else {
                    $retouridx = TRUE;
                }
                break;

            case 'st' :
                if (nb_st() > 0) {
                    echo '<div align="center">';
                    // Création de la liste des sous-traitants ouverts
                    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
                    $rech = 'SELECT * FROM `' . TBST . "` WHERE `st_ouvert` = '1' ORDER BY st_nom";
                    $rows = $db->get_results($rech, ARRAY_A);
                    close_database();
                    cre_select_tab('code', 'code', $rows, 'st_code', 'st_nom', 'st_code', '', '', _('-- Faites votre choix --'));
                    echo '</div>';
                } else {
                    $retouridx = TRUE;
                }
                break;

        }

        if ($retouridx == FALSE) {
            ?>
            <p align="center">
                <?php
                echo '<input name="cancel" type="button" class="bton_std" id="cancel" value="' . _('Ne rien faire') . '">';
                echo '<input name="reinit" type="button" class="bton_std" id="reinit" value="' . _('Réinitialiser') . '">';
                if ($categorie <> 'siege') {
                    echo '<input name="desact" type="button" class="bton_std" id="desact" value="' . _('Désactiver') . '">';
                    echo '<input name="react" type="button" class="bton_std" id="react" value="' . _('Réactiver') . '">';
                    echo '<div class="annot_petit_it" align="center">';
                    echo '(' . _('La désactivation  empêche la connexion, mais ne supprime pas la fiche') . ')';
                    echo '</div>';
                }
                ?>
            </p>
            <?php
        }
        ?>
    </form>
    <?php
    if ($retouridx == TRUE) {
        pop_ret_auto(_("Pas d'enregistrement..."), 'warn', 'index.php');
    }
} else {
    pop_ret_auto(_('Catégorie inconnue'), 'warn', 'index.php');
}
include_once 'pied.php';
?>
</body>
</html>