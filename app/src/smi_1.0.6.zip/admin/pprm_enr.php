<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_prm.inc.php';
include_once '../inc/fic_prmmail.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$modeplan = valpost('modeplan');
$firsthour = (int)valpost('firsthour');
$lasthour = (int)valpost('lasthour');

$retourliste = FALSE;
$msg = '';

// MAJ de la fiche Paramètres Planning
$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
$rech = 'SELECT * FROM `' . TBPPRM . '`';
$rows = $db->get_results($rech, ARRAY_A);
if ($rows) {
    $num_rows = count($rows);
    switch ($num_rows) {
        case 1 :
            foreach ($rows as $row) {
                $row = encode_str($row);
                $rech = 'UPDATE `' . TBPPRM . "` SET `pprm_modeplan`='" . $modeplan . "', `pprm_firsthour`='" . $firsthour . "',";
                $rech .= " `pprm_lasthour`='" . $lasthour . "'";
                $rech .= "  WHERE `pprm_id` = '" . $row['pprm_id'] . "'";
                $db->query($rech);
            }
            $msg = _('Fiche modifiée');
            $retourliste = TRUE;
            break;
        case 0 :
            $rech = 'INSERT INTO `' . TBPPRM . '`'
                . ' (pprm_modeplan,pprm_firsthour,pprm_lasthour)'
                . ' VALUES'
                . " ('$modeplan','$firsthour','$lasthour')";
            $db->query($rech);
            $msg = _('Fiche modifiée');
            $retourliste = TRUE;
            break;
        default :
            $msg = _('Problème mise à jour');
            break;
    }
} else {
    $msg = _('Problème mise à jour');
}
close_database();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Paramètres planning'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form(_('PARAMETRES PLANNING'), '', '', '', FALSE);
if ($retourliste == FALSE) {
    exec_func_js("warn_txt('" . str_escape($msg) . "')");
    aff_ret_idx_man($td, 'pprm_maj.php', _('Retour à la saisie'), FALSE);
} else {
    pop_ret_auto($msg, 'ok', 'index.php');
}
include_once 'pied.php';
?>
</body>
</html>
