<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(TRUE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

//Numérotation
$rtec = str_majuscules(valpost('rtec'));
$ntec = (int)valpost('ntec');
$rcli = str_majuscules(valpost('rcli'));
$ncli = (int)valpost('ncli');
$rint = str_majuscules(valpost('rint'));
$nint = (int)valpost('nint');
$rope = str_majuscules(valpost('rope'));
$nope = (int)valpost('nope');
$rcon = str_majuscules(valpost('rcon'));
$ncon = (int)valpost('ncon');
$rcer = str_majuscules(valpost('rcer'));
$ncer = (int)valpost('ncer');
$rdde = str_majuscules(valpost('rdde'));
$ndde = (int)valpost('ndde');
$rrel = str_majuscules(valpost('rrel'));
$nrel = (int)valpost('nrel');
$rrlic = str_majuscules(valpost('rrlic'));
$nrlic = (int)valpost('nrlic');
$rrpdt = str_majuscules(valpost('rrpdt'));
$nrpdt = (int)valpost('nrpdt');
$rord = str_majuscules(valpost('rord'));
$nord = (int)valpost('nord');
$rretp = str_majuscules(valpost('rretp'));
$nretp = (int)valpost('nretp');
$rrete = str_majuscules(valpost('rrete'));
$nrete = (int)valpost('nrete');
$rloc = str_majuscules(valpost('rloc'));
$nloc = (int)valpost('nloc');
$rdos = str_majuscules(valpost('rdos'));
$ndos = (int)valpost('ndos');
$rtac = str_majuscules(valpost('rtac'));
$ntac = (int)valpost('ntac');

// Contrats
// Location
$coclpolcgv = (int)valpost('coclpolcgv');
$relmin = (int)valpost('relmin');
$relmax = (int)valpost('relmax');
$coclrenactif = (int)valpost('coclrenactif');
$typarr = (int)valpost('typarr');
$codeper = str_majuscules(valpost('codeper'));
$pourm = (float)valpost('pourm');
$pour1 = (float)valpost('pour1');
$pour2 = (float)valpost('pour2');
$pour3 = (float)valpost('pour3');

// Intervention
$intpolpied = (int)valpost('intpolpied');
$intpolcgv = (int)valpost('intpolcgv');
$coupactif = (int)valpost('intcoupactif');
$coupc = (int)valpost('intcoupc');
$coupm = (int)valpost('intcoupm');
$coupma = (int)valpost('intcoupma');
$coupman = (int)valpost('intcoupman');
$coupsdp = (int)valpost('intcoupsdp');

// Location
$colocpolcgv = (int)valpost('colocpolcgv');

// Planning
$modeplan = valpost('modeplan');
$firsthour = (int)valpost('firsthour');
$lasthour = (int)valpost('lasthour');

// Retours
$retdpolpied = (int)valpost('retdpolpied');
$retepolpied = (int)valpost('retepolpied');

// Traçabilité
$nivtrace = (int)valpost('nivtrace');

$retourliste = FALSE;

// MAJ des constantes / paramètres
$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
$rech = 'SELECT * FROM `' . TBCONS . '`';
$row = $db->get_row($rech, ARRAY_A);
if ($row) {
    $rech = 'UPDATE `' . TBCONS . "` SET `cons_relmin`='" . $relmin . "', `cons_relmax`='" . $relmax . "', `cons_rtec`='" . $rtec . "',";
    $rech .= " `cons_ntec`='" . $ntec . "', `cons_rcli`='" . $rcli . "', `cons_ncli`='" . $ncli . "', `cons_rint`='" . $rint . "',";
    $rech .= " `cons_nint`='" . $nint . "', `cons_rope`='" . $rope . "', `cons_nope`='" . $nope . "', `cons_rcon`='" . $rcon . "',";
    $rech .= " `cons_ncon`='" . $ncon . "', `cons_rcer`='" . $rcer . "', `cons_ncer`='" . $ncer . "', `cons_rdde`='" . $rdde . "',";
    $rech .= " `cons_ndde`='" . $ndde . "',`cons_rrel`='" . $rrel . "', `cons_nrel`='" . $nrel . "',`cons_rrlic`='" . $rrlic . "',";
    $rech .= " `cons_nrlic`='" . $nrlic . "',`cons_rrpdt`='" . $rrpdt . "', `cons_nrpdt`='" . $nrpdt . "',";
    $rech .= " `cons_rord`='" . $rord . "', `cons_nretp`='" . $nord . "',";
    $rech .= " `cons_rretp`='" . $rretp . "', `cons_nretp`='" . $nretp . "',";
    $rech .= " `cons_rrete`='" . $rrete . "', `cons_nrete`='" . $nrete . "',";
    $rech .= " `cons_rloc`='" . $rloc . "', `cons_nloc`='" . $nloc . "',";
    $rech .= " `cons_rdos`='" . $rdos . "', `cons_ndos`='" . $ndos . "',";
    $rech .= " `cons_rtac`='" . $rtac . "', `cons_ntac`='" . $ntac . "',";
    $rech .= " `cons_nivtra`='" . $nivtrace . "',";
    $rech .= " `cons_coclcat_default`=' $coclrenactif',";
    $rech .= " `cons_coclcat_typarr`='$typarr', `cons_coclcat_codeper`='" . $db->escape($codeper) . "',";
    $rech .= " `cons_coclcat_pourm`='$pourm', `cons_coclcat_pour1`='$pour1', `cons_coclcat_pour2`='$pour2', `cons_coclcat_pour3`='$pour3',";
    $rech .= " `cons_cocl_polcgv`=' $coclpolcgv',";
    $rech .= " `cons_int_polpied`=' $intpolpied', `cons_int_polcgv`=' $intpolcgv',";
    $rech .= " `cons_int_coupactif`=' $coupactif',";
    $rech .= " `cons_int_coupc`='$coupc', `cons_int_coupm`='$coupm',";
    $rech .= " `cons_int_coupma`='$coupma', `cons_int_coupman`='$coupman', `cons_int_coupsdp`='$coupsdp',";
    $rech .= " `cons_coloc_polcgv`=' $colocpolcgv',";
    $rech .= " `cons_retd_polpied`=' $retdpolpied', `cons_rete_polpied`=' $retepolpied'";
    $rech .= "  WHERE `cons_id` = '" . $row['cons_id'] . "'";
    $db->query($rech);
    $msg = _('Paramètres mis à jour');
    $retourliste = TRUE;
} else {
    $msg = _('Problème mise à jour');
}

if ($retourliste == TRUE) {
    // MAJ de la fiche Paramètres Planning
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
    $rech = 'SELECT * FROM `' . TBPPRM . '`';
    $rows = $db->get_results($rech, ARRAY_A);
    if ($rows) {
        $num_rows = count($rows);
        switch ($num_rows) {
            case 1 :
                foreach ($rows as $row) {
                    $row = encode_str($row);
                    $rech = 'UPDATE `' . TBPPRM . "` SET `pprm_modeplan`='" . $modeplan . "', `pprm_firsthour`='" . $firsthour . "',";
                    $rech .= " `pprm_lasthour`='" . $lasthour . "'";
                    $rech .= "  WHERE `pprm_id` = '" . $row['pprm_id'] . "'";
                    $db->query($rech);
                }
                break;
            case 0 :
                $rech = 'INSERT INTO `' . TBPPRM . '`'
                    . ' (pprm_modeplan,pprm_firsthour,pprm_lasthour)'
                    . ' VALUES'
                    . " ('$modeplan','$firsthour','$lasthour')";
                $db->query($rech);
                break;
            default :
                $retourliste = FALSE;
                $msg = _('Problème mise à jour');
                break;
        }
    } else {
        $retourliste = FALSE;
        $msg = _('Problème mise à jour');
    }
    close_database();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Paramètres'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form(_('PARAMETRES DIVERS'), '', '', '', FALSE);
if ($retourliste == FALSE) {
    exec_func_js("warn_txt('" . str_escape($msg) . "')");
    aff_ret_idx_man($td, 'prm_maj.php', _('Retour à la saisie'), FALSE);
} else {
    pop_ret_auto($msg, 'ok', 'index.php');
}
include_once 'pied.php';
?>
</body>
</html>