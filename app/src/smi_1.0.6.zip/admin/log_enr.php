<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if (CheckURLLog(TRUE) == FALSE) {
    header('Location: ../index.php');
}
if (CheckNivLog('9') == FALSE) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_date.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
// Variables Formulaire
fix_magic_quotes();
$_POST = clean_str($_POST);

$td = $_GET['td'];

$date1f = valpost('date1f');
$date2f = valpost('date2f');
$date1 = datetomysql($date1f);
$date2 = datetomysql($date2f);

$retourliste = TRUE;

if ($td == 'del') {
    $msg = '';

    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

    // vérification de l'existence de la fourchette de dates

    if ($date1 != '') // Date remplie = purge sur fourchette
    {
        $rech = 'SELECT * FROM `' . TBLOG . "` WHERE `log_date` >= '$date1' AND `log_date` <= '$date2'";
    } else {
        $rech = 'SELECT * FROM `' . TBLOG . '`';
    }
    $rows = $db->get_results($rech, ARRAY_A);
    if ($rows && (count($rows) <> 0)) {
        // SUPPRESSION des logs
        if ($date1 != '') // Date remplie = purge sur fourchette
        {
            $rech = 'DELETE FROM `' . TBLOG . "` WHERE `log_date` >= '$date1' AND `log_date` <= '$date2'";
        } else {
            $rech = 'TRUNCATE TABLE `' . TBLOG . '`';
        }
        $db->query($rech);

        if ($date1 != '') // Date remplie = purge sur fourchette
        {
            $msg = _('Logs purgés du ') . $date1f . _(' ' . _('au') . ' ') . $date2f;
        } else {
            $msg = _('Logs purgés en totalité');
        }
    } else {
        if ($date1 != '') // Date remplie = purge sur fourchette
        {
            $msg = _('Aucun logs sur cette fourchette de dates');
        } else {
            $msg = _('Pas de logs à purger');
        }
        $retourliste = FALSE;
    }
    close_database();
} else {
    $msg = _('Problème de paramètres');
    $retourliste = FALSE;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Logs de Connexion'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            <?php
            if ($retourliste == FALSE)
                {echo "warn_txt('" . str_escape($msg) . "');";}
            ?>
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>
<body>

<?php include_once '../inc/entete.inc.php';
cre_ent_form(_('PURGE DES LOGS'), '', '', '', FALSE);
if ($retourliste == FALSE) {
    aff_ret_idx_man($td, 'log_lst.php?ord=DES&tri=Date', _('Retour à la liste'), TRUE);
} else {
    pop_ret_auto($msg, 'ok', 'log_lst.php?ord=DES&tri=Date');
}
include_once 'pied.php';
?>
</body>
</html>