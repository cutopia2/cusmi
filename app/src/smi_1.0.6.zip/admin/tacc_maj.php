<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$td = $_GET['td'];
$coderech = $_GET['code'];
$is = $_GET['is'];

$pbm_tacc = FALSE;

if ($coderech <> '') {
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');
    $rech = 'SELECT * FROM `' . TBTACC . "` WHERE tacc_code = '" . $db->escape($coderech) . "'";
    $row = $db->get_row($rech, ARRAY_A);
    if ($row) {
        $row = encode_str($row);
        extract($row);
    } else {
        $pbm_tacc = TRUE;
    }
    close_database();
} else {
    if ($td == 'add') {
        $tacc_img = $is;
        $tacc_code = '';
        $tacc_desc = '';
    } else {
        $pbm_tacc = TRUE;
    }
}

$titre = '';
switch ($td) {
    case 'add' :
        $titre = _('CREATION CATEGORIE TACHE');
        break;
    case 'edit' :
        $titre = _('MISE A JOUR CATEGORIE TACHE');
        break;
    case 'del' :
        $titre = _('SUPPRESSION CATEGORIE TACHE');
        if ($tacc_delok == 0) {
            $pbm_tacc = TRUE;
        }
        break;
    default :
        $pbm_tacc = TRUE;
        break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche catégorie tâche'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab1_champ = ["nom:image ; format:txt ; req:Y ; txt:<?php echo _('Icône'); ?> ; lmx:200 ; stok:frmok ; stbad:frmbad",
            "nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?> ; lmx:5 ; stok:frmok ; stbad:frmbad",
            "nom:desc; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?> ; lmx:50 ; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_tacc == FALSE) { ?>
        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                <?php
                 switch ($td)
                 {
                    case 'add':
                        echo "init_valid_form('enr','tacc_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'edit':
                        echo "readonly_id('code',false);";
                        echo "init_valid_form('enr','tacc_maj','".valsession('date_fmtshort')."',tab1_champ,'','');";
                        break;
                    case 'del':
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                    case 'view':
                        echo 'readonly_all();';
                        break;

                 }
                ?>
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>
<?php
include_once '../inc/entete.inc.php';

if ($pbm_tacc == FALSE) {
    cre_ent_form($titre, 'tacc_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="tacc_maj" id="tacc_maj" method="post" action="tacc_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="10%" class="rubfrm" id="f_img" align="right"><?php echo _('Icône'); ?></td>
                <td>
                    <input name="image" type="hidden" id="image" value="<?php echo $tacc_img ?>">
                    <?php
                    if (($td == 'add') || ($td == 'edit')) {
                        if ($tacc_img <> '') {
                            echo ' <img src="' . $tacc_img . '" border="0" align="absmiddle">';
                        } else {
                            echo ' <img src="../img/vide.png" align="absmiddle">';
                            echo ' <a href="icotacc_lst.php">' . _('Choisir Icône') . '</a>';
                            echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                            echo '<span class="annot_std_it">' . _('(impératif en 1er !)') . '</span>';
                        }
                    } else {
                        echo ' <img src="' . $tacc_img . '" border="0" align="absmiddle">';
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td width="10%" class="rubfrm" id="f_code" align="right"><?php echo _('Code'); ?></td>
                <td width="47%">
                    <input name="code" type="text" id="code" value="<?php echo $tacc_code ?>" size="5" maxlength="5">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">
                </td>
            </tr>
            <tr>
                <td width="10%" class="rubfrm" id="f_desc" align="right"><?php echo _('Libellé'); ?></td>
                <td><input name="desc" type="text" id="desc" value="<?php echo $tacc_desc ?>" size="50">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
            </tr>
        </table>
        <p align="center">
            <?php if (($td == 'add') || ($td == 'edit')) { ?>
                <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="<?php echo _('Réinitialiser'); ?>">
                <input name="enr" type="button" class="bton_std" id="enr" value="<?php echo _('Enregistrer'); ?>">
            <?php } ?>
            <?php if ($td == 'del') { ?>
                <input name="del" type="submit" class="bton_std" id="del" value="<?php echo _('Supprimer'); ?>">
            <?php } ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'tacc_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>