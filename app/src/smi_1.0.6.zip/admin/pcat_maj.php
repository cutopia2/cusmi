<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/fic_droits.inc.php';
include_once '../inc/fic_plan.inc.php';
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
// Variables Formulaire
fix_magic_quotes();
$_GET = clean_str($_GET);

$td = $_GET['td'];
$coderech = $_GET['code'];

$pbm_plancat = FALSE;

if ($coderech <> '') {
    $row = lit_enr_pcat($coderech);
    if (is_array($row)) {
        $row = encode_str($row);
        extract($row);
    } else {
        $pbm_plancat = TRUE;
    }
} else {
    if ($td <> 'add') {
        $pbm_plancat = TRUE;
    }
}

$titre ='';
if ($pbm_plancat == FALSE) {
    switch ($td) {
        case 'add' :
            $titre = _('CREATION CATEGORIE EVENEMENT');
            $pcat_couleur = '#C5CED7';
            break;
        case 'edit' :
            $titre = _('MISE A JOUR CATEGORIE EVENEMENT');
            break;
        case 'del' :
            $titre = _('SUPPRESSION CATEGORIE EVENEMENT');
            break;
        default :
            $pbm_plancat = TRUE;
            break;
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-type=" content="text/html; charset=utf-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Fiche catégorie évènements'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script language="javascript">
        <!--
        const tab_champ = ["nom:code ; format:alphanum ; req:Y ; txt:<?php echo _('Code'); ?> ; lmn:1 ; lmx:5; stok:frmok ; stbad:frmbad",
            "nom:desc ; format:txt ; req:Y ; txt:<?php echo _('Libellé'); ?>; lmn:1 ; lmx:50; stok:frmok ; stbad:frmbad",
            "nom:couleur ; format:hexacol ; req:Y ; txt:<?php echo _('Couleur'); ?>; lmn:7 ; lmx:7; stok:frmok ; stbad:frmbad"];
        //-->
    </script>

    <?php if ($pbm_plancat == FALSE) { ?>
        <script type="text/javascript">
            <!--
            function init_all() {
                init_Body();
                <?php
                switch ($td)
                {
                    case 'add' :
                        echo "init_valid_form('enr','pcat_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                        break;
                    case 'edit' :
                        echo "init_valid_form('enr','pcat_maj','".valsession('date_fmtshort')."',tab_champ,'','');";
                        echo "readonly_id('code',false);";
                        break;
                    case 'view' :
                        echo 'readonly_all();';
                        break;
                    case 'del' :
                        echo 'readonly_all();';
                        echo "warn_del('');";
                        break;
                }
                ?>
                $('#boxpicker').hide();
                init_colorpicker();
                display_colorpicker();
                close_colorpicker();
                valid_colorpicker();
                Focus_first();
            }

            $(document).ready(function () {
                init_all();
            });
            //-->
        </script>

    <?php } ?>
</head>

<body>

<?php
include_once '../inc/entete.inc.php';
if ($pbm_plancat == FALSE) {
    cre_ent_form($titre, 'pcat_lst.php', $_SERVER['HTTP_REFERER']);
    ?>
    <form name="pcat_maj" id="pcat_maj" method="post" action="pcat_enr.php">
        <input name="titre" type="hidden" id="titre" value="<?php echo $titre ?>">
        <input name="td" type="hidden" id="td" value="<?php echo $td ?>">
        <input name="nbutton" type="hidden" id="nbutton" value="">
        <table width="100%" border="0">
            <tr>
                <td width="10%" class="rubfrm" id="f_code"><?php echo _('Code'); ?></td>
                <td width="47%">
                    <input name="code" type="text" id="code" value="<?php echo $pcat_code ?>" size="5">
                    <?php
                    if ($td == 'add') {
                        echo ' <img src="../img/oblig.png" align="absmiddle" alt="' . _('Champ obligatoire') . '">';
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_desc"><?php echo _('Libellé'); ?></td>
                <td><input name="desc" type="text" id="desc" value="<?php echo $pcat_desc; ?>" size="50">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>"></td>
            </tr>
            <tr>
                <td class="rubfrm" id="f_couleur"><?php echo _('Couleur'); ?></td>
                <td>
                    <div id="boxpicker" class="pick_box">
                        <div style="float:right;">
                            <img id="colorpicker_valid" src="../img/ok.png" border="0" align="absmiddle"
                                 title="<?php echo _('Valider'); ?>" alt="<?php echo _('Valider'); ?>">
                            <img id="colorpicker_close" src="../img/rech_close.png" border="0" align="absmiddle"
                                 title="<?php echo _('Fermer'); ?>" alt="<?php echo _('Fermer'); ?>">
                        </div>
                        <div id="colorpicker" style="clear:both;">
                        </div>
                    </div>
                    <input id="couleur_init" name="couleur_init" type="hidden" value="<?php echo $pcat_couleur; ?>"
                           readonly="1">
                    <input id="couleur" name="couleur" type="hidden" value="<?php echo $pcat_couleur; ?>" readonly="1">
                    <input id="couleur_display" name="couleur_display" type="button" value=""
                           style="background-color:<?php echo $pcat_couleur; ?>;" class="exemple_color">
                    <img src="../img/oblig.png" align="absmiddle" alt="<?php echo _('Champ obligatoire'); ?>">

                    <div class="annot_petit_it"><?php echo _('Cliquez sur la couleur pour la changer') ?></div>
                </td>
            </tr>
        </table>
        <p align="center">
            <?php
            switch ($td) {
                case 'add' :
                case 'edit' :
                    echo '<input name="enr" type="button" class="bton_std" id="enr" value="' . _('Enregistrer') . '">';
                    echo ' <input name="RAZ" type="reset" class="bton_std" id="RAZ" value="' . _('Réinitialiser') . '">';
                    break;
                case 'del' :
                    echo '<input name="del" type="submit" class="bton_std" id="del" value="' . _('Supprimer') . '">';
                    break;
            }
            ?>
        </p>
    </form>
    <?php
} else {
    pop_ret_auto(_('Problème de paramètres'), 'warn', 'pcat_lst.php');
}
include_once 'pied.php';
?>
</body>
</html>