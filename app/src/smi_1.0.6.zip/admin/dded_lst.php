<?php
/****************************************************************************************
 * SMI (Services Maintenance Interventions) est une gestion libre de maintenance et de SAV
 *
 * Version 1.0.6
 *
 * Copyright (C) 2006-2018  Sylvain FATOME
 * This program is free software; you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program
 * (in the directory docs);
 * if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA  02110-1301, USA.
 *
 * Contact : galawa@free.fr
 *
 * Web : http://smi.no-ip.org
 ****************************************************************************************/

session_start();

require_once '../lib/gettext/gettext.inc';
include_once '../inc/config.inc.php';
include_once '../inc/fic_droits.inc.php';
include_once '../inc/func_log.inc.php';
if ((CheckURLLog(FALSE) == FALSE) || (CheckNivLog('5-9') == FALSE)) {
    header('Location: ../index.php');
}
include_once '../inc/func.inc.php';
include_once '../inc/func_geo.inc.php';
include_once '../inc/func_txt.inc.php';
include_once '../inc/lst.inc.php';
include_once '../classes/ezSQL/shared/ez_sql_core.php';
include_once '../classes/ezSQL/mysqli/ez_sql_mysqli.php';
include_once '../inc/func_sql.inc.php';
Archivelog(valsession('code_log'));
$_SESSION['typ_filtres'] = 'dded';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>SMI - <?php echo _('ESPACE PRIVE'); ?> : <?php echo _('Liste des Destinataires'); ?></title>

    <?php include_once '../inc/header.inc.php'; ?>

    <script type="text/javascript">
        <!--
        function init_all() {
            init_Body();
            init_autohref_classe('falselnkimg', '');
            Focus_first();
        }

        $(document).ready(function () {
            init_all();
        });
        //-->
    </script>

</head>

<body>

<?php
include_once '../inc/entete.inc.php';
cre_ent_form(_('DESTINATAIRES DES DEMANDEURS'), '', '', '', FALSE);
$fic_imp = '';
$url_add = 'dded_maj.php?td=add&code=';

$db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

$rech = cree_strrechlstdded();
$rech .= crestr_triord($dded_titre_col, 'dded_code', FALSE, $limit);

$rows = $db->get_results($rech, ARRAY_A);
close_database();

if ($rows) {
    include_once '../inc/formr.inc.php';

    $numrows = count($rows);
    $db = open_database(DBUSER, DBPASS, DBNAME, DBHOST, 'utf8');

    $rech = modstr_triord($rech, $dded_titre_col, 'dded_code', TRUE, $limit);

    $rows = $db->get_results($rech, ARRAY_A);

    // *** Pagination de pied
    pagine_lst($numrows, $limit);

    // *** Affichage de la table
    echo '<table class="Mtable" border="0" width="100%" cellpadding="0" cellspacing="0">';

    // création entête
    titlst($dded_titre_col);
    echo '<th>' . _('Cliquer') . '</th>';

    $i = 0;

    foreach ($rows as $row) {
        $row = encode_str($row);
        // création de l'entête de ligne (TR)
        echo '<tr>';

        echo '<td>' . $row['dded_code'] . '</td>';
        echo '<td>' . $row['dded_desc'] . '</td>';
        echo '<td align="center">';
        if ($row['dded_code'] <> 'VA') {
            echo ' <a href="mailto:' . $row['dded_email'] . '">' . $row['dded_email'] . '</a>';
        } else {
            echo _("email de l'agence propriétaire") . '<br />' . _('ou sur zone de chalandise');
        }
        echo '</td>';
        echo '<td align="center">' . $non_oui2[$row['dded_pub']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['dded_cli']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['dded_age']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['dded_tec']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['dded_ope']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['dded_cge']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['dded_dot']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['dded_do']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['dded_st']] . '</td>';
        echo '<td align="center">' . $non_oui2[$row['dded_stt']] . '</td>';

        // CREATION lien dynamique sur icône (édition, suppression, etc...)
        echo '<td align="center">';
        if ($row['dded_code'] <> 'VA') {
            $lst_maj = TRUE;
            cre_falselnk_img('', 'dded_edit_' . $row['dded_id'], 'span', 'center', _('Edition'), 'lnk', 'dded_maj.php?td=edit&code=' . $row['dded_code'], '../img/edit.png');
            if ($row['dded_delok'] == TRUE) {
                $lst_del = TRUE;
                cre_falselnk_img('', 'dded_del_' . $row['dded_id'], 'span', 'center', _('Suppression'), 'lnk', 'dded_maj.php?td=del&code=' . $row['dded_code'], '../img/del.png');
            }
        } else {
            echo '-';
        }
        echo '</td>';

        echo '</tr>';

        $i++;
    }
    echo '</table>';
    // *** Fin affichage de la table

    close_database();

    // *** Pagination de pied
    pagine_lst($numrows, $limit);

    $taille_piedla = '';
    include_once '../inc/piedla.inc.php';
} else {
    retpp();
}

include_once 'pied.php';
?>
</body>
</html>